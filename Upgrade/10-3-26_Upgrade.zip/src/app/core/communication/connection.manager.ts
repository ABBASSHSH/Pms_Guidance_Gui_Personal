import { Injectable } from '@angular/core';
import { Subject, Observable } from 'rxjs';
import { IMessageReceiver } from './i-message-receiver';
import { RawMessage } from './raw-message';

/**
 * Handles low-level WebView2 communication.
 *
 * Responsibilities (single):
 *   - Establish / tear down the `chrome.webview` event listener.
 *   - Emit raw parsed messages on `messages$`.
 *   - Forward outgoing messages via `postMessage`.
 *
 * Must NOT contain application or domain logic.
 */
@Injectable({ providedIn: 'root' })
export class ConnectionManager implements IMessageReceiver {
  private webview: any | null = null;

  private readonly messageSubject = new Subject<RawMessage>();

  /** Emits every inbound message from the WebView2 host. */
  readonly messages$: Observable<RawMessage> = this.messageSubject.asObservable();

  private readonly messageHandler = (event: any): void => {
    this.handleMessage(event?.data);
  };

  /** Establish the WebView2 connection. Call exactly once at bootstrap. */
  connect(): void {
    if (this.webview) {
      // Already connected — guard against accidental double-registration of
      // the event listener which would deliver each message twice.
      console.warn('[ConnectionManager.connect] Already connected — ignoring duplicate connect() call.');
      return;
    }

    const chromeRef = (window as any)?.chrome;

    if (!chromeRef?.webview) {
      // Log to console only — injecting LogService here would create a circular
      // dependency (LogManager → CommunicationService → ConnectionManager).
      // The message stream is left open so that if the environment later
      // injects messages manually (e.g. tests, late-binding mocks) it still works.
      console.error('[ConnectionManager.connect] WebView2 environment not detected. Messages will not be received.');
      return;
    }

    this.webview = chromeRef.webview;
    this.webview.addEventListener('message', this.messageHandler);
  }

  /** Send a JSON message to the WebView2 host. */
  send(message: RawMessage): void {
    if (!this.webview) {
      return;
    }
    this.webview.postMessage(message);
  }

  /** Remove the event listener and release the webview reference. */
  disconnect(): void {
    if (this.webview) {
      this.webview.removeEventListener('message', this.messageHandler);
      this.webview = null;
    }
  }

  // ---- private ----

  private handleMessage(data: any): void {
    if (data === null || data === undefined) {
      console.warn('[ConnectionManager.handleMessage] Received null or undefined message data — discarding.');
      return;
    }

    try {
      const parsedMessage: RawMessage =
        typeof data === 'string' && data !== ''
          ? (JSON.parse(data) as RawMessage)
          : (data as RawMessage);

      this.messageSubject.next(parsedMessage);
    } catch (err) {
      // Malformed JSON — log to console so it is visible during development/debugging.
      // if we propagate the error into the Subject; that would permanently terminate
      // the stream and prevent any further messages from being processed.
      console.warn('[ConnectionManager.handleMessage] Failed to parse message — discarding malformed payload.', err);
    }
  }
}
