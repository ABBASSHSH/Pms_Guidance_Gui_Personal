import { TestBed } from '@angular/core/testing';
import { CommunicationService } from './communication.service';
import { ConnectionManager } from './connection.manager';
import { Subject } from 'rxjs';
import { RawMessage } from './raw-message';

describe('CommunicationService', () => {
  let service: CommunicationService;
  let mockConnectionManager: jasmine.SpyObj<ConnectionManager>;
  let messageSubject: Subject<RawMessage>;

  beforeEach(() => {
    messageSubject = new Subject<RawMessage>();

    mockConnectionManager = jasmine.createSpyObj('ConnectionManager', [
      'connect',
      'send',
      'disconnect',
    ], {
      messages$: messageSubject.asObservable(),
    });

    TestBed.configureTestingModule({
      providers: [
        CommunicationService,
        { provide: ConnectionManager, useValue: mockConnectionManager },
      ],
    });

    service = TestBed.inject(CommunicationService);
  });

  describe('Initialization', () => {
    it('should create the service', () => {
      expect(service).toBeTruthy();
    });

    it('should connect successfully', () => {
      service.connect();
      expect(mockConnectionManager.connect).toHaveBeenCalledTimes(1);
    });
  });

  describe('Message Sending', () => {
    it('should send action-based message without payload', () => {
      const action = 'TestAction';
      service.send(action);

      expect(mockConnectionManager.send).toHaveBeenCalledWith({
        Action: action,
      } as any);
    });

    it('should send action-based message with payload', () => {
      const action = 'TestAction';
      const payload = { key1: 'value1', key2: 123 };

      service.send(action, payload);

      expect(mockConnectionManager.send).toHaveBeenCalledWith({
        Action: action,
        key1: 'value1',
        key2: 123,
      } as any);
    });

    it('should handle empty payload object', () => {
      const action = 'TestAction';
      service.send(action, {});

      expect(mockConnectionManager.send).toHaveBeenCalledWith({
        Action: action,
      } as any);
    });

    it('should handle complex payload structures', () => {
      const action = 'ComplexAction';
      const payload = {
        nested: { data: { value: 'test' } },
        array: [1, 2, 3],
        boolean: true,
      };

      service.send(action, payload);

      expect(mockConnectionManager.send).toHaveBeenCalledWith({
        Action: action,
        nested: { data: { value: 'test' } },
        array: [1, 2, 3],
        boolean: true,
      } as any);
    });
  });

  describe('Message Receiving', () => {
    it('should provide observable for incoming messages', (done) => {
      const testMessage = { Action: 'Response', Data: 'TestData' } as any;

      service.onMessage().subscribe((message) => {
        expect(message).toEqual(testMessage);
        done();
      });

      messageSubject.next(testMessage);
    });

    it('should handle multiple message subscribers', () => {
      const messages1: RawMessage[] = [];
      const messages2: RawMessage[] = [];

      service.onMessage().subscribe((msg) => messages1.push(msg));
      service.onMessage().subscribe((msg) => messages2.push(msg));

      const testMessage = { Action: 'Test' } as any;
      messageSubject.next(testMessage);

      expect(messages1).toEqual([testMessage]);
      expect(messages2).toEqual([testMessage]);
    });

    it('should receive multiple consecutive messages', () => {
      const receivedMessages: RawMessage[] = [];

      service.onMessage().subscribe((msg) => receivedMessages.push(msg));

      const message1 = { Action: 'Message1' } as any;
      const message2 = { Action: 'Message2' } as any;
      const message3 = { Action: 'Message3' } as any;

      messageSubject.next(message1);
      messageSubject.next(message2);
      messageSubject.next(message3);

      expect(receivedMessages.length).toBe(3);
      expect(receivedMessages).toEqual([message1, message2, message3]);
    });
  });

  describe('Shutdown', () => {
    it('should disconnect from connection manager', () => {
      service.shutdown();
      expect(mockConnectionManager.disconnect).toHaveBeenCalledTimes(1);
    });

    it('should be safe to call shutdown multiple times', () => {
      service.shutdown();
      service.shutdown();
      expect(mockConnectionManager.disconnect).toHaveBeenCalledTimes(2);
    });
  });

  describe('Integration Scenarios', () => {
    it('should handle full lifecycle: connect, send, receive, shutdown', (done) => {
      service.connect();

      service.onMessage().subscribe((message) => {
        expect(message).toEqual({ Action: 'Response' } as any);
        service.shutdown();
        expect(mockConnectionManager.disconnect).toHaveBeenCalled();
        done();
      });

      service.send('TestAction', { data: 'test' });

      expect(mockConnectionManager.send).toHaveBeenCalled();

      messageSubject.next({ Action: 'Response' } as any);
    });

    it('should handle send before connect gracefully', () => {
      expect(() => service.send('TestAction')).not.toThrow();
      expect(mockConnectionManager.send).toHaveBeenCalled();
    });

    it('should handle rapid successive sends', () => {
      for (let i = 0; i < 100; i++) {
        service.send(`Action${i}`, { index: i });
      }
      expect(mockConnectionManager.send).toHaveBeenCalledTimes(100);
    });

    it('should handle concurrent message sending and receiving', (done) => {
      const receivedMessages: RawMessage[] = [];
      
      service.onMessage().subscribe((msg) => {
        receivedMessages.push(msg);
        if (receivedMessages.length === 3) {
          expect(receivedMessages.length).toBe(3);
          expect(mockConnectionManager.send).toHaveBeenCalledTimes(3);
          done();
        }
      });

      // Send and receive interleaved
      service.send('Action1');
      messageSubject.next({ Action: 'Response1' } as any);
      
      service.send('Action2');
      messageSubject.next({ Action: 'Response2' } as any);
      
      service.send('Action3');
      messageSubject.next({ Action: 'Response3' } as any);
    });
  });

  describe('Edge Cases and Error Scenarios', () => {
    it('should handle null action in send', () => {
      expect(() => service.send(null as any)).not.toThrow();
      expect(mockConnectionManager.send).toHaveBeenCalledWith({ Action: null } as any);
    });

    it('should handle undefined action in send', () => {
      expect(() => service.send(undefined as any)).not.toThrow();
      expect(mockConnectionManager.send).toHaveBeenCalledWith({ Action: undefined } as any);
    });

    it('should handle empty string action', () => {
      service.send('');
      expect(mockConnectionManager.send).toHaveBeenCalledWith({ Action: '' } as any);
    });

    it('should handle payload with null values', () => {
      service.send('TestAction', { key: null, value: undefined });
      expect(mockConnectionManager.send).toHaveBeenCalledWith({
        Action: 'TestAction',
        key: null,
        value: undefined,
      } as any);
    });

    it('should handle payload with circular references gracefully', () => {
      const circular: any = { Action: 'Test' };
      circular.self = circular;
      
      // This should not throw, but the send will have issues
      expect(() => service.send('CircularTest', circular)).not.toThrow();
    });

    it('should handle very large payloads', () => {
      const largePayload: Record<string, any> = {};
      for (let i = 0; i < 1000; i++) {
        largePayload[`key${i}`] = `value${i}`;
      }
      
      service.send('LargeAction', largePayload);
      expect(mockConnectionManager.send).toHaveBeenCalled();
    });

    it('should handle special characters in action names', () => {
      const specialActions = [
        'Action-With-Dashes',
        'Action_With_Underscores',
        'Action.With.Dots',
        'Action@With#Special$Chars',
      ];

      specialActions.forEach(action => {
        service.send(action);
        expect(mockConnectionManager.send).toHaveBeenCalledWith({ Action: action } as any);
      });
    });

    it('should handle payload with arrays', () => {
      service.send('ArrayAction', {
        numbers: [1, 2, 3],
        strings: ['a', 'b', 'c'],
        mixed: [1, 'two', true, null],
      });

      expect(mockConnectionManager.send).toHaveBeenCalled();
    });

    it('should handle payload with dates', () => {
      const testDate = new Date('2026-02-06');
      service.send('DateAction', { timestamp: testDate });
      
      expect(mockConnectionManager.send).toHaveBeenCalled();
    });

    it('should handle multiple connect attempts', () => {
      service.connect();
      service.connect();
      service.connect();
      
      expect(mockConnectionManager.connect).toHaveBeenCalledTimes(3);
    });

    it('should handle connect after shutdown', () => {
      service.connect();
      service.shutdown();
      service.connect();
      
      expect(mockConnectionManager.connect).toHaveBeenCalledTimes(2);
      expect(mockConnectionManager.disconnect).toHaveBeenCalledTimes(1);
    });

    it('should handle message stream completion', (done) => {
      let completedCalled = false;
      
      service.onMessage().subscribe({
        next: () => {},
        complete: () => {
          completedCalled = true;
        }
      });

      messageSubject.complete();
      
      setTimeout(() => {
        expect(completedCalled).toBe(true);
        done();
      }, 10);
    });

    it('should handle message stream errors', (done) => {
      let errorCalled = false;
      
      service.onMessage().subscribe({
        next: () => {},
        error: (err) => {
          errorCalled = true;
          expect(err).toBeDefined();
        }
      });

      messageSubject.error(new Error('Stream error'));
      
      setTimeout(() => {
        expect(errorCalled).toBe(true);
        done();
      }, 10);
    });
  });

  describe('Performance and Stress Tests', () => {
    it('should handle high-frequency message reception', (done) => {
      const messageCount = 1000;
      const receivedMessages: RawMessage[] = [];
      
      service.onMessage().subscribe((msg) => {
        receivedMessages.push(msg);
        if (receivedMessages.length === messageCount) {
          expect(receivedMessages.length).toBe(messageCount);
          done();
        }
      });

      for (let i = 0; i < messageCount; i++) {
        messageSubject.next({ Action: `Message${i}` } as any);
      }
    });

    it('should maintain message order', (done) => {
      const messageCount = 100;
      const receivedMessages: RawMessage[] = [];
      
      service.onMessage().subscribe((msg) => {
        receivedMessages.push(msg);
        if (receivedMessages.length === messageCount) {
          for (let i = 0; i < messageCount; i++) {
            expect((receivedMessages[i] as any).Action).toBe(`Message${i}`);
          }
          done();
        }
      });

      for (let i = 0; i < messageCount; i++) {
        messageSubject.next({ Action: `Message${i}` } as any);
      }
    });
  });

  describe('Type Safety and Validation', () => {
    it('should handle messages with different types', () => {
      const testMessages = [
        { Action: 'StringAction', data: 'string' },
        { Action: 'NumberAction', data: 123 },
        { Action: 'BooleanAction', data: true },
        { Action: 'ObjectAction', data: { nested: 'object' } },
        { Action: 'ArrayAction', data: [1, 2, 3] },
      ];

      testMessages.forEach(msg => {
        service.send(msg.Action, { data: msg.data });
        expect(mockConnectionManager.send).toHaveBeenCalledWith({
          Action: msg.Action,
          data: msg.data,
        } as any);
      });
    });

    it('should preserve payload property types', () => {
      const payload = {
        string: 'test',
        number: 42,
        boolean: true,
        nullValue: null,
        undefinedValue: undefined,
        object: { nested: 'value' },
        array: [1, 2, 3],
      };

      service.send('TypeTest', payload);
      
      const call = mockConnectionManager.send.calls.mostRecent();
      const sentMessage = call.args[0] as any;
      
      expect(sentMessage).toEqual({
        Action: 'TypeTest',
        ...payload,
      } as any);
    });
  });

  describe('Observable Subscription Management', () => {
    it('should allow unsubscribing from messages', () => {
      const receivedMessages: RawMessage[] = [];
      
      const subscription = service.onMessage().subscribe((msg) => {
        receivedMessages.push(msg);
      });

      messageSubject.next({ Action: 'Message1' } as any);
      subscription.unsubscribe();
      messageSubject.next({ Action: 'Message2' } as any);

      expect(receivedMessages.length).toBe(1);
      expect((receivedMessages[0] as any).Action).toBe('Message1');
    });

    it('should support late subscription to messages', (done) => {
      messageSubject.next({ Action: 'EarlyMessage' } as any);
      
      setTimeout(() => {
        service.onMessage().subscribe((msg) => {
          expect((msg as any).Action).toBe('LateMessage');
          done();
        });
        
        messageSubject.next({ Action: 'LateMessage' } as any);
      }, 10);
    });
  });
});

