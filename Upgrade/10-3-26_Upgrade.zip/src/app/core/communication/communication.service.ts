import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ConnectionManager } from './connection.manager';
import { RawMessage } from './raw-message';
import { LogoClickedEvent } from '@shui/core/utils/events.js';

/**
 * Application-level communication facade.
 *
 * Converts high-level intents (action + optional payload) into
 * Action-keyed JSON messages and delegates to ConnectionManager.
 */
@Injectable({ providedIn: 'root' })
export class CommunicationService {
  constructor(private readonly connection: ConnectionManager) {}

  /** Establish the WebView2 connection. Call once at bootstrap. */
  connect(): void {
    this.connection.connect();
  }

  /**
   * Send an action-keyed message to the backend.
   * @param action  - The `Action` field value (e.g. `'VerifyInstallationPrerequisite'`).
   * @param payload - Optional additional fields merged into the message object.
   */
  send(action: string, payload?: Record<string, unknown>): void {
    const message = { Action: action, ...payload };
    this.connection.send(message as RawMessage);
  }

  /** Observable stream of raw backend messages. */
  onMessage(): Observable<RawMessage> {
    return this.connection.messages$;
  }

  /** Graceful shutdown — removes the WebView2 event listener. */
  shutdown(): void {
    this.connection.disconnect();
  }
}

// make 2 classes one is message sender and one is message receiver 
// use message sender to send the LogoClickedEvent
// message receiver in one classs 
// create dependency of class to service to use 
// and receiver and sender hve dependency n connection mnager 

