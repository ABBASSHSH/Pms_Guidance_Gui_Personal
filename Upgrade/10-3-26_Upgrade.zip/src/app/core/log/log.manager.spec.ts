import { TestBed } from '@angular/core/testing';
import { LogManager } from './log.manager';
import { CommunicationService } from '../communication/communication.service';
import { LogLevel } from './log.models';

describe('LogManager', () => {
  let service: LogManager;
  let mockCommunicationService: jasmine.SpyObj<CommunicationService>;

  beforeEach(() => {
    mockCommunicationService = jasmine.createSpyObj('CommunicationService', [
      'send',
    ]);

    TestBed.configureTestingModule({
      providers: [
        LogManager,
        { provide: CommunicationService, useValue: mockCommunicationService },
      ],
    });

    service = TestBed.inject(LogManager);
  });

  describe('Initialization', () => {
    it('should create the service', () => {
      expect(service).toBeTruthy();
    });
  });

  describe('Logging Methods', () => {
    beforeEach(() => {
      spyOn(console, 'debug');
      spyOn(console, 'info');
      spyOn(console, 'warn');
      spyOn(console, 'error');
    });

    it('should log debug messages', () => {
      service.debug('TestSource', 'Debug message');

      expect(console.debug).toHaveBeenCalledWith(
        jasmine.stringContaining('[TestSource]: Debug message')
      );
    });

    it('should log info messages', () => {
      service.info('TestSource', 'Info message');

      expect(console.info).toHaveBeenCalledWith(
        jasmine.stringContaining('[TestSource]: Info message')
      );
    });

    it('should log warn messages', () => {
      service.warn('TestSource', 'Warning message');

      expect(console.warn).toHaveBeenCalledWith(
        jasmine.stringContaining('[TestSource]: Warning message')
      );
    });

    it('should log error messages', () => {
      service.error('TestSource', 'Error message');

      expect(console.error).toHaveBeenCalledWith(
        jasmine.stringContaining('[TestSource]: Error message')
      );
    });

    it('should handle undefined messages', () => {
      service.info('TestSource');

      expect(console.info).toHaveBeenCalledWith(
        jasmine.stringContaining('[TestSource]: ')
      );
    });
  });

  describe('Batching and Flushing', () => {
    it('should queue log entries', () => {
      service.debug('Source1', 'Message1');
      service.info('Source2', 'Message2');

      // Should not send yet (batch size not reached)
      expect(mockCommunicationService.send).not.toHaveBeenCalled();
    });

    it('should flush logs on explicit flush call', () => {
      service.debug('TestSource', 'Test message');
      service.flush();

      expect(mockCommunicationService.send).toHaveBeenCalledWith(
        'LogMessage',
        jasmine.objectContaining({ Message: '[debug] TestSource: Test message' })
      );
    });

    it('should auto-flush when batch size is reached', () => {
      // Create 25 log entries to trigger auto-flush
      for (let i = 0; i < 25; i++) {
        service.info(`Source${i}`, `Message${i}`);
      }

      expect(mockCommunicationService.send).toHaveBeenCalledTimes(25);
    });

    it('should clear queue after flushing', () => {
      service.info('TestSource', 'Message1');
      service.flush();

      mockCommunicationService.send.calls.reset();

      service.flush();

      // Should not send anything as queue is empty
      expect(mockCommunicationService.send).not.toHaveBeenCalled();
    });

    it('should send multiple messages on flush', () => {
      service.info('Source1', 'Message1');
      service.info('Source2', 'Message2');
      service.info('Source3', 'Message3');

      service.flush();

      expect(mockCommunicationService.send).toHaveBeenCalledTimes(3);
    });
  });

  describe('Log Level Filtering', () => {
    it('should log all levels by default (min level: debug)', () => {
      spyOn(console, 'debug');
      spyOn(console, 'info');
      spyOn(console, 'warn');
      spyOn(console, 'error');

      service.debug('Test', 'debug');
      service.info('Test', 'info');
      service.warn('Test', 'warn');
      service.error('Test', 'error');

      expect(console.debug).toHaveBeenCalledTimes(1);
      expect(console.info).toHaveBeenCalledTimes(1);
      expect(console.warn).toHaveBeenCalledTimes(1);
      expect(console.error).toHaveBeenCalledTimes(1);
    });
  });

  describe('Log Entry Structure', () => {
    it('should create log entries with correct structure', () => {
      service.info('TestSource', 'TestMessage');
      service.flush();

      expect(mockCommunicationService.send).toHaveBeenCalledWith(
        'LogMessage',
        jasmine.objectContaining({
          Message: '[info] TestSource: TestMessage',
        })
      );
    });

    it('should include timestamp in log entries', () => {
      spyOn(console, 'info');

      service.info('TestSource', 'TestMessage');

      const logCall = (console.info as jasmine.Spy).calls.mostRecent().args[0];

      expect(logCall).toContain('TestSource');
      expect(logCall).toContain('TestMessage');
    });
  });

  describe('Edge Cases', () => {
    it('should handle empty source', () => {
      spyOn(console, 'info');
      service.info('', 'Message');

      expect(console.info).toHaveBeenCalledWith(
        jasmine.stringContaining('[]: Message')
      );
    });

    it('should handle special characters in messages', () => {
      spyOn(console, 'info');
      const specialMessage = 'Message with "quotes" and \\backslashes\\';

      service.info('TestSource', specialMessage);

      expect(console.info).toHaveBeenCalledWith(
        jasmine.stringContaining(specialMessage)
      );
    });

    it('should handle very long messages', () => {
      const longMessage = 'A'.repeat(10000);
      expect(() => service.info('Test', longMessage)).not.toThrow();
    });

    it('should handle rapid consecutive logs', () => {
      spyOn(console, 'info');

      for (let i = 0; i < 100; i++) {
        service.info(`Source${i}`, `Message${i}`);
      }

      expect(console.info).toHaveBeenCalledTimes(100);
    });
  });

  describe('Integration with Communication Service', () => {
    it('should send logs with correct action name', () => {
      service.info('TestSource', 'TestMessage');
      service.flush();

      expect(mockCommunicationService.send).toHaveBeenCalledWith(
        'LogMessage',
        jasmine.any(Object)
      );
    });

    it('should handle communication service errors gracefully', () => {
      mockCommunicationService.send.and.throwError('Network error');

      expect(() => {
        service.info('Test', 'Message');
        service.flush();
      }).toThrow();
    });
  });

  describe('Advanced Batching Scenarios', () => {
    it('should handle flush with empty queue', () => {
      service.flush();
      expect(mockCommunicationService.send).not.toHaveBeenCalled();
    });

    it('should send exact number of messages when batch size is exactly reached', () => {
      for (let i = 0; i < 25; i++) {
        service.debug(`Source${i}`, `Message${i}`);
      }

      expect(mockCommunicationService.send).toHaveBeenCalledTimes(25);
    });

    it('should handle batch size + 1 (26 messages)', () => {
      mockCommunicationService.send.calls.reset();

      for (let i = 0; i < 26; i++) {
        service.info(`Source${i}`, `Message${i}`);
      }

      // First 25 auto-flushed, 1 remaining in queue
      expect(mockCommunicationService.send).toHaveBeenCalledTimes(25);

      service.flush();
      expect(mockCommunicationService.send).toHaveBeenCalledTimes(26);
    });

    it('should handle multiple auto-flushes (50+ messages)', () => {
      mockCommunicationService.send.calls.reset();

      for (let i = 0; i < 50; i++) {
        service.warn(`Source${i}`, `Message${i}`);
      }

      // 2 auto-flushes (25 each)
      expect(mockCommunicationService.send).toHaveBeenCalledTimes(50);
    });

    it('should handle multiple auto-flushes with remainder', () => {
      mockCommunicationService.send.calls.reset();

      for (let i = 0; i < 53; i++) {
        service.error(`Source${i}`, `Message${i}`);
      }

      // 2 auto-flushes (50 total), 3 remaining
      expect(mockCommunicationService.send).toHaveBeenCalledTimes(50);

      service.flush();
      expect(mockCommunicationService.send).toHaveBeenCalledTimes(53);
    });

    it('should maintain message order across flushes', () => {
      const messages: string[] = [];
      mockCommunicationService.send.and.callFake((action: string, payload: any) => {
        messages.push(payload.Message);
      });

      for (let i = 0; i < 30; i++) {
        service.info(`Source${i}`, `Message${i}`);
      }

      service.flush();

      for (let i = 0; i < 30; i++) {
        expect(messages[i]).toBe(`[info] Source${i}: Message${i}`);
      }
    });
  });

  describe('Log Level Filtering (Advanced)', () => {
    beforeEach(() => {
      spyOn(console, 'debug');
      spyOn(console, 'info');
      spyOn(console, 'warn');
      spyOn(console, 'error');
    });

    it('should respect min level debug (all levels logged)', () => {
      // Default is debug, so all should be logged
      service.debug('Test', 'debug');
      service.info('Test', 'info');
      service.warn('Test', 'warn');
      service.error('Test', 'error');

      expect(console.debug).toHaveBeenCalledTimes(1);
      expect(console.info).toHaveBeenCalledTimes(1);
      expect(console.warn).toHaveBeenCalledTimes(1);
      expect(console.error).toHaveBeenCalledTimes(1);
    });

    it('should not log below minimum level', () => {
      // Since we cannot set minLevel via public API, test the behavior
      // This documents that filtering is handled internally by allowed() method
      service.debug('Test', 'Should be logged');
      expect(console.debug).toHaveBeenCalledWith(
        jasmine.stringContaining('[Test]: Should be logged')
      );
    });
  });

  describe('Message Content Handling', () => {
    beforeEach(() => {
      spyOn(console, 'info');
    });

    it('should handle null message (converted to empty string)', () => {
      service.info('TestSource', undefined);
      expect(console.info).toHaveBeenCalledWith(
        jasmine.stringContaining('[TestSource]: ')
      );
    });

    it('should handle message with newlines', () => {
      const multilineMessage = 'Line1\nLine2\nLine3';
      service.info('Test', multilineMessage);

      expect(console.info).toHaveBeenCalledWith(
        jasmine.stringContaining(multilineMessage)
      );
    });

    it('should handle message with tabs', () => {
      const tabbedMessage = 'Column1\tColumn2\tColumn3';
      service.info('Test', tabbedMessage);

      expect(console.info).toHaveBeenCalledWith(
        jasmine.stringContaining(tabbedMessage)
      );
    });

    it('should handle Unicode characters', () => {
      const unicodeMessage = '🎉 Unicode test 中文 العربية';
      service.info('Test', unicodeMessage);

      expect(console.info).toHaveBeenCalledWith(
        jasmine.stringContaining(unicodeMessage)
      );
    });

    it('should handle HTML-like strings', () => {
      const htmlMessage = '<div>Test &amp; content</div>';
      service.info('Test', htmlMessage);

      expect(console.info).toHaveBeenCalledWith(
        jasmine.stringContaining(htmlMessage)
      );
    });

    it('should handle JSON-like strings', () => {
      const jsonMessage = '{"key": "value", "number": 123}';
      service.info('Test', jsonMessage);

      expect(console.info).toHaveBeenCalledWith(
        jasmine.stringContaining(jsonMessage)
      );
    });
  });

  describe('Source Handling', () => {
    beforeEach(() => {
      spyOn(console, 'info');
    });

    it('should handle very long source names', () => {
      const longSource = 'A'.repeat(1000);
      service.info(longSource, 'Message');

      expect(console.info).toHaveBeenCalledWith(
        jasmine.stringContaining(longSource)
      );
    });

    it('should handle source with special characters', () => {
      const specialSource = 'Source:With:Colons::And::Stuff';
      service.info(specialSource, 'Message');

      expect(console.info).toHaveBeenCalledWith(
        jasmine.stringContaining(specialSource)
      );
    });

    it('should handle source with spaces', () => {
      const spacedSource = 'My Component Name';
      service.info(spacedSource, 'Message');

      expect(console.info).toHaveBeenCalledWith(
        jasmine.stringContaining(spacedSource)
      );
    });
  });

  describe('Timestamp Generation', () => {
    it('should generate ISO 8601 timestamps', () => {
      spyOn(console, 'info');
      service.info('Test', 'Message');

      // Console format is: [source]: message (no timestamp in console output)
      const logCall = (console.info as jasmine.Spy).calls.mostRecent().args[0];
      expect(logCall).toContain('Test');
      expect(logCall).toContain('Message');
    });

    it('should generate unique timestamps for rapid logs', () => {
      const messages: string[] = [];
      spyOn(console, 'info').and.callFake((msg: string) => {
        messages.push(msg);
      });

      for (let i = 0; i < 10; i++) {
        service.info('Test', `Message${i}`);
      }

      expect(messages.length).toBe(10);
    });
  });

  describe('Performance Tests', () => {
    it('should handle high-frequency logging (1000 messages)', () => {
      spyOn(console, 'info');
      mockCommunicationService.send.calls.reset();

      const startTime = Date.now();
      for (let i = 0; i < 1000; i++) {
        service.info(`Source${i}`, `Message${i}`);
      }
      const endTime = Date.now();

      expect(console.info).toHaveBeenCalledTimes(1000);
      // Should complete in reasonable time (< 1 second)
      expect(endTime - startTime).toBeLessThan(1000);
    });

    it('should not accumulate memory with repeated flush cycles', () => {
      mockCommunicationService.send.calls.reset();

      for (let cycle = 0; cycle < 10; cycle++) {
        for (let i = 0; i < 25; i++) {
          service.info(`Cycle${cycle}`, `Message${i}`);
        }
        // Auto-flush happens at 25
      }

      // 10 cycles * 25 messages = 250 total
      expect(mockCommunicationService.send).toHaveBeenCalledTimes(250);
    });
  });

  describe('Concurrency and Edge Timing', () => {
    it('should handle flush during logging', () => {
      service.info('Test1', 'Message1');
      service.flush();
      service.info('Test2', 'Message2');
      service.flush();

      expect(mockCommunicationService.send).toHaveBeenCalledTimes(2);
    });

    it('should handle multiple flushes in sequence', () => {
      service.info('Test', 'Message');
      service.flush();
      service.flush();
      service.flush();

      // Should only send once (queue empty after first flush)
      expect(mockCommunicationService.send).toHaveBeenCalledTimes(1);
    });

    it('should handle interleaved logging and flushing', () => {
      mockCommunicationService.send.calls.reset();

      service.info('Test1', 'Message1');
      service.flush();
      service.info('Test2', 'Message2');
      service.info('Test3', 'Message3');
      service.flush();
      service.info('Test4', 'Message4');

      expect(mockCommunicationService.send).toHaveBeenCalledTimes(3);

      service.flush();
      expect(mockCommunicationService.send).toHaveBeenCalledTimes(4);
    });
  });

  describe('Log Entry Structure Validation', () => {
    it('should create entries with all required fields', () => {
      service.info('TestSource', 'TestMessage');
      service.flush();

      const call = mockCommunicationService.send.calls.mostRecent();
      expect(call.args[0]).toBe('LogMessage');
      expect(call.args[1]).toEqual(
        jasmine.objectContaining({
          Message: '[info] TestSource: TestMessage',
        })
      );
    });

    it('should preserve message content exactly', () => {
      const exactMessage = 'Exact\tContent\nWith\rSpecial\\Characters"Quotes"';
      service.info('Test', exactMessage);
      service.flush();

      expect(mockCommunicationService.send).toHaveBeenCalledWith(
        'LogMessage',
        jasmine.objectContaining({
          Message: `[info] Test: ${exactMessage}`,
        })
      );
    });
  });

  describe('Error Scenarios', () => {
    it('should throw if communication service throws during flush', () => {
      mockCommunicationService.send.and.throwError('Network failure');

      service.info('Test', 'Message');

      expect(() => service.flush()).toThrow();
    });

    it('should recover after communication error', () => {
      mockCommunicationService.send.and.throwError('First error');

      service.info('Test1', 'Message1');
      try {
        service.flush();
      } catch (e) {
        // Expected error
      }

      // Reset mock to not throw
      mockCommunicationService.send.and.stub();
      mockCommunicationService.send.calls.reset();

      // Should work normally after error
      service.info('Test2', 'Message2');
      service.flush();

      expect(mockCommunicationService.send).toHaveBeenCalledTimes(1);
    });
  });

  describe('Mixed Log Levels', () => {
    beforeEach(() => {
      spyOn(console, 'debug');
      spyOn(console, 'info');
      spyOn(console, 'warn');
      spyOn(console, 'error');
      mockCommunicationService.send.calls.reset();
    });

    it('should handle all log levels in sequence', () => {
      service.debug('Test', 'Debug');
      service.info('Test', 'Info');
      service.warn('Test', 'Warn');
      service.error('Test', 'Error');

      expect(console.debug).toHaveBeenCalledTimes(1);
      expect(console.info).toHaveBeenCalledTimes(1);
      expect(console.warn).toHaveBeenCalledTimes(1);
      expect(console.error).toHaveBeenCalledTimes(1);

      service.flush();
      expect(mockCommunicationService.send).toHaveBeenCalledTimes(4);
    });

    it('should handle random mix of log levels', () => {
      const levels = ['debug', 'info', 'warn', 'error'];
      const methods: { [key: string]: (s: string, m: string) => void } = {
        debug: (s, m) => service.debug(s, m),
        info: (s, m) => service.info(s, m),
        warn: (s, m) => service.warn(s, m),
        error: (s, m) => service.error(s, m),
      };

      let callCount = 0;
      for (let i = 0; i < 20; i++) {
        const level = levels[Math.floor(Math.random() * levels.length)];
        methods[level]('Test', `Message${i}`);
        callCount++;
      }

      const totalCalls =
        (console.debug as jasmine.Spy).calls.count() +
        (console.info  as jasmine.Spy).calls.count() +
        (console.warn  as jasmine.Spy).calls.count() +
        (console.error as jasmine.Spy).calls.count();
      expect(totalCalls).toBe(20);
    });
  });
});
