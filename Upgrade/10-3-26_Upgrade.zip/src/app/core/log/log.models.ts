/** Severity level used internally by LogManager. */
export type LogLevel = 'debug' | 'info' | 'warn' | 'error';

/** A single log record held in the queue before flushing. */
export interface LogEntry {
  readonly ts: string;
  readonly level: LogLevel;
  readonly source: string;
  readonly message: string;
}

export interface ILog {
  debug(source: string, message?: string): void;
  info(source: string, message?: string): void;
  warn(source: string, message?: string): void;
  error(source: string, message?: string): void;
  flush(): void;
}