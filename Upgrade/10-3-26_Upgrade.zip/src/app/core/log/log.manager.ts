import { Injectable } from '@angular/core';
import { LogEntry, LogLevel ,ILog} from './log.models';
import { CommunicationService } from '../communication/communication.service';

const LOG_LEVEL_ORDER: readonly LogLevel[] = ['debug', 'info', 'warn', 'error'];

@Injectable({ providedIn: 'root' })
export class LogManager implements ILog {
  private readonly queue: LogEntry[] = [];
  private readonly minLevel: LogLevel = 'debug';
  private readonly maxBatchSize = 25;

  constructor(private readonly comm: CommunicationService) {}

  debug(source: string, message?: string): void {
    this.write('debug', source, message);
  }

  info(source: string, message?: string): void {
    this.write('info', source, message);
  }

  warn(source: string, message?: string): void {
    this.write('warn', source, message);
  }

  error(source: string, message?: string): void {
    this.write('error', source, message);
  }

  flush(): void {
    if (!this.queue.length) return;

    const entries = [...this.queue];
    this.queue.length = 0;

    for (const e of entries) {
      this.comm.send('LogMessage', { Message: `[${e.level}] ${e.source}: ${e.message}` });
    }
  }

  // ---- private ----

  private write(level: LogLevel, source: string, message?: string): void {
    if (!this.allowed(level)) return;

    const entry: LogEntry = {
      ts: new Date().toISOString(),
      level,
      source,
      message: message ?? '',
    };

    this.queue.push(entry);
    console[level](`[${entry.source}]: ${entry.message}`);

    if (this.queue.length >= this.maxBatchSize) {
      this.flush();
    }
  }

  private allowed(level: LogLevel): boolean {
    return LOG_LEVEL_ORDER.indexOf(level) >= LOG_LEVEL_ORDER.indexOf(this.minLevel);
  }
}
