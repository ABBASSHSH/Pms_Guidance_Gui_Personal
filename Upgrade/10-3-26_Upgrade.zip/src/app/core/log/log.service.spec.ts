import { TestBed } from '@angular/core/testing';
import { LogService } from './log.service';
import { LogManager } from './log.manager';

describe('LogService', () => {
  let service: LogService;
  let mockLogManager: jasmine.SpyObj<LogManager>;

  beforeEach(() => {
    mockLogManager = jasmine.createSpyObj('LogManager', [
      'debug',
      'info',
      'warn',
      'error',
      'flush',
    ]);

    TestBed.configureTestingModule({
      providers: [
        LogService,
        { provide: LogManager, useValue: mockLogManager },
      ],
    });

    service = TestBed.inject(LogService);
  });

  describe('Initialization', () => {
    it('should create the service', () => {
      expect(service).toBeTruthy();
    });

    it('should inject LogManager dependency', () => {
      expect(service['manager']).toBe(mockLogManager);
    });
  });

  describe('Debug Method', () => {
    it('should call LogManager.debug with formatted event and message', () => {
      service.debug('TestSource', 'TestEvent', 'Test debug message');

      expect(mockLogManager.debug).toHaveBeenCalledWith(
        'TestSource',
        'TestEvent: Test debug message'
      );
    });

    it('should include event parameter in the formatted message', () => {
      service.debug('Source', 'EventName', 'Message');

      expect(mockLogManager.debug).toHaveBeenCalledWith('Source', 'EventName: Message');
      // Verify it's only called with 2 arguments (source + formatted message)
      const calls = mockLogManager.debug.calls.mostRecent();
      expect(calls.args.length).toBe(2);
    });

    it('should handle empty message', () => {
      service.debug('Source', 'Event', '');

      expect(mockLogManager.debug).toHaveBeenCalledWith('Source', 'Event: ');
    });

    it('should handle special characters in message', () => {
      const specialMessage = 'Test "quotes" and \\backslashes\\ 🎉';
      service.debug('Source', 'Event', specialMessage);

      expect(mockLogManager.debug).toHaveBeenCalledWith(
        'Source',
        `Event: ${specialMessage}`
      );
    });

    it('should handle very long messages', () => {
      const longMessage = 'A'.repeat(10000);
      service.debug('Source', 'Event', longMessage);

      expect(mockLogManager.debug).toHaveBeenCalledWith('Source', `Event: ${longMessage}`);
    });

    it('should call manager exactly once per invocation', () => {
      service.debug('Source', 'Event', 'Message');

      expect(mockLogManager.debug).toHaveBeenCalledTimes(1);
    });
  });

  describe('Info Method', () => {
    it('should call LogManager.info with formatted event and message', () => {
      service.info('TestSource', 'TestEvent', 'Test info message');

      expect(mockLogManager.info).toHaveBeenCalledWith(
        'TestSource',
        'TestEvent: Test info message'
      );
    });

    it('should include event parameter in the formatted message', () => {
      service.info('Source', 'EventName', 'Message');

      expect(mockLogManager.info).toHaveBeenCalledWith('Source', 'EventName: Message');
      // Verify it's only called with 2 arguments (source + formatted message)
      const calls = mockLogManager.info.calls.mostRecent();
      expect(calls.args.length).toBe(2);
    });

    it('should handle empty message', () => {
      service.info('Source', 'Event', '');

      expect(mockLogManager.info).toHaveBeenCalledWith('Source', 'Event: ');
    });

    it('should handle Unicode messages', () => {
      const unicodeMessage = '中文 العربية Ελληνικά';
      service.info('Source', 'Event', unicodeMessage);

      expect(mockLogManager.info).toHaveBeenCalledWith('Source', `Event: ${unicodeMessage}`);
    });

    it('should handle message with newlines', () => {
      const multilineMessage = 'Line1\nLine2\nLine3';
      service.info('Source', 'Event', multilineMessage);

      expect(mockLogManager.info).toHaveBeenCalledWith(
        'Source',
        `Event: ${multilineMessage}`
      );
    });

    it('should call manager exactly once per invocation', () => {
      service.info('Source', 'Event', 'Message');

      expect(mockLogManager.info).toHaveBeenCalledTimes(1);
    });
  });

  describe('Warn Method', () => {
    it('should call LogManager.warn with formatted event and message', () => {
      service.warn('TestSource', 'TestEvent', 'Test warning message');

      expect(mockLogManager.warn).toHaveBeenCalledWith(
        'TestSource',
        'TestEvent: Test warning message'
      );
    });

    it('should include event parameter in the formatted message', () => {
      service.warn('Source', 'EventName', 'Message');

      expect(mockLogManager.warn).toHaveBeenCalledWith('Source', 'EventName: Message');
      // Verify it's only called with 2 arguments (source + formatted message)
      const calls = mockLogManager.warn.calls.mostRecent();
      expect(calls.args.length).toBe(2);
    });

    it('should handle empty message', () => {
      service.warn('Source', 'Event', '');

      expect(mockLogManager.warn).toHaveBeenCalledWith('Source', 'Event: ');
    });

    it('should handle message with tabs', () => {
      const tabbedMessage = 'Col1\tCol2\tCol3';
      service.warn('Source', 'Event', tabbedMessage);

      expect(mockLogManager.warn).toHaveBeenCalledWith('Source', `Event: ${tabbedMessage}`);
    });

    it('should handle JSON-like messages', () => {
      const jsonMessage = '{"error": "Something went wrong", "code": 500}';
      service.warn('Source', 'Event', jsonMessage);

      expect(mockLogManager.warn).toHaveBeenCalledWith('Source', `Event: ${jsonMessage}`);
    });

    it('should call manager exactly once per invocation', () => {
      service.warn('Source', 'Event', 'Message');

      expect(mockLogManager.warn).toHaveBeenCalledTimes(1);
    });
  });

  describe('Error Method', () => {
    it('should call LogManager.error with formatted event and message', () => {
      service.error('TestSource', 'TestEvent', 'Test error message');

      expect(mockLogManager.error).toHaveBeenCalledWith(
        'TestSource',
        'TestEvent: Test error message'
      );
    });

    it('should include event parameter in the formatted message', () => {
      service.error('Source', 'EventName', 'Message');

      expect(mockLogManager.error).toHaveBeenCalledWith('Source', 'EventName: Message');
      // Verify it's only called with 2 arguments (source + formatted message)
      const calls = mockLogManager.error.calls.mostRecent();
      expect(calls.args.length).toBe(2);
    });

    it('should handle empty message', () => {
      service.error('Source', 'Event', '');

      expect(mockLogManager.error).toHaveBeenCalledWith('Source', 'Event: ');
    });

    it('should handle stack traces', () => {
      const stackTrace = `Error: Something failed
        at Object.<anonymous> (file.ts:10:15)
        at Module._compile (internal/modules:123:45)`;
      service.error('Source', 'Event', stackTrace);

      expect(mockLogManager.error).toHaveBeenCalledWith('Source', `Event: ${stackTrace}`);
    });

    it('should handle HTML content in error messages', () => {
      const htmlError = '<div class="error">Error occurred</div>';
      service.error('Source', 'Event', htmlError);

      expect(mockLogManager.error).toHaveBeenCalledWith('Source', `Event: ${htmlError}`);
    });

    it('should call manager exactly once per invocation', () => {
      service.error('Source', 'Event', 'Message');

      expect(mockLogManager.error).toHaveBeenCalledTimes(1);
    });
  });

  describe('Flush Method', () => {
    it('should call LogManager.flush', () => {
      service.flush();

      expect(mockLogManager.flush).toHaveBeenCalled();
    });

    it('should call flush exactly once per invocation', () => {
      service.flush();

      expect(mockLogManager.flush).toHaveBeenCalledTimes(1);
    });

    it('should allow multiple flush calls', () => {
      service.flush();
      service.flush();
      service.flush();

      expect(mockLogManager.flush).toHaveBeenCalledTimes(3);
    });

    it('should not pass any parameters to flush', () => {
      service.flush();

      expect(mockLogManager.flush).toHaveBeenCalledWith();
    });
  });

  describe('Source Parameter Handling', () => {
    it('should handle empty source string', () => {
      service.info('', 'Event', 'Message');

      expect(mockLogManager.info).toHaveBeenCalledWith('', 'Event: Message');
    });

    it('should handle source with spaces', () => {
      service.info('My Component Name', 'Event', 'Message');

      expect(mockLogManager.info).toHaveBeenCalledWith(
        'My Component Name',
        'Event: Message'
      );
    });

    it('should handle source with special characters', () => {
      const specialSource = 'Component:Name::With::Colons';
      service.info(specialSource, 'Event', 'Message');

      expect(mockLogManager.info).toHaveBeenCalledWith(
        specialSource,
        'Event: Message'
      );
    });

    it('should handle very long source names', () => {
      const longSource = 'A'.repeat(1000);
      service.info(longSource, 'Event', 'Message');

      expect(mockLogManager.info).toHaveBeenCalledWith(longSource, 'Event: Message');
    });

    it('should preserve source exactly as provided', () => {
      const exactSource = 'Exact\tSource\nWith\rSpecial\\Chars';
      service.info(exactSource, 'Event', 'Message');

      expect(mockLogManager.info).toHaveBeenCalledWith(exactSource, 'Event: Message');
    });
  });

  describe('Event Parameter Handling', () => {
    it('should include event in the formatted message passed to manager', () => {
      service.debug('Source', 'IgnoredEvent', 'Message');

      const calls = mockLogManager.debug.calls.all();
      expect(calls[0].args).toEqual(['Source', 'IgnoredEvent: Message']);
      expect(calls[0].args.length).toBe(2);
    });

    it('should prefix each method message with the event name', () => {
      service.info('Source', 'SomeEvent', 'Message1');
      service.warn('Source', 'AnotherEvent', 'Message2');
      service.error('Source', 'ErrorEvent', 'Message3');

      expect(mockLogManager.info).toHaveBeenCalledWith('Source', 'SomeEvent: Message1');
      expect(mockLogManager.warn).toHaveBeenCalledWith('Source', 'AnotherEvent: Message2');
      expect(mockLogManager.error).toHaveBeenCalledWith('Source', 'ErrorEvent: Message3');
    });

    it('should handle empty event string', () => {
      service.info('Source', '', 'Message');

      expect(mockLogManager.info).toHaveBeenCalledWith('Source', ': Message');
    });
  });

  describe('Multiple Method Calls', () => {
    it('should handle sequential calls to same method', () => {
      service.info('Source1', 'Event', 'Message1');
      service.info('Source2', 'Event', 'Message2');
      service.info('Source3', 'Event', 'Message3');

      expect(mockLogManager.info).toHaveBeenCalledTimes(3);
      expect(mockLogManager.info).toHaveBeenCalledWith('Source1', 'Event: Message1');
      expect(mockLogManager.info).toHaveBeenCalledWith('Source2', 'Event: Message2');
      expect(mockLogManager.info).toHaveBeenCalledWith('Source3', 'Event: Message3');
    });

    it('should handle calls to different methods', () => {
      service.debug('Source', 'Event', 'Debug message');
      service.info('Source', 'Event', 'Info message');
      service.warn('Source', 'Event', 'Warn message');
      service.error('Source', 'Event', 'Error message');

      expect(mockLogManager.debug).toHaveBeenCalledTimes(1);
      expect(mockLogManager.info).toHaveBeenCalledTimes(1);
      expect(mockLogManager.warn).toHaveBeenCalledTimes(1);
      expect(mockLogManager.error).toHaveBeenCalledTimes(1);
    });

    it('should handle interleaved method calls', () => {
      service.debug('S1', 'E', 'M1');
      service.info('S2', 'E', 'M2');
      service.debug('S3', 'E', 'M3');
      service.warn('S4', 'E', 'M4');
      service.info('S5', 'E', 'M5');

      expect(mockLogManager.debug).toHaveBeenCalledTimes(2);
      expect(mockLogManager.info).toHaveBeenCalledTimes(2);
      expect(mockLogManager.warn).toHaveBeenCalledTimes(1);
    });
  });

  describe('High-Frequency Logging', () => {
    it('should handle rapid successive calls', () => {
      for (let i = 0; i < 100; i++) {
        service.info(`Source${i}`, 'Event', `Message${i}`);
      }

      expect(mockLogManager.info).toHaveBeenCalledTimes(100);
    });

    it('should handle rapid calls to different methods', () => {
      const methods = [
        () => service.debug('S', 'E', 'M'),
        () => service.info('S', 'E', 'M'),
        () => service.warn('S', 'E', 'M'),
        () => service.error('S', 'E', 'M'),
      ];

      for (let i = 0; i < 100; i++) {
        methods[i % 4]();
      }

      expect(mockLogManager.debug).toHaveBeenCalledTimes(25);
      expect(mockLogManager.info).toHaveBeenCalledTimes(25);
      expect(mockLogManager.warn).toHaveBeenCalledTimes(25);
      expect(mockLogManager.error).toHaveBeenCalledTimes(25);
    });

    it('should maintain call order for rapid logging', () => {
      const messages: string[] = [];
      mockLogManager.info.and.callFake((source: string, message: string) => {
        messages.push(message);
      });

      for (let i = 0; i < 50; i++) {
        service.info('Source', 'Event', `Message${i}`);
      }

      for (let i = 0; i < 50; i++) {
        expect(messages[i]).toBe(`Event: Message${i}`);
      }
    });
  });

  describe('Integration Scenarios', () => {
    it('should handle complete logging workflow', () => {
      service.debug('Component', 'Init', 'Initializing');
      service.info('Component', 'Load', 'Loading data');
      service.info('Component', 'Process', 'Processing');
      service.warn('Component', 'Warning', 'Slow response');
      service.error('Component', 'Error', 'Failed operation');
      service.flush();

      expect(mockLogManager.debug).toHaveBeenCalledTimes(1);
      expect(mockLogManager.info).toHaveBeenCalledTimes(2);
      expect(mockLogManager.warn).toHaveBeenCalledTimes(1);
      expect(mockLogManager.error).toHaveBeenCalledTimes(1);
      expect(mockLogManager.flush).toHaveBeenCalledTimes(1);
    });

    it('should support logging with periodic flushes', () => {
      for (let batch = 0; batch < 5; batch++) {
        for (let i = 0; i < 10; i++) {
          service.info(`Batch${batch}`, 'Event', `Message${i}`);
        }
        service.flush();
      }

      expect(mockLogManager.info).toHaveBeenCalledTimes(50);
      expect(mockLogManager.flush).toHaveBeenCalledTimes(5);
    });

    it('should handle mixed logging and flushing', () => {
      service.debug('S1', 'E', 'M1');
      service.flush();
      service.info('S2', 'E', 'M2');
      service.warn('S3', 'E', 'M3');
      service.flush();
      service.error('S4', 'E', 'M4');
      service.flush();

      expect(mockLogManager.flush).toHaveBeenCalledTimes(3);
    });
  });

  describe('Edge Cases', () => {
    it('should handle logging before any configuration', () => {
      // Service should work immediately after creation
      expect(() => service.info('Test', 'Event', 'Message')).not.toThrow();
    });

    it('should handle flush before any logging', () => {
      expect(() => service.flush()).not.toThrow();
    });

    it('should handle alternating log levels', () => {
      service.debug('S', 'E', 'Debug');
      service.error('S', 'E', 'Error');
      service.debug('S', 'E', 'Debug');
      service.error('S', 'E', 'Error');

      expect(mockLogManager.debug).toHaveBeenCalledTimes(2);
      expect(mockLogManager.error).toHaveBeenCalledTimes(2);
    });

    it('should handle identical consecutive messages', () => {
      service.info('Same', 'Event', 'Same message');
      service.info('Same', 'Event', 'Same message');
      service.info('Same', 'Event', 'Same message');

      expect(mockLogManager.info).toHaveBeenCalledTimes(3);
      expect(mockLogManager.info).toHaveBeenCalledWith('Same', 'Event: Same message');
    });
  });

  describe('Performance Tests', () => {
    it('should execute 1000 log calls quickly', () => {
      const startTime = Date.now();

      for (let i = 0; i < 1000; i++) {
        service.info(`Source${i}`, 'Event', `Message${i}`);
      }

      const endTime = Date.now();
      const duration = endTime - startTime;

      expect(mockLogManager.info).toHaveBeenCalledTimes(1000);
      expect(duration).toBeLessThan(100); // Should complete in < 100ms
    });

    it('should handle mixed operations under load', () => {
      for (let i = 0; i < 250; i++) {
        service.debug(`S${i}`, 'E', `M${i}`);
        service.info(`S${i}`, 'E', `M${i}`);
        service.warn(`S${i}`, 'E', `M${i}`);
        service.error(`S${i}`, 'E', `M${i}`);
      }

      expect(mockLogManager.debug).toHaveBeenCalledTimes(250);
      expect(mockLogManager.info).toHaveBeenCalledTimes(250);
      expect(mockLogManager.warn).toHaveBeenCalledTimes(250);
      expect(mockLogManager.error).toHaveBeenCalledTimes(250);
    });
  });

  describe('Error Handling', () => {
    it('should propagate errors from LogManager.debug', () => {
      mockLogManager.debug.and.throwError('Debug error');

      expect(() => service.debug('S', 'E', 'M')).toThrow();
    });

    it('should propagate errors from LogManager.info', () => {
      mockLogManager.info.and.throwError('Info error');

      expect(() => service.info('S', 'E', 'M')).toThrow();
    });

    it('should propagate errors from LogManager.warn', () => {
      mockLogManager.warn.and.throwError('Warn error');

      expect(() => service.warn('S', 'E', 'M')).toThrow();
    });

    it('should propagate errors from LogManager.error', () => {
      mockLogManager.error.and.throwError('Error error');

      expect(() => service.error('S', 'E', 'M')).toThrow();
    });

    it('should propagate errors from LogManager.flush', () => {
      mockLogManager.flush.and.throwError('Flush error');

      expect(() => service.flush()).toThrow();
    });
  });

  describe('Service as Facade', () => {
    it('should act as a thin wrapper around LogManager', () => {
      // Service should have minimal logic, just delegation
      service.debug('S', 'E', 'M');
      service.info('S', 'E', 'M');
      service.warn('S', 'E', 'M');
      service.error('S', 'E', 'M');
      service.flush();

      // Each method should be called exactly once
      expect(mockLogManager.debug).toHaveBeenCalledTimes(1);
      expect(mockLogManager.info).toHaveBeenCalledTimes(1);
      expect(mockLogManager.warn).toHaveBeenCalledTimes(1);
      expect(mockLogManager.error).toHaveBeenCalledTimes(1);
      expect(mockLogManager.flush).toHaveBeenCalledTimes(1);
    });

    it('should format event and message before passing to manager', () => {
      const source = 'Original Source';
      const event = 'OriginalEvent';
      const message = 'Original Message';

      service.info(source, event, message);

      expect(mockLogManager.info).toHaveBeenCalledWith(source, `${event}: ${message}`);
    });

    it('should provide a consistent interface', () => {
      // All logging methods should have the same signature
      expect(() => service.debug('S', 'E', 'M')).not.toThrow();
      expect(() => service.info('S', 'E', 'M')).not.toThrow();
      expect(() => service.warn('S', 'E', 'M')).not.toThrow();
      expect(() => service.error('S', 'E', 'M')).not.toThrow();
    });
  });
});
