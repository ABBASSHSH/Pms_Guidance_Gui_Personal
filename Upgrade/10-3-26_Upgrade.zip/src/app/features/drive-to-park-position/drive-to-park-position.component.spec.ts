import { ComponentFixture, TestBed } from '@angular/core/testing';
import { DriveToParkPositionComponent } from './drive-to-park-position.component';
import { UiStateManagementService } from '../../core/update/ui-state-management-service';
import { CommunicationService } from '../../core/communication/communication.service';
import { LogService } from '../../core/log/log.service';
import { I18nService } from '../../core/i18n';

describe('DriveToParkPositionComponent', () => {
  let component: DriveToParkPositionComponent;
  let fixture: ComponentFixture<DriveToParkPositionComponent>;
  let mockUiStateManagementService: jasmine.SpyObj<UiStateManagementService>;
  let mockCommService: jasmine.SpyObj<CommunicationService>;
  let mockLogService: jasmine.SpyObj<LogService>;
  let mockI18nService: jasmine.SpyObj<I18nService>;

  beforeEach(async () => {
    mockUiStateManagementService = jasmine.createSpyObj('UiStateManagementService', [
      'next',
      'setActive',
      'complete',
    ]);

    mockCommService = jasmine.createSpyObj('CommunicationService', ['send', 'connect', 'shutdown']);

    mockLogService = jasmine.createSpyObj('LogService', [
      'debug',
      'info',
      'warn',
      'error',
      'flush',
    ]);

    mockI18nService = jasmine.createSpyObj('I18nService', ['translate', 'setLanguage']);
    mockI18nService.translate.and.callFake((key: string) => key);

    await TestBed.configureTestingModule({
      imports: [DriveToParkPositionComponent],
      providers: [
        { provide: UiStateManagementService, useValue: mockUiStateManagementService },
        { provide: CommunicationService, useValue: mockCommService },
        { provide: LogService, useValue: mockLogService },
        { provide: I18nService, useValue: mockI18nService },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(DriveToParkPositionComponent);
    component = fixture.componentInstance;
  });

  describe('Component Lifecycle', () => {
    it('should create', () => {
      expect(component).toBeTruthy();
    });

    it('should have correct source identifier', () => {
      expect((component as any).source).toBe('DriveToParkPositionComponent');
    });

    it('should log on initialization', () => {
      fixture.detectChanges();

      expect(mockLogService.info).toHaveBeenCalledWith(
        'DriveToParkPositionComponent',
        'enter',
        'View entered'
      );
      expect(mockLogService.flush).toHaveBeenCalled();
    });

    it('should log on destroy', () => {
      fixture.detectChanges();
      mockLogService.info.calls.reset();
      mockLogService.flush.calls.reset();

      component.ngOnDestroy();

      expect(mockLogService.info).toHaveBeenCalledWith(
        'DriveToParkPositionComponent',
        'leave',
        'View left'
      );
      expect(mockLogService.flush).toHaveBeenCalled();
    });

    it('should log exactly once on initialization', () => {
      fixture.detectChanges();

      expect(mockLogService.info).toHaveBeenCalledTimes(1);
      expect(mockLogService.flush).toHaveBeenCalledTimes(1);
    });

    it('should log exactly once on destroy', () => {
      fixture.detectChanges();
      mockLogService.info.calls.reset();
      mockLogService.flush.calls.reset();

      component.ngOnDestroy();

      expect(mockLogService.info).toHaveBeenCalledTimes(1);
      expect(mockLogService.flush).toHaveBeenCalledTimes(1);
    });
  });

  describe('User Interactions', () => {
    beforeEach(() => {
      fixture.detectChanges();
      mockLogService.info.calls.reset();
      mockLogService.warn.calls.reset();
      mockLogService.flush.calls.reset();
      mockUiStateManagementService.next.calls.reset();
    });

    describe('onProceed', () => {
      it('should handle proceed action', () => {
        component.onProceed();

        expect(mockLogService.info).toHaveBeenCalledWith(
          'DriveToParkPositionComponent',
          'proceed',
          'Proceed clicked'
        );
        expect(mockUiStateManagementService.next).toHaveBeenCalledTimes(1);
        expect(mockLogService.flush).toHaveBeenCalled();
      });

      it('should call UiStateManagementService.next when proceed is clicked', () => {
        component.onProceed();

        expect(mockUiStateManagementService.next).toHaveBeenCalled();
      });

      it('should log before calling state update', () => {
        component.onProceed();

        const infoCallOrder = mockLogService.info.calls.first();
        const nextCallOrder = mockUiStateManagementService.next.calls.first();

        expect(infoCallOrder).toBeDefined();
        expect(nextCallOrder).toBeDefined();
      });

      it('should flush logs after proceed action', () => {
        component.onProceed();

        expect(mockLogService.flush).toHaveBeenCalledTimes(1);
      });

      it('should log info level for proceed action', () => {
        component.onProceed();

        expect(mockLogService.info).toHaveBeenCalled();
        expect(mockLogService.warn).not.toHaveBeenCalled();
        expect(mockLogService.error).not.toHaveBeenCalled();
      });
    });

    describe('onCancel', () => {
      it('should handle cancel action', () => {
        component.onCancel();

        expect(mockLogService.warn).toHaveBeenCalledWith(
          'DriveToParkPositionComponent',
          'cancel',
          'Cancel clicked'
        );
        expect(mockLogService.flush).toHaveBeenCalled();
      });

      it('should not call UiStateManagementService.next when cancel is clicked', () => {
        component.onCancel();

        expect(mockUiStateManagementService.next).not.toHaveBeenCalled();
      });

      it('should flush logs after cancel action', () => {
        component.onCancel();

        expect(mockLogService.flush).toHaveBeenCalledTimes(1);
      });

      it('should log warning level for cancel action', () => {
        component.onCancel();

        expect(mockLogService.warn).toHaveBeenCalled();
        expect(mockLogService.info).not.toHaveBeenCalled();
        expect(mockLogService.error).not.toHaveBeenCalled();
      });

      it('should log exactly once when cancel is clicked', () => {
        component.onCancel();

        expect(mockLogService.warn).toHaveBeenCalledTimes(1);
        expect(mockLogService.flush).toHaveBeenCalledTimes(1);
      });

      it('should send CloseApp to backend on cancel', () => {
        component.onCancel();

        expect(mockCommService.send).toHaveBeenCalledWith('CloseApp');
      });
    });
  });

  describe('Service Dependencies', () => {
    it('should inject UiStateManagementService', () => {
      expect((component as any).uiStateUpdate).toBe(mockUiStateManagementService);
    });

    it('should inject LogService', () => {
      expect((component as any).log).toBe(mockLogService);
    });
  });

  describe('Template Integration', () => {
    beforeEach(() => {
      fixture.detectChanges();
      mockLogService.info.calls.reset();
      mockLogService.warn.calls.reset();
      mockLogService.flush.calls.reset();
      mockUiStateManagementService.next.calls.reset();
    });

    it('should render the component template', () => {
      const compiled = fixture.nativeElement;
      expect(compiled).toBeTruthy();
    });

    it('should have content panel', () => {
      const compiled = fixture.nativeElement;
      const contentPanel = compiled.querySelector('.content-panel');
      expect(contentPanel).toBeTruthy();
    });

    it('should display title', () => {
      const compiled = fixture.nativeElement;
      const title = compiled.querySelector('.title');
      expect(title).toBeTruthy();
      // Mock returns translation key
      expect(title.textContent).toContain('driveToPark.title');
    });

    it('should display instruction texts', () => {
      const compiled = fixture.nativeElement;
      const texts = compiled.querySelectorAll('.text');
      expect(texts.length).toBeGreaterThan(0);
    });

    it('should have proceed button', () => {
      const compiled = fixture.nativeElement;
      const buttons = compiled.querySelectorAll('sh-button[color="primary"]');
      expect(buttons.length).toBeGreaterThan(0);
    });

    it('should have cancel button', () => {
      const compiled = fixture.nativeElement;
      const buttons = compiled.querySelectorAll('sh-button[color="secondary"]');
      expect(buttons.length).toBeGreaterThan(0);
    });

    it('should call onProceed when proceed button is clicked', () => {
      spyOn(component, 'onProceed');
      const compiled = fixture.nativeElement;
      const proceedButton = compiled.querySelector('sh-button[color="primary"]');
      
      if (proceedButton) {
        proceedButton.click();
        expect(component.onProceed).toHaveBeenCalled();
      }
    });

    it('should call onCancel when cancel button is clicked', () => {
      spyOn(component, 'onCancel');
      const compiled = fixture.nativeElement;
      const cancelButton = compiled.querySelector('sh-button[color="secondary"]');
      
      if (cancelButton) {
        cancelButton.click();
        expect(component.onCancel).toHaveBeenCalled();
      }
    });

    it('should display info bar', () => {
      const compiled = fixture.nativeElement;
      const infoBar = compiled.querySelector('.info-bar');
      expect(infoBar).toBeTruthy();
    });

    it('should display footer with copyright', () => {
      const compiled = fixture.nativeElement;
      const footer = compiled.querySelector('.footer');
      expect(footer).toBeTruthy();
      // Mock returns translation key
      expect(footer.textContent).toContain('common.copyright');
    });
  });

  describe('Error Handling', () => {
    it('should handle multiple proceed clicks', () => {
      fixture.detectChanges();
      mockLogService.info.calls.reset();
      mockLogService.flush.calls.reset();

      component.onProceed();
      component.onProceed();

      expect(mockUiStateManagementService.next).toHaveBeenCalledTimes(2);
      expect(mockLogService.info).toHaveBeenCalledTimes(2);
    });

    it('should handle multiple cancel clicks', () => {
      fixture.detectChanges();
      mockLogService.warn.calls.reset();
      mockLogService.flush.calls.reset();

      component.onCancel();
      component.onCancel();

      expect(mockLogService.warn).toHaveBeenCalledTimes(2);
      expect(mockLogService.flush).toHaveBeenCalledTimes(2);
    });

    it('should handle proceed and cancel in sequence', () => {
      fixture.detectChanges();
      mockLogService.info.calls.reset();
      mockLogService.warn.calls.reset();
      mockLogService.flush.calls.reset();

      component.onProceed();
      component.onCancel();

      expect(mockLogService.info).toHaveBeenCalledTimes(1);
      expect(mockLogService.warn).toHaveBeenCalledTimes(1);
      expect(mockUiStateManagementService.next).toHaveBeenCalledTimes(1);
    });
  });

  describe('Component State', () => {
    it('should maintain source identifier throughout lifecycle', () => {
      const initialSource = (component as any).source;
      fixture.detectChanges();
      const afterInitSource = (component as any).source;
      component.ngOnDestroy();
      const afterDestroySource = (component as any).source;

      expect(initialSource).toBe('DriveToParkPositionComponent');
      expect(afterInitSource).toBe('DriveToParkPositionComponent');
      expect(afterDestroySource).toBe('DriveToParkPositionComponent');
    });

    it('should not modify services during lifecycle', () => {
      fixture.detectChanges();
      const stateService = (component as any).uiStateUpdate;
      const logService = (component as any).log;

      component.onProceed();
      component.onCancel();
      component.ngOnDestroy();

      expect((component as any).uiStateUpdate).toBe(stateService);
      expect((component as any).log).toBe(logService);
    });
  });
});

