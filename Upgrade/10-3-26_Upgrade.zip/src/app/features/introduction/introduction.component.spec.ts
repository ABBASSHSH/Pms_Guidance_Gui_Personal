import { ComponentFixture, TestBed } from '@angular/core/testing';
import { IntroductionComponent } from './introduction.component';
import { UiStateManagementService } from '../../core/update/ui-state-management-service';
import { CommunicationService } from '../../core/communication/communication.service';
import { LogService } from '../../core/log/log.service';
import { I18nService } from '../../core/i18n';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

describe('IntroductionComponent', () => {
  let component: IntroductionComponent;
  let fixture: ComponentFixture<IntroductionComponent>;
  let mockStateService: jasmine.SpyObj<UiStateManagementService>;
  let mockCommService: jasmine.SpyObj<CommunicationService>;
  let mockLogService: jasmine.SpyObj<LogService>;
  let mockI18nService: jasmine.SpyObj<I18nService>;

  beforeEach(async () => {
    // Create mock services
    mockStateService = jasmine.createSpyObj('UiStateManagementService', ['next']);
    mockCommService = jasmine.createSpyObj('CommunicationService', ['send', 'connect', 'shutdown']);
    mockLogService = jasmine.createSpyObj('LogService', ['info', 'warn', 'flush']);
    mockI18nService = jasmine.createSpyObj('I18nService', ['translate', 'setLanguage']);
    mockI18nService.translate.and.callFake((key: string) => key);

    await TestBed.configureTestingModule({
      imports: [IntroductionComponent],
      providers: [
        { provide: UiStateManagementService, useValue: mockStateService },
        { provide: CommunicationService, useValue: mockCommService },
        { provide: LogService, useValue: mockLogService },
        { provide: I18nService, useValue: mockI18nService }
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();

    fixture = TestBed.createComponent(IntroductionComponent);
    component = fixture.componentInstance;
  });

  afterEach(() => {
    fixture.destroy();
  });

  describe('Component Initialization', () => {
    it('should create the component', () => {
      expect(component).toBeTruthy();
    });

    it('should have correct component metadata', () => {
      expect(component instanceof IntroductionComponent).toBeTrue();
    });
  });

  describe('ngOnInit', () => {
    it('should log info message when component initializes', () => {
      // Act
      fixture.detectChanges(); // triggers ngOnInit

      // Assert
      expect(mockLogService.info).toHaveBeenCalledWith(
        'IntroductionComponent',
        'enter',
        'View entered'
      );
    });

    it('should flush logs after initialization', () => {
      // Act
      fixture.detectChanges();

      // Assert
      expect(mockLogService.flush).toHaveBeenCalled();
    });

    it('should log before flushing', () => {
      // Act
      fixture.detectChanges();

      // Assert - verify call order
      expect(mockLogService.info).toHaveBeenCalledBefore(mockLogService.flush);
    });

    it('should only log once during initialization', () => {
      // Act
      fixture.detectChanges();

      // Assert
      expect(mockLogService.info).toHaveBeenCalledTimes(1);
      expect(mockLogService.flush).toHaveBeenCalledTimes(1);
    });
  });

  describe('ngOnDestroy', () => {
    it('should log info message when component is destroyed', () => {
      // Arrange
      fixture.detectChanges();
      mockLogService.info.calls.reset();
      mockLogService.flush.calls.reset();

      // Act
      component.ngOnDestroy();

      // Assert
      expect(mockLogService.info).toHaveBeenCalledWith(
        'IntroductionComponent',
        'leave',
        'View left'
      );
    });

    it('should flush logs after destruction', () => {
      // Arrange
      fixture.detectChanges();
      mockLogService.flush.calls.reset();

      // Act
      component.ngOnDestroy();

      // Assert
      expect(mockLogService.flush).toHaveBeenCalled();
    });

    it('should log before flushing on destroy', () => {
      // Arrange
      fixture.detectChanges();
      mockLogService.info.calls.reset();
      mockLogService.flush.calls.reset();

      // Act
      component.ngOnDestroy();

      // Assert - verify call order
      expect(mockLogService.info).toHaveBeenCalledBefore(mockLogService.flush);
    });
  });

  describe('onProceed', () => {
    beforeEach(() => {
      fixture.detectChanges();
      // Reset spies after ngOnInit
      mockLogService.info.calls.reset();
      mockLogService.flush.calls.reset();
    });

    it('should log info message when proceed is clicked', () => {
      // Act
      component.onProceed();

      // Assert
      expect(mockLogService.info).toHaveBeenCalledWith(
        'IntroductionComponent',
        'proceed',
        'Proceed clicked'
      );
    });

    it('should flush logs after proceed is clicked', () => {
      // Act
      component.onProceed();

      // Assert
      expect(mockLogService.flush).toHaveBeenCalled();
    });

    it('should call uiStateUpdate.next() to advance to next step', () => {
      // Act
      component.onProceed();

      // Assert
      expect(mockStateService.next).toHaveBeenCalled();
    });

    it('should call uiStateUpdate.next() exactly once', () => {
      // Act
      component.onProceed();

      // Assert
      expect(mockStateService.next).toHaveBeenCalledTimes(1);
    });

    it('should log and flush before advancing to next step', () => {
      // Act
      component.onProceed();

      // Assert - verify call order
      expect(mockLogService.info).toHaveBeenCalledBefore(mockLogService.flush);
      expect(mockLogService.flush).toHaveBeenCalledBefore(mockStateService.next);
    });

    it('should handle multiple proceed clicks', () => {
      // Act
      component.onProceed();
      component.onProceed();
      component.onProceed();

      // Assert
      expect(mockLogService.info).toHaveBeenCalledTimes(3);
      expect(mockLogService.flush).toHaveBeenCalledTimes(3);
      expect(mockStateService.next).toHaveBeenCalledTimes(3);
    });

    it('should not throw error when proceed is called', () => {
      // Act & Assert
      expect(() => component.onProceed()).not.toThrow();
    });
  });

  describe('onCancel', () => {
    beforeEach(() => {
      fixture.detectChanges();
      // Reset spies after ngOnInit
      mockLogService.warn.calls.reset();
      mockLogService.flush.calls.reset();
    });

    it('should log warning message when cancel is clicked', () => {
      // Act
      component.onCancel();

      // Assert
      expect(mockLogService.warn).toHaveBeenCalledWith(
        'IntroductionComponent',
        'cancel',
        'Cancel clicked'
      );
    });

    it('should flush logs after cancel is clicked', () => {
      // Act
      component.onCancel();

      // Assert
      expect(mockLogService.flush).toHaveBeenCalled();
    });

    it('should log before flushing on cancel', () => {
      // Act
      component.onCancel();

      // Assert - verify call order
      expect(mockLogService.warn).toHaveBeenCalledBefore(mockLogService.flush);
    });

    it('should NOT call uiStateUpdate.next() when cancel is clicked', () => {
      // Act
      component.onCancel();

      // Assert
      expect(mockStateService.next).not.toHaveBeenCalled();
    });

    it('should handle multiple cancel clicks', () => {
      // Act
      component.onCancel();
      component.onCancel();

      // Assert
      expect(mockLogService.warn).toHaveBeenCalledTimes(2);
      expect(mockLogService.flush).toHaveBeenCalledTimes(2);
      expect(mockStateService.next).not.toHaveBeenCalled();
    });

    it('should not throw error when cancel is called', () => {
      // Act & Assert
      expect(() => component.onCancel()).not.toThrow();
    });

    it('should send CloseApp to backend when cancel is clicked', () => {
      component.onCancel();

      expect(mockCommService.send).toHaveBeenCalledWith('CloseApp');
    });
  });

  describe('Lifecycle Integration', () => {
    it('should log in correct order: init → proceed → destroy', () => {
      // Arrange
      const callOrder: string[] = [];
      mockLogService.info.and.callFake((source, action) => {
        callOrder.push(`${source}:${action}`);
      });
      mockLogService.warn.and.callFake((source, action) => {
        callOrder.push(`${source}:${action}`);
      });

      // Act
      fixture.detectChanges(); // ngOnInit
      component.onProceed();
      component.ngOnDestroy(); // ngOnDestroy

      // Assert
      expect(callOrder).toEqual([
        'IntroductionComponent:enter',
        'IntroductionComponent:proceed',
        'IntroductionComponent:leave'
      ]);
    });

    it('should log in correct order: init → cancel → destroy', () => {
      // Arrange
      const callOrder: string[] = [];
      mockLogService.info.and.callFake((source, action) => {
        callOrder.push(`info:${action}`);
      });
      mockLogService.warn.and.callFake((source, action) => {
        callOrder.push(`warn:${action}`);
      });

      // Act
      fixture.detectChanges(); // ngOnInit
      component.onCancel();
      component.ngOnDestroy(); // ngOnDestroy

      // Assert
      expect(callOrder).toEqual([
        'info:enter',
        'warn:cancel',
        'info:leave'
      ]);
    });

    it('should call flush after each logging operation', () => {
      // Act
      fixture.detectChanges(); // ngOnInit -> flush
      mockLogService.flush.calls.reset();
      
      component.onProceed(); // proceed -> flush
      component.onCancel(); // cancel -> flush
      component.ngOnDestroy(); // destroy -> flush

      // Assert
      expect(mockLogService.flush).toHaveBeenCalledTimes(3);
    });
  });

  describe('Component Properties', () => {
    it('should have source property set to "IntroductionComponent"', () => {
      // Access private property for testing
      const source = (component as any).source;
      expect(source).toBe('IntroductionComponent');
    });

    it('should inject UiStateManagementService', () => {
      const stateService = (component as any).uiStateUpdate;
      expect(stateService).toBeDefined();
      expect(stateService).toBe(mockStateService);
    });

    it('should inject LogService', () => {
      const logService = (component as any).log;
      expect(logService).toBeDefined();
      expect(logService).toBe(mockLogService);
    });
  });

  describe('Error Handling', () => {
    it('should propagate errors from uiStateUpdate.next()', () => {
      // Arrange
      mockStateService.next.and.throwError('State error');
      fixture.detectChanges();
      mockLogService.info.calls.reset();
      mockLogService.flush.calls.reset();

      // Act & Assert - error should propagate
      expect(() => component.onProceed()).toThrowError('State error');
      // But logging should have happened before the error
      expect(mockLogService.info).toHaveBeenCalledWith(
        'IntroductionComponent',
        'proceed',
        'Proceed clicked'
      );
      expect(mockLogService.flush).toHaveBeenCalled();
    });
  });

  describe('State Management', () => {
    it('should not modify state on initialization', () => {
      // Act
      fixture.detectChanges();

      // Assert
      expect(mockStateService.next).not.toHaveBeenCalled();
    });

    it('should not modify state on cancel', () => {
      // Arrange
      fixture.detectChanges();

      // Act
      component.onCancel();

      // Assert
      expect(mockStateService.next).not.toHaveBeenCalled();
    });

    it('should only modify state on proceed', () => {
      // Arrange
      fixture.detectChanges();

      // Act
      component.onProceed();

      // Assert
      expect(mockStateService.next).toHaveBeenCalledTimes(1);
    });
  });

  describe('Component Template Integration', () => {
    it('should render without errors', () => {
      // Act
      fixture.detectChanges();

      // Assert
      const compiled = fixture.nativeElement;
      expect(compiled).toBeTruthy();
    });

    it('should allow proceed button clicks', () => {
      // Arrange
      fixture.detectChanges();
      spyOn(component, 'onProceed');

      // Act
      component.onProceed();

      // Assert
      expect(component.onProceed).toHaveBeenCalled();
    });

    it('should allow cancel button clicks', () => {
      // Arrange
      fixture.detectChanges();
      spyOn(component, 'onCancel');

      // Act
      component.onCancel();

      // Assert
      expect(component.onCancel).toHaveBeenCalled();
    });
  });

  describe('Memory Leaks Prevention', () => {
    it('should call ngOnDestroy when component is destroyed', () => {
      // Arrange
      fixture.detectChanges();
      spyOn(component, 'ngOnDestroy').and.callThrough();

      // Act
      component.ngOnDestroy();

      // Assert
      expect(component.ngOnDestroy).toHaveBeenCalled();
    });

    it('should not retain references after destroy', () => {
      // Arrange
      fixture.detectChanges();

      // Act
      component.ngOnDestroy();
      mockLogService.info.calls.reset();

      // Try to call methods after destroy (should still work but log)
      component.onProceed();

      // Assert - component still functional but logged
      expect(mockLogService.info).toHaveBeenCalled();
    });
  });

  describe('Logging Consistency', () => {
    it('should always use same source identifier', () => {
      // Act
      fixture.detectChanges();
      component.onProceed();
      component.onCancel();

      // Assert
      const infoCalls = mockLogService.info.calls.all();
      const warnCalls = mockLogService.warn.calls.all();
      
      infoCalls.forEach(call => {
        expect(call.args[0]).toBe('IntroductionComponent');
      });
      
      warnCalls.forEach(call => {
        expect(call.args[0]).toBe('IntroductionComponent');
      });
    });

    it('should use descriptive action names', () => {
      // Act
      fixture.detectChanges();
      component.onProceed();
      component.onCancel();
      fixture.destroy();

      // Assert - check all action names are meaningful
      expect(mockLogService.info).toHaveBeenCalledWith(
        jasmine.any(String), 
        'enter', 
        jasmine.any(String)
      );
      expect(mockLogService.info).toHaveBeenCalledWith(
        jasmine.any(String), 
        'proceed', 
        jasmine.any(String)
      );
      expect(mockLogService.warn).toHaveBeenCalledWith(
        jasmine.any(String), 
        'cancel', 
        jasmine.any(String)
      );
      expect(mockLogService.info).toHaveBeenCalledWith(
        jasmine.any(String), 
        'leave', 
        jasmine.any(String)
      );
    });

    it('should provide meaningful log messages', () => {
      // Act
      fixture.detectChanges();
      component.onProceed();
      component.onCancel();
      fixture.destroy();

      // Assert - check messages are descriptive
      expect(mockLogService.info).toHaveBeenCalledWith(
        jasmine.any(String), 
        jasmine.any(String), 
        'View entered'
      );
      expect(mockLogService.info).toHaveBeenCalledWith(
        jasmine.any(String), 
        jasmine.any(String), 
        'Proceed clicked'
      );
      expect(mockLogService.warn).toHaveBeenCalledWith(
        jasmine.any(String), 
        jasmine.any(String), 
        'Cancel clicked'
      );
      expect(mockLogService.info).toHaveBeenCalledWith(
        jasmine.any(String), 
        jasmine.any(String), 
        'View left'
      );
    });
  });
});

