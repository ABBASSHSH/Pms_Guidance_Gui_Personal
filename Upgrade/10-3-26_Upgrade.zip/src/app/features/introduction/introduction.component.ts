
import { Component, CUSTOM_ELEMENTS_SCHEMA, OnDestroy, OnInit } from '@angular/core';
import { UiStateManagementService } from '../../core/update/ui-state-management-service';
import { CommunicationService } from '../../core/communication/communication.service';
import { LogService } from '../../core/log/log.service';
import { TranslatePipe } from '../../core/i18n';

@Component({
    selector: 'app-introduction',
    imports: [TranslatePipe],
    templateUrl: './introduction.component.html',
    styleUrls: ['./introduction.component.css'],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})

export class IntroductionComponent implements OnInit, OnDestroy {
  private readonly source = 'IntroductionComponent';

  constructor(
    private readonly uiStateUpdate: UiStateManagementService,
    private readonly comm: CommunicationService,
    private readonly log: LogService
  ) {}

  ngOnInit(): void {
    this.log.info(this.source, 'enter', 'View entered');
    this.log.flush();
  }

  ngOnDestroy(): void {
    this.log.info(this.source, 'leave', 'View left');
    this.log.flush();
  }

  onProceed(): void {
    this.log.info(this.source, 'proceed', 'Proceed clicked');
    this.log.flush();
    this.uiStateUpdate.next();
  }

  onCancel(): void {
    this.log.warn(this.source, 'cancel', 'Cancel clicked');
    this.comm.send('CloseApp');
    this.log.flush();
  }
}
