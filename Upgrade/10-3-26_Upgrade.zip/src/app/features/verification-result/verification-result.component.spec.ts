import { ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { BehaviorSubject } from 'rxjs';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

import { VerificationResultComponent } from './verification-result.component';
import { UiStateManagementService } from '../../core/update/ui-state-management-service';
import { CommunicationService } from '../../core/communication/communication.service';
import { LogService } from '../../core/log/log.service';
import { I18nService } from '../../core/i18n';
import { PrereqStatus } from '../../core/update/update.models';

describe('VerificationResultComponent', () => {
  let component: VerificationResultComponent;
  let fixture: ComponentFixture<VerificationResultComponent>;
  let mockStateService: jasmine.SpyObj<UiStateManagementService>;
  let mockCommService: jasmine.SpyObj<CommunicationService>;
  let mockLogService: jasmine.SpyObj<LogService>;
  let mockI18nService: jasmine.SpyObj<I18nService>;
  let prereqSubject: BehaviorSubject<PrereqStatus>;

  beforeEach(async () => {
    prereqSubject = new BehaviorSubject<PrereqStatus>(PrereqStatus.OK);

    mockStateService = jasmine.createSpyObj('UiStateManagementService', ['next'], {
      prereqStatus$: prereqSubject.asObservable(),
    });

    mockCommService = jasmine.createSpyObj('CommunicationService', ['send', 'connect', 'shutdown']);

    mockLogService = jasmine.createSpyObj('LogService', ['info', 'debug', 'warn', 'error', 'flush']);

    mockI18nService = jasmine.createSpyObj('I18nService', ['translate', 'setLanguage']);
    mockI18nService.translate.and.callFake((key: string) => key);

    await TestBed.configureTestingModule({
      imports: [VerificationResultComponent],
      providers: [
        { provide: UiStateManagementService, useValue: mockStateService },
        { provide: CommunicationService, useValue: mockCommService },
        { provide: LogService, useValue: mockLogService },
        { provide: I18nService, useValue: mockI18nService },
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    }).compileComponents();

    fixture = TestBed.createComponent(VerificationResultComponent);
    component = fixture.componentInstance;
  });

  afterEach(() => {
    fixture.destroy();
  });

  describe('Component Initialization', () => {
    it('should create', () => {
      expect(component).toBeTruthy();
    });

    it('should have vm$ observable defined', () => {
      expect(component.vm$).toBeDefined();
    });

    it('should inject UiStateManagementService', () => {
      expect(component['uiStateUpdate']).toBe(mockStateService);
    });

    it('should inject LogService', () => {
      expect(component['log']).toBe(mockLogService);
    });
  });

  describe('vm$ Observable - OK status', () => {
    it('should map prereqStatus to OK with isOk true', fakeAsync(() => {
      prereqSubject.next(PrereqStatus.OK);
      fixture.detectChanges();
      tick();

      let vmData: any;
      component.vm$.subscribe(vm => (vmData = vm));
      tick();

      expect(vmData.prereqStatus).toBe('OK');
      expect(vmData.isOk).toBe(true);
    }));

    it('should set isOk to true when prereqStatus is OK', fakeAsync(() => {
      prereqSubject.next(PrereqStatus.OK);
      tick();

      let vmData: any;
      component.vm$.subscribe(vm => (vmData = vm));
      tick();

      expect(vmData.isOk).toBe(true);
    }));
  });

  describe('vm$ Observable - Not Ok status', () => {
    it('should map prereqStatus to Not Ok with isOk false', fakeAsync(() => {
      prereqSubject.next(PrereqStatus.NotOk);
      tick();

      let vmData: any;
      component.vm$.subscribe(vm => (vmData = vm));
      tick();

      expect(vmData.prereqStatus).toBe('Not Ok');
      expect(vmData.isOk).toBe(false);
    }));

    it('should set isOk to false when prereqStatus is Not Ok', fakeAsync(() => {
      prereqSubject.next(PrereqStatus.NotOk);
      tick();

      let vmData: any;
      component.vm$.subscribe(vm => (vmData = vm));
      tick();

      expect(vmData.isOk).toBe(false);
    }));
  });

  describe('vm$ Observable - undefined status', () => {
    it('should have isOk false for unexpected status', fakeAsync(() => {
      prereqSubject.next('Pending' as any);
      tick();

      let vmData: any;
      component.vm$.subscribe(vm => (vmData = vm));
      tick();

      expect(vmData.prereqStatus).toBe('Pending');
      expect(vmData.isOk).toBe(false);
    }));
  });

  describe('vm$ Observable - Reactive updates', () => {
    it('should emit new values when state changes', fakeAsync(() => {
      const emittedValues: any[] = [];
      component.vm$.subscribe(vm => emittedValues.push(vm));

      prereqSubject.next(PrereqStatus.OK);
      tick();

      prereqSubject.next(PrereqStatus.NotOk);
      tick();

      expect(emittedValues.length).toBeGreaterThan(1);
      expect(emittedValues[emittedValues.length - 1].prereqStatus).toBe('Not Ok');
    }));
  });

  describe('onProceedInstall()', () => {
    it('should log info message', () => {
      component.onProceedInstall();

      expect(mockLogService.info).toHaveBeenCalledWith(
        'VerificationResultComponent',
        'proceed',
        'Proceed with installation clicked'
      );
    });

    it('should call uiStateUpdate.next()', () => {
      component.onProceedInstall();

      expect(mockStateService.next).toHaveBeenCalled();
    });

    it('should call uiStateUpdate.next() with no arguments', () => {
      component.onProceedInstall();

      expect(mockStateService.next).toHaveBeenCalledWith();
    });

    it('should flush logs before calling next', () => {
      const callOrder: string[] = [];
      mockLogService.info.and.callFake(() => callOrder.push('log'));
      mockLogService.flush.and.callFake(() => callOrder.push('flush'));
      mockStateService.next.and.callFake(() => callOrder.push('next'));

      component.onProceedInstall();

      expect(callOrder).toEqual(['log', 'flush', 'next']);
    });
  });

  describe('onCancel()', () => {
    it('should log info message', () => {
      component.onCancel();

      expect(mockLogService.info).toHaveBeenCalledWith(
        'VerificationResultComponent',
        'cancel',
        'Cancel clicked'
      );
    });

    it('should not call uiStateUpdate.next()', () => {
      component.onCancel();

      expect(mockStateService.next).not.toHaveBeenCalled();
    });

    it('should send CloseApp to backend on cancel', () => {
      component.onCancel();

      expect(mockCommService.send).toHaveBeenCalledWith('CloseApp');
    });

    it('should flush logs before sending CloseApp', () => {
      const callOrder: string[] = [];
      mockLogService.info.and.callFake(() => callOrder.push('log'));
      mockLogService.flush.and.callFake(() => callOrder.push('flush'));
      mockCommService.send.and.callFake(() => callOrder.push('send'));

      component.onCancel();

      expect(callOrder).toEqual(['log', 'flush', 'send']);
    });
  });

  describe('onOk()', () => {
    it('should log info message', () => {
      component.onOk();

      expect(mockLogService.info).toHaveBeenCalledWith(
        'VerificationResultComponent',
        'ok',
        'OK clicked'
      );
    });

    it('should not call uiStateUpdate.next()', () => {
      component.onOk();

      expect(mockStateService.next).not.toHaveBeenCalled();
    });

    it('should flush logs', () => {
      component.onOk();

      expect(mockLogService.flush).toHaveBeenCalledTimes(1);
    });
  });

  describe('onShowReport()', () => {
    it('should log info message', () => {
      component.onShowReport();

      expect(mockLogService.info).toHaveBeenCalledWith(
        'VerificationResultComponent',
        'showReport',
        'Show report clicked'
      );
    });

    it('should not call uiStateUpdate.next()', () => {
      component.onShowReport();

      expect(mockStateService.next).not.toHaveBeenCalled();
    });

    it('should flush logs', () => {
      component.onShowReport();

      expect(mockLogService.flush).toHaveBeenCalledTimes(1);
    });
  });

  describe('Button Actions - Multiple Calls', () => {
    it('should handle multiple onProceedInstall calls', () => {
      component.onProceedInstall();
      component.onProceedInstall();
      component.onProceedInstall();

      expect(mockStateService.next).toHaveBeenCalledTimes(3);
      expect(mockLogService.info).toHaveBeenCalledTimes(3);
    });

    it('should handle multiple onCancel calls', () => {
      component.onCancel();
      component.onCancel();

      expect(mockLogService.info).toHaveBeenCalledTimes(2);
    });

    it('should handle multiple onOk calls', () => {
      component.onOk();
      component.onOk();

      expect(mockLogService.info).toHaveBeenCalledTimes(2);
    });

    it('should handle multiple onShowReport calls', () => {
      component.onShowReport();
      component.onShowReport();

      expect(mockLogService.info).toHaveBeenCalledTimes(2);
    });
  });

  describe('Logging Behavior', () => {
    it('should use VerificationResultComponent as source for all logs', () => {
      component.onProceedInstall();
      component.onCancel();
      component.onOk();
      component.onShowReport();

      const calls = mockLogService.info.calls.all();
      calls.forEach(call => {
        expect(call.args[0]).toBe('VerificationResultComponent');
      });
    });

    it('should use a specific event string per action', () => {
      component.onProceedInstall();
      component.onCancel();
      component.onOk();
      component.onShowReport();

      const calls = mockLogService.info.calls.all();
      expect(calls[0].args[1]).toBe('proceed');
      expect(calls[1].args[1]).toBe('cancel');
      expect(calls[2].args[1]).toBe('ok');
      expect(calls[3].args[1]).toBe('showReport');
    });
  });

  describe('Integration Tests', () => {
    it('should work correctly when status changes from OK to Not Ok', fakeAsync(() => {
      let currentVm: any;
      component.vm$.subscribe(vm => (currentVm = vm));

      prereqSubject.next(PrereqStatus.OK);
      tick();
      expect(currentVm.isOk).toBe(true);

      prereqSubject.next(PrereqStatus.NotOk);
      tick();
      expect(currentVm.isOk).toBe(false);
    }));

    it('should work correctly when status changes from Not Ok to OK', fakeAsync(() => {
      let currentVm: any;
      component.vm$.subscribe(vm => (currentVm = vm));

      prereqSubject.next(PrereqStatus.NotOk);
      tick();
      expect(currentVm.isOk).toBe(false);

      prereqSubject.next(PrereqStatus.OK);
      tick();
      expect(currentVm.isOk).toBe(true);
    }));

    it('should continue to work after multiple button clicks', fakeAsync(() => {
      component.onProceedInstall();
      component.onCancel();
      component.onOk();
      component.onShowReport();

      let currentVm: any;
      component.vm$.subscribe(vm => (currentVm = vm));

      prereqSubject.next(PrereqStatus.OK);
      tick();

      expect(currentVm.isOk).toBe(true);
      expect(mockLogService.info).toHaveBeenCalledTimes(4);
    }));
  });
});

