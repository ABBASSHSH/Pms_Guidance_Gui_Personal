import { ComponentFixture, TestBed } from '@angular/core/testing';
import { SavePatientImagesComponent } from './save-patient-images.component';
import { UiStateManagementService } from '../../core/update/ui-state-management-service';
import { CommunicationService } from '../../core/communication/communication.service';
import { LogService } from '../../core/log/log.service';
import { I18nService } from '../../core/i18n';

describe('SavePatientImagesComponent', () => {
  let component: SavePatientImagesComponent;
  let fixture: ComponentFixture<SavePatientImagesComponent>;
  let mockUiStateManagementService: jasmine.SpyObj<UiStateManagementService>;
  let mockCommService: jasmine.SpyObj<CommunicationService>;
  let mockLogService: jasmine.SpyObj<LogService>;
  let mockI18nService: jasmine.SpyObj<I18nService>;

  beforeEach(async () => {
    mockUiStateManagementService = jasmine.createSpyObj('UiStateManagementService', [
      'next',
      'setActive',
      'complete',
    ]);

    mockCommService = jasmine.createSpyObj('CommunicationService', ['send', 'connect', 'shutdown']);

    mockLogService = jasmine.createSpyObj('LogService', [
      'debug',
      'info',
      'warn',
      'error',
      'flush',
    ]);

    mockI18nService = jasmine.createSpyObj('I18nService', ['translate', 'setLanguage']);
    mockI18nService.translate.and.callFake((key: string) => key);

    await TestBed.configureTestingModule({
      imports: [SavePatientImagesComponent],
      providers: [
        { provide: UiStateManagementService, useValue: mockUiStateManagementService },
        { provide: CommunicationService, useValue: mockCommService },
        { provide: LogService, useValue: mockLogService },
        { provide: I18nService, useValue: mockI18nService },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(SavePatientImagesComponent);
    component = fixture.componentInstance;
  });

  describe('Component Lifecycle', () => {
    it('should create', () => {
      expect(component).toBeTruthy();
    });

    it('should log on initialization', () => {
      fixture.detectChanges();

      expect(mockLogService.info).toHaveBeenCalledWith(
        'SavePatientImagesComponent',
        'enter',
        'View entered'
      );
      expect(mockLogService.flush).toHaveBeenCalled();
    });

    it('should log on destroy', () => {
      fixture.detectChanges();
      mockLogService.info.calls.reset();
      mockLogService.flush.calls.reset();

      component.ngOnDestroy();

      expect(mockLogService.info).toHaveBeenCalledWith(
        'SavePatientImagesComponent',
        'leave',
        'View left'
      );
      expect(mockLogService.flush).toHaveBeenCalled();
    });
  });

  describe('User Interactions', () => {
    beforeEach(() => {
      fixture.detectChanges();
      mockLogService.info.calls.reset();
      mockLogService.warn.calls.reset();
      mockLogService.flush.calls.reset();
    });

    it('should handle proceed action', () => {
      component.onProceed();

      expect(mockLogService.info).toHaveBeenCalledWith(
        'SavePatientImagesComponent',
        'proceed',
        'Proceed clicked'
      );
      expect(mockUiStateManagementService.next).toHaveBeenCalledTimes(1);
      expect(mockLogService.flush).toHaveBeenCalled();
    });

    it('should handle cancel action', () => {
      component.onCancel();

      expect(mockLogService.warn).toHaveBeenCalledWith(
        'SavePatientImagesComponent',
        'cancel',
        'Cancel clicked'
      );
      expect(mockLogService.flush).toHaveBeenCalled();
    });

    it('should send CloseApp to backend on cancel', () => {
      component.onCancel();

      expect(mockCommService.send).toHaveBeenCalledWith('CloseApp');
    });

    it('should advance to next step on proceed', () => {
      component.onProceed();

      expect(mockUiStateManagementService.next).toHaveBeenCalledTimes(1);
    });

    it('should not advance on cancel', () => {
      component.onCancel();

      expect(mockUiStateManagementService.next).not.toHaveBeenCalled();
    });
  });

  describe('Logging Behavior', () => {
    beforeEach(() => {
      fixture.detectChanges();
      mockLogService.info.calls.reset();
      mockLogService.warn.calls.reset();
      mockLogService.flush.calls.reset();
    });

    it('should flush logs after proceed', () => {
      component.onProceed();

      expect(mockLogService.flush).toHaveBeenCalledTimes(1);
    });

    it('should flush logs after cancel', () => {
      component.onCancel();

      expect(mockLogService.flush).toHaveBeenCalledTimes(1);
    });

    it('should log with correct source identifier', () => {
      component.onProceed();

      expect(mockLogService.info).toHaveBeenCalledWith(
        'SavePatientImagesComponent',
        jasmine.any(String),
        jasmine.any(String)
      );
    });
  });

  describe('Multiple Interactions', () => {
    beforeEach(() => {
      fixture.detectChanges();
      mockLogService.info.calls.reset();
      mockLogService.warn.calls.reset();
      mockLogService.flush.calls.reset();
      mockUiStateManagementService.next.calls.reset();
    });

    it('should handle multiple proceed calls', () => {
      component.onProceed();
      component.onProceed();
      component.onProceed();

      expect(mockUiStateManagementService.next).toHaveBeenCalledTimes(3);
      expect(mockLogService.flush).toHaveBeenCalledTimes(3);
    });

    it('should handle multiple cancel calls', () => {
      component.onCancel();
      component.onCancel();

      expect(mockLogService.warn).toHaveBeenCalledTimes(2);
      expect(mockLogService.flush).toHaveBeenCalledTimes(2);
    });

    it('should handle alternating proceed and cancel', () => {
      component.onProceed();
      component.onCancel();
      component.onProceed();
      component.onCancel();

      expect(mockLogService.info).toHaveBeenCalledTimes(2);
      expect(mockLogService.warn).toHaveBeenCalledTimes(2);
      expect(mockUiStateManagementService.next).toHaveBeenCalledTimes(2);
    });
  });

  describe('Template Integration', () => {
    it('should render the component', () => {
      fixture.detectChanges();
      const compiled = fixture.nativeElement as HTMLElement;
      expect(compiled).toBeDefined();
    });

    it('should call onProceed when triggered', () => {
      spyOn(component, 'onProceed');
      fixture.detectChanges();

      component.onProceed();

      expect(component.onProceed).toHaveBeenCalled();
    });

    it('should call onCancel when triggered', () => {
      spyOn(component, 'onCancel');
      fixture.detectChanges();

      component.onCancel();

      expect(component.onCancel).toHaveBeenCalled();
    });
  });

  describe('Service Integration', () => {
    it('should inject UiStateManagementService', () => {
      expect(component['uiStateUpdate']).toBeDefined();
    });

    it('should inject LogService', () => {
      expect(component['log']).toBeDefined();
    });

    it('should maintain proper source identifier', () => {
      expect(component['source']).toBe('SavePatientImagesComponent');
    });
  });

  describe('Error Scenarios', () => {
    beforeEach(() => {
      fixture.detectChanges();
    });

    afterEach(() => {
      // Reset all spies to prevent cleanup errors
      mockLogService.info.and.stub();
      mockLogService.flush.and.stub();
      mockUiStateManagementService.next.and.stub();
    });

    it('should handle errors when state service fails', () => {
      mockUiStateManagementService.next.and.throwError('State service error');

      expect(() => component.onProceed()).toThrowError('State service error');
    });

    it('should handle logging errors gracefully', () => {
      mockLogService.info.and.throwError('Logging error');

      expect(() => component.onProceed()).toThrowError('Logging error');
    });

    it('should handle flush errors', () => {
      mockLogService.flush.and.throwError('Flush error');

      expect(() => component.onProceed()).toThrowError('Flush error');
    });
  });

  describe('Component State', () => {
    it('should initialize with correct source property', () => {
      expect(component['source']).toBe('SavePatientImagesComponent');
    });

    it('should not modify source during lifecycle', () => {
      const initialSource = component['source'];
      fixture.detectChanges();
      component.onProceed();
      component.onCancel();
      fixture.destroy();

      expect(component['source']).toBe(initialSource);
    });
  });

  describe('Business Logic', () => {
    beforeEach(() => {
      fixture.detectChanges();
      mockUiStateManagementService.next.calls.reset();
      mockLogService.flush.calls.reset();
    });

    it('should trigger navigation workflow on proceed', () => {
      component.onProceed();

      expect(mockLogService.flush).toHaveBeenCalled();
      expect(mockUiStateManagementService.next).toHaveBeenCalled();
    });

    it('should not trigger navigation on cancel', () => {
      component.onCancel();

      expect(mockUiStateManagementService.next).not.toHaveBeenCalled();
    });
  });
});

