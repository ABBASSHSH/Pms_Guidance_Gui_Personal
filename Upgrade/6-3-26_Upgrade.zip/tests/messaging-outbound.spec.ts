import { test, expect, getMessagesSent, sendToFrontend, goToStep1, goToStep5 } from './fixtures';

test.describe('Suite 10 — Frontend → Backend Outbound Messages', () => {
  test('OUT-01: app boot sends nothing', async ({ bridgedPage: page }) => {
    const sent = await getMessagesSent(page);
    // The app sends LogMessage entries during bootstrap — filter those out and
    // assert that no domain-level actions (e.g. VerifyInstallationPrerequisite)
    // are sent before the user navigates to Step 1.
    const domainMessages = sent.filter(m => m.Action !== 'LogMessage');
    expect(domainMessages).toHaveLength(0);
  });

  test('OUT-02: entering Step 1 sends VerifyInstallationPrerequisite', async ({
    bridgedPage: page,
  }) => {
    await goToStep1(page);
    const sent = await getMessagesSent(page);
    expect(sent).toContainEqual({ Action: 'VerifyInstallationPrerequisite' });
  });

  test('OUT-03: VerifyInstallationPrerequisite sent exactly once', async ({
    bridgedPage: page,
  }) => {
    await goToStep1(page);
    const sent = await getMessagesSent(page);
    expect(sent.filter(m => m.Action === 'VerifyInstallationPrerequisite')).toHaveLength(1);
  });

  test('OUT-04: Cancel on Introduction sends CloseApp', async ({ bridgedPage: page }) => {
    await page.locator('sh-button[label="Cancel"]').click();
    const sent = await getMessagesSent(page);
    expect(sent).toContainEqual({ Action: 'CloseApp' });
  });

  test('OUT-05: Cancel on Verification Result (success) sends CloseApp', async ({
    bridgedPage: page,
  }) => {
    await goToStep1(page);
    await sendToFrontend(page, { Action: 'ShowInstallationPrerequisite', Status: 'OK' });
    await page.waitForSelector('app-verification-result');
    await page.locator('sh-button[label="Cancel"]').click();
    const sent = await getMessagesSent(page);
    expect(sent).toContainEqual({ Action: 'CloseApp' });
  });

  test('OUT-06: Abort confirmed on Step 1 sends CloseApp', async ({ bridgedPage: page }) => {
    await goToStep1(page);
    // Two sh-button[label="Abort"] elements exist (page button + modal button)
    // → scope to the footer actions to click the page-level Abort button.
    await page.locator('app-verify-installation-prerequisites .footer__actions sh-button').click();
    await page.locator('sh-modal sh-button[label="Abort"]').click();
    const sent = await getMessagesSent(page);
    expect(sent).toContainEqual({ Action: 'CloseApp' });
  });

  test('OUT-07: Abort cancelled sends no CloseApp', async ({ bridgedPage: page }) => {
    await goToStep1(page);
    // Same scoping fix as OUT-06.
    await page.locator('app-verify-installation-prerequisites .footer__actions sh-button').click();
    await page.locator('sh-modal sh-button[label="Cancel"]').click();
    const sent = await getMessagesSent(page);
    expect(sent.find(m => m.Action === 'CloseApp')).toBeUndefined();
  });

  test('OUT-08: Cancel on Save Patient Images sends CloseApp', async ({ bridgedPage: page }) => {
    await goToStep1(page);
    await sendToFrontend(page, { Action: 'ShowInstallationPrerequisite', Status: 'OK' });
    await page.waitForSelector('app-verification-result');
    await page.locator('sh-button[label="Proceed with Installation"]').click();
    await page.waitForSelector('app-save-patient-images');
    await page.locator('sh-button[label="Cancel"]').click();
    const sent = await getMessagesSent(page);
    expect(sent).toContainEqual({ Action: 'CloseApp' });
  });

  test('OUT-09: Cancel on Drive to Park sends CloseApp', async ({ bridgedPage: page }) => {
    await goToStep1(page);
    await sendToFrontend(page, { Action: 'ShowInstallationPrerequisite', Status: 'OK' });
    await page.waitForSelector('app-verification-result');
    await page.locator('sh-button[label="Proceed with Installation"]').click();
    await page.waitForSelector('app-save-patient-images');
    await page.locator('sh-button[label="Proceed"]').click();
    await page.waitForSelector('app-drive-to-park-position');
    await page.locator('sh-button[label="Cancel"]').click();
    const sent = await getMessagesSent(page);
    expect(sent).toContainEqual({ Action: 'CloseApp' });
  });

  test('OUT-10: entering Step 5 sends InstallSoftware', async ({ bridgedPage: page }) => {
    await goToStep5(page);
    const sent = await getMessagesSent(page);
    expect(sent).toContainEqual({ Action: 'InstallSoftware' });
  });

  test('OUT-11: InstallSoftware sent exactly once', async ({ bridgedPage: page }) => {
    await goToStep5(page);
    const sent = await getMessagesSent(page);
    expect(sent.filter(m => m.Action === 'InstallSoftware')).toHaveLength(1);
  });

  test('OUT-12: full happy path sends only the two expected actions', async ({
    bridgedPage: page,
  }) => {
    await goToStep5(page);
    const sent = await getMessagesSent(page);
    const actions = sent.map(m => m.Action);
    expect(actions).toContain('VerifyInstallationPrerequisite');
    expect(actions).toContain('InstallSoftware');
    // LogMessage entries are expected (the log manager flushes during navigation);
    // filter those out before checking for unexpected domain-level actions.
    const unexpected = actions.filter(
      a => a !== 'VerifyInstallationPrerequisite' && a !== 'InstallSoftware' && a !== 'LogMessage'
    );
    expect(unexpected).toHaveLength(0);
  });

  test('OUT-13: every postMessage payload has an Action field', async ({ bridgedPage: page }) => {
    await goToStep5(page);
    const sent = await getMessagesSent(page);
    for (const msg of sent) {
      expect(msg).toHaveProperty('Action');
    }
  });
});
