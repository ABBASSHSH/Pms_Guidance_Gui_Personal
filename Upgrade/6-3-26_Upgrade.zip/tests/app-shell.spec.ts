import { test, expect } from './fixtures';

test.describe('Suite 1 — App Shell', () => {
  test('AS-01: app loads and shows the access bar with translated label', async ({ bridgedPage: page }) => {
    await expect(page.locator('sh-access-bar')).toBeVisible();
    // i18n loads asynchronously — wait until the label resolves from raw key to
    // the translated value. toHaveAttribute retries until timeout.
    await expect(page.locator('sh-access-bar')).toHaveAttribute('label', 'Software Upgrade');
  });

  test('AS-02: left stepper panel is visible on load', async ({ bridgedPage: page }) => {
    await expect(page.locator('app-guidance-overview')).toBeVisible();
  });

  test('AS-03: exactly 6 stepper items are rendered', async ({ bridgedPage: page }) => {
    await expect(page.locator('sh-stepper-item')).toHaveCount(6);
  });

  test('AS-04: Introduction step is active on first load', async ({ bridgedPage: page }) => {
    const items = page.locator('sh-stepper-item');
    await expect(items.nth(0)).toHaveAttribute('active', '');
    for (let i = 1; i <= 5; i++) {
      await expect(items.nth(i)).not.toHaveAttribute('active', '');
    }
  });

  test('AS-05: app applies dark theme', async ({ bridgedPage: page }) => {
    await expect(page.locator('sh-page')).toHaveAttribute('theme', 'dark');
  });

  test('AS-06: Introduction content panel is shown', async ({ bridgedPage: page }) => {
    await expect(page.locator('app-introduction')).toBeVisible();
  });
});
