import { test, expect, sendToFrontend, sendRaw, goToStep1 } from './fixtures';

test.describe('Suite 13 — Communication Robustness', () => {
  test('RB-01: empty JSON object causes no crash', async ({ bridgedPage: page }) => {
    await sendToFrontend(page, {});
    await expect(page.locator('app-introduction')).toBeVisible();
  });

  test('RB-02: message with no Action field is discarded silently', async ({
    bridgedPage: page,
  }) => {
    await sendToFrontend(page, { Status: 'OK' });
    await expect(page.locator('app-introduction')).toBeVisible();
  });

  test('RB-03: unknown Action value is discarded silently', async ({ bridgedPage: page }) => {
    await sendToFrontend(page, { Action: 'UnknownAction' });
    await expect(page.locator('app-introduction')).toBeVisible();
  });

  test('RB-04: malformed JSON string does not crash', async ({ bridgedPage: page }) => {
    // Use sendRaw to dispatch a non-JSON string directly through the bridge's handler
    // list, which forces Angular's ConnectionManager to call JSON.parse() on bad data.
    // The fix vs. old implementation: the raw string now actually reaches the handlers.
    await sendRaw(page, 'not-json{{{badly===formed');
    // App must survive the parse error and remain on Step 0
    await expect(page.locator('app-introduction')).toBeVisible();
  });

  test('RB-05: null message data does not crash', async ({ bridgedPage: page }) => {
    await page.evaluate(() => {
      // Dispatch a MessageEvent with null data directly to document
      const evt = new MessageEvent('message', { data: null as any });
      window.dispatchEvent(evt);
    });
    await expect(page.locator('app-introduction')).toBeVisible();
  });

  test('RB-06: rapid repeated OK messages — UI stable, navigated once', async ({
    bridgedPage: page,
  }) => {
    await goToStep1(page);
    // Send 10 OK messages in quick succession
    for (let i = 0; i < 10; i++) {
      await sendToFrontend(page, { Action: 'ShowInstallationPrerequisite', Status: 'OK' });
    }
    await expect(page.locator('app-verification-result')).toBeVisible();
    // Only one step forward — must not have gone past Step 2
    await expect(page.locator('app-save-patient-images')).toHaveCount(0);
  });

  test('RB-07: wrong action casing is not handled', async ({ bridgedPage: page }) => {
    await goToStep1(page);
    await sendToFrontend(page, { Action: 'showInstallationPrerequisite', Status: 'OK' });
    // Case-sensitive — should NOT navigate
    await expect(page.locator('app-verify-installation-prerequisites')).toBeVisible();
  });

  test('RB-08: large payload with extra fields is handled correctly', async ({
    bridgedPage: page,
  }) => {
    await goToStep1(page);
    const extra = Object.fromEntries(Array.from({ length: 100 }, (_, i) => [`field${i}`, 'x'.repeat(100)]));
    await sendToFrontend(page, {
      Action: 'ShowInstallationPrerequisite',
      Status: 'OK',
      ...extra,
    });
    await expect(page.locator('app-verification-result')).toBeVisible();
  });
});
