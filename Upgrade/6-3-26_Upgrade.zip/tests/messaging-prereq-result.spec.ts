import { test, expect, sendToFrontend, goToStep1 } from './fixtures';

test.describe('Suite 12 — Backend → Frontend: ShowInstallationPrerequisite', () => {
  // ── 12A: Status OK ─────────────────────────────────────────────────────────

  test.describe('12A — Status OK', () => {
    test('PR-01: OK response marks Step 1 stepper as success', async ({ bridgedPage: page }) => {
      await goToStep1(page);
      await sendToFrontend(page, { Action: 'ShowInstallationPrerequisite', Status: 'OK' });
      // The handler calls state.setActive(VerificationResult) synchronously, so the
      // verify-prereq component is torn down before any DOM assertion can see its
      // internal progress state.  Verify the outcome via the stepper attribute that
      // is set to 'success' when progress reaches 100 % (i.e. Status = OK).
      await page.waitForSelector('app-verification-result');
      await expect(page.locator('sh-stepper-item').nth(1)).toHaveAttribute('type', 'success');
    });

    test('PR-02: status text updates to success', async ({ bridgedPage: page }) => {
      await goToStep1(page);
      await sendToFrontend(page, { Action: 'ShowInstallationPrerequisite', Status: 'OK' });
      // Navigation is synchronous — verify the post-navigation success notification
      // instead of the transient status text on the now-unmounted component.
      await page.waitForSelector('app-verification-result');
      await expect(page.locator('sh-notification-item[type="success"]')).toBeVisible();
    });

    test('PR-03: no error styling on success', async ({ bridgedPage: page }) => {
      await goToStep1(page);
      await sendToFrontend(page, { Action: 'ShowInstallationPrerequisite', Status: 'OK' });
      await expect(page.locator('.text--error')).toHaveCount(0);
    });

    test('PR-04: auto-navigates to Step 2', async ({ bridgedPage: page }) => {
      await goToStep1(page);
      await sendToFrontend(page, { Action: 'ShowInstallationPrerequisite', Status: 'OK' });
      await expect(page.locator('app-verification-result')).toBeVisible();
    });

    test('PR-05: Step 1 marked success in stepper', async ({ bridgedPage: page }) => {
      await goToStep1(page);
      await sendToFrontend(page, { Action: 'ShowInstallationPrerequisite', Status: 'OK' });
      await page.waitForSelector('app-verification-result');
      await expect(page.locator('sh-stepper-item').nth(1)).toHaveAttribute('type', 'success');
    });

    test('PR-06: Step 2 shows success notification', async ({ bridgedPage: page }) => {
      await goToStep1(page);
      await sendToFrontend(page, { Action: 'ShowInstallationPrerequisite', Status: 'OK' });
      await page.waitForSelector('app-verification-result');
      await expect(page.locator('sh-notification-item[type="success"]')).toBeVisible();
    });
  });

  // ── 12B: Status NotOk ──────────────────────────────────────────────────────

  test.describe('12B — Status NotOk', () => {
    test('PR-07: NotOk response marks Step 1 stepper as error', async ({ bridgedPage: page }) => {
      await goToStep1(page);
      await sendToFrontend(page, { Action: 'ShowInstallationPrerequisite', Status: 'Not Ok' });
      // Navigation is synchronous — the verify-prereq component is unmounted before
      // we can read its progress label.  Verify via the stepper 'error' attribute
      // which reflects the 75 % / error outcome.
      await page.waitForSelector('app-verification-result');
      await expect(page.locator('sh-stepper-item').nth(1)).toHaveAttribute('type', 'error');
    });

    test('PR-08: status text updates to error', async ({ bridgedPage: page }) => {
      await goToStep1(page);
      await sendToFrontend(page, { Action: 'ShowInstallationPrerequisite', Status: 'Not Ok' });
      // Same timing issue — check the post-navigation error notification instead.
      await page.waitForSelector('app-verification-result');
      await expect(page.locator('sh-notification-item[type="error"]')).toBeVisible();
    });

    test('PR-09: NotOk response — stepper type="error" is set (error state confirmed)', async ({ bridgedPage: page }) => {
      await goToStep1(page);
      await sendToFrontend(page, { Action: 'ShowInstallationPrerequisite', Status: 'Not Ok' });
      // The .text--error class is on the now-unmounted verify-prereq component.
      // The equivalent observable outcome is the stepper item having type="error".
      await page.waitForSelector('app-verification-result');
      await expect(page.locator('sh-stepper-item').nth(1)).toHaveAttribute('type', 'error');
    });

    test('PR-10: auto-navigates to Step 2', async ({ bridgedPage: page }) => {
      await goToStep1(page);
      await sendToFrontend(page, { Action: 'ShowInstallationPrerequisite', Status: 'Not Ok' });
      await expect(page.locator('app-verification-result')).toBeVisible();
    });

    test('PR-11: Step 1 marked error in stepper', async ({ bridgedPage: page }) => {
      await goToStep1(page);
      await sendToFrontend(page, { Action: 'ShowInstallationPrerequisite', Status: 'Not Ok' });
      await page.waitForSelector('app-verification-result');
      await expect(page.locator('sh-stepper-item').nth(1)).toHaveAttribute('type', 'error');
    });

    test('PR-12: Step 2 shows error notification', async ({ bridgedPage: page }) => {
      await goToStep1(page);
      await sendToFrontend(page, { Action: 'ShowInstallationPrerequisite', Status: 'Not Ok' });
      await page.waitForSelector('app-verification-result');
      await expect(page.locator('sh-notification-item[type="error"]')).toBeVisible();
    });
  });

  // ── 12C: Invalid and Edge Cases ────────────────────────────────────────────

  test.describe('12C — Invalid and Edge Cases', () => {
    test('PR-13: invalid Status field causes no navigation', async ({ bridgedPage: page }) => {
      await goToStep1(page);
      await sendToFrontend(page, { Action: 'ShowInstallationPrerequisite', Status: 'bad' });
      // Should stay on Step 1 or handle gracefully
      await expect(page.locator('app-verification-result')).toHaveCount(0);
    });

    test('PR-14: missing Status field causes no crash', async ({ bridgedPage: page }) => {
      await goToStep1(page);
      await sendToFrontend(page, { Action: 'ShowInstallationPrerequisite' });
      await expect(page.locator('app-verify-installation-prerequisites')).toBeVisible();
    });

    test('PR-15: duplicate OK message is idempotent', async ({ bridgedPage: page }) => {
      await goToStep1(page);
      await sendToFrontend(page, { Action: 'ShowInstallationPrerequisite', Status: 'OK' });
      await page.waitForSelector('app-verification-result');
      // Send again — should not double-navigate or crash
      await sendToFrontend(page, { Action: 'ShowInstallationPrerequisite', Status: 'OK' });
      await expect(page.locator('app-verification-result')).toBeVisible();
    });

    test('PR-16: message received while abort modal open', async ({ bridgedPage: page }) => {
      await goToStep1(page);
      // Two sh-button[label="Abort"] elements in DOM — scope to .footer__actions.
      await page.locator('app-verify-installation-prerequisites .footer__actions sh-button').click();
      await expect(page.locator('sh-modal')).toBeVisible();
      await sendToFrontend(page, { Action: 'ShowInstallationPrerequisite', Status: 'OK' });
      // Navigation should still happen; no crash
      await expect(page.locator('app-verification-result')).toBeVisible();
    });
  });
});
