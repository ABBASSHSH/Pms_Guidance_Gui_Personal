import { test as base, Page } from '@playwright/test';

/**
 * Playwright WebView2 Bridge
 *
 * Injected via page.addInitScript() BEFORE Angular bootstraps, so that
 * ConnectionManager.connect() finds window.chrome.webview already present.
 *
 * This is NOT the dev-time webview2.mock.ts — that file is only loaded during
 * `ng serve` for manual browser testing and is never present in Playwright runs.
 *
 * Capabilities:
 *  - Outbound spy:    Angular calls chrome.webview.postMessage(payload)
 *                     → stored in window.__pw_messages_sent[]
 *  - Inbound trigger: test calls window.__pw_sendToFrontend(payload)
 *                     → dispatches a MessageEvent to all registered handlers
 */
const bridgeScript = () => {
  (window as any).__pw_messages_sent = [];
  const handlers: Array<(e: MessageEvent) => void> = [];

  /** Dispatch a backend→frontend message to all currently-registered handlers. */
  const dispatch = (payload: object) => {
    const evt = new MessageEvent('message', { data: JSON.stringify(payload) });
    handlers.forEach(h => h(evt));
  };

  /** Dispatch a raw string (bypassing JSON.stringify) to exercise parse-error paths. */
  const dispatchRaw = (raw: string) => {
    const evt = new MessageEvent('message', { data: raw });
    handlers.forEach(h => h(evt));
  };

  (window as any).chrome = {
    webview: {
      addEventListener: (type: string, fn: (e: MessageEvent) => void) => {
        if (type !== 'message') return;
        handlers.push(fn);
        // Mirror webview2.mock.ts behaviour: the real backend sends ShowSystemLanguage
        // immediately after the first listener registers (i.e. on connection).
        // Sending it here (synchronously-then-microtask) ensures i18n loads before
        // any test assertion runs, with zero race-condition risk.
        if (handlers.length === 1) {
          Promise.resolve().then(() =>
            dispatch({ Action: 'ShowSystemLanguage', Language: 'English' })
          );
        }
      },
      removeEventListener: (_type: string, fn: (e: MessageEvent) => void) => {
        const i = handlers.indexOf(fn);
        if (i > -1) handlers.splice(i, 1);
      },
      postMessage: (msg: unknown) => {
        (window as any).__pw_messages_sent.push(msg);
      },
    },
  };

  /** Call this from a test to simulate a backend → frontend message. */
  (window as any).__pw_sendToFrontend = (payload: object) => dispatch(payload);

  /**
   * Call this from a test to dispatch a raw string through the registered handlers.
   * Useful for robustness testing where JSON.parse is expected to throw.
   */
  (window as any).__pw_sendRaw = (raw: string) => dispatchRaw(raw);
};

// ── Selector helpers ─────────────────────────────────────────────────────────
//
// IMPORTANT — Angular binding modes used in this app:
//
//  [attr.label]="..."   → renders as an HTML attribute → [label="..."] CSS works ✓
//  [label]="..."        → sets a JS property only, NO HTML attribute → [label="..."] fails ✗
//
// Per-component button binding:
//  introduction          : [label]="..." (property) — use color attribute instead
//  save-patient-images   : [label]="..." (property) — use color attribute instead
//  drive-to-park-position: [label]="..." (property) — use color attribute instead
//  verify-prereq         : [attr.label]="..." — label attribute present ✓
//  verification-result   : [attr.label]="..." — label attribute present ✓
//
// Static color attributes (always rendered, all components):
//   Proceed / primary action  → sh-button[color="primary"]
//   Cancel / secondary action → sh-button[color="secondary"]
//   (scoped to the host component to avoid cross-component ambiguity)

// ── Typed helpers ─────────────────────────────────────────────────────────────

export type MessagesSent = Array<{ Action: string; [key: string]: unknown }>;

/** Read all messages Angular has sent to the backend since page load. */
export async function getMessagesSent(page: Page): Promise<MessagesSent> {
  return page.evaluate(() => (window as any).__pw_messages_sent ?? []);
}

/** Simulate the backend sending a message to Angular via the WebView2 bridge. */
export async function sendToFrontend(page: Page, payload: object): Promise<void> {
  await page.evaluate((p) => (window as any).__pw_sendToFrontend(p), payload);
}

/**
 * Dispatch a raw (non-JSON-encoded) string through the bridge handler list.
 * Used to test that the communication layer handles JSON.parse errors gracefully.
 */
export async function sendRaw(page: Page, raw: string): Promise<void> {
  await page.evaluate((r) => (window as any).__pw_sendRaw(r), raw);
}

// ── Navigation helpers ────────────────────────────────────────────────────────

/**
 * Step 0 → Step 1.
 * Introduction uses [label] property binding, so we use the static color="primary"
 * attribute to locate the Proceed button.
 */
export async function goToStep1(page: Page): Promise<void> {
  await page.locator('app-introduction sh-button[color="primary"]').click();
  await page.waitForSelector('app-verify-installation-prerequisites');
}

/**
 * Step 1 → Step 2 (OK path).
 * The backend sends ShowInstallationPrerequisite Status=OK which triggers auto-
 * navigation. waitForSelector confirms the component swap has occurred.
 */
export async function goToStep2ViaOk(page: Page): Promise<void> {
  await goToStep1(page);
  await sendToFrontend(page, { Action: 'ShowInstallationPrerequisite', Status: 'OK' });
  await page.waitForSelector('app-verification-result');
}

/**
 * Step 1 → Step 2 (NotOk path).
 */
export async function goToStep2ViaNotOk(page: Page): Promise<void> {
  await goToStep1(page);
  await sendToFrontend(page, { Action: 'ShowInstallationPrerequisite', Status: 'Not Ok' });
  await page.waitForSelector('app-verification-result');
}

/**
 * Step 2 → Step 3.
 * verification-result uses [attr.label], so the label attribute is in the DOM.
 */
export async function goToStep3(page: Page): Promise<void> {
  await goToStep2ViaOk(page);
  await page.locator('sh-button[label="Proceed with Installation"]').click();
  await page.waitForSelector('app-save-patient-images');
}

/**
 * Step 3 → Step 4.
 * save-patient-images uses [label] property binding → use color="primary".
 */
export async function goToStep4(page: Page): Promise<void> {
  await goToStep3(page);
  await page.locator('app-save-patient-images sh-button[color="primary"]').click();
  await page.waitForSelector('app-drive-to-park-position');
}

/**
 * Step 4 → Step 5.
 * drive-to-park-position uses [label] property binding → use color="primary".
 */
export async function goToStep5(page: Page): Promise<void> {
  await goToStep4(page);
  await page.locator('app-drive-to-park-position sh-button[color="primary"]').click();
  await page.waitForSelector('app-installation-in-progress');
}

// ── Custom fixture ────────────────────────────────────────────────────────────

type Fixtures = {
  /**
   * A Page with the WebView2 bridge injected before Angular bootstraps.
   * Use this fixture (instead of the bare `page`) in every test.
   */
  bridgedPage: Page;
};

export const test = base.extend<Fixtures>({
  bridgedPage: async ({ page }, use) => {
    // Must be added BEFORE goto so it runs before Angular bootstraps.
    await page.addInitScript(bridgeScript);
    await page.goto('/');
    await page.waitForSelector('app-introduction');

    // The bridge script automatically sends ShowSystemLanguage when Angular's
    // ConnectionManager registers its first 'message' listener (mirrors the
    // real backend and webview2.mock.ts behaviour). Wait until the i18n pipe
    // has resolved the introduction title to its English value before handing
    // the page to any test — this guarantees all text assertions see translated
    // strings rather than raw i18n keys.
    await page.waitForFunction(
      () => {
        const el = document.querySelector('app-introduction .title');
        return el !== null && el.textContent !== null &&
               el.textContent.includes('Software');
      },
      { timeout: 15000 }
    );

    await use(page);
  },
});

export { expect } from '@playwright/test';
