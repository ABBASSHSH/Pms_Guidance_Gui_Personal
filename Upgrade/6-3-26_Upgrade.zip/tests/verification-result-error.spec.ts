import { test, expect, getMessagesSent, goToStep2ViaNotOk } from './fixtures';

test.describe('Suite 5 — Step 2: Verification Result (Error Path)', () => {
  test('VRE-01: title displayed', async ({ bridgedPage: page }) => {
    await goToStep2ViaNotOk(page);
    await expect(page.locator('.title')).toContainText('Verification Result');
  });

  test('VRE-02: error notification shown', async ({ bridgedPage: page }) => {
    await goToStep2ViaNotOk(page);
    await expect(page.locator('sh-notification-item[type="error"]')).toBeVisible();
  });

  test('VRE-03: error title text', async ({ bridgedPage: page }) => {
    await goToStep2ViaNotOk(page);
    await expect(page.locator('sh-notification-item[type="error"]')).toHaveAttribute(
      'label',
      'Error'
    );
  });

  test('VRE-04: error subtitle text', async ({ bridgedPage: page }) => {
    await goToStep2ViaNotOk(page);
    await expect(page.locator('sh-notification-item[type="error"]')).toContainText(
      'Prerequisites for the software update failed'
    );
  });

  test('VRE-05: error body text', async ({ bridgedPage: page }) => {
    await goToStep2ViaNotOk(page);
    await expect(page.locator('.body')).toContainText(
      'Proceeding with the software installation is not possible'
    );
  });

  test('VRE-06: error info hint', async ({ bridgedPage: page }) => {
    await goToStep2ViaNotOk(page);
    await expect(page.locator('sh-menu-item[icon="information"]')).toContainText(
      'system stays with the previous software'
    );
  });

  test('VRE-07: Show Report and OK buttons visible', async ({ bridgedPage: page }) => {
    await goToStep2ViaNotOk(page);
    await expect(page.locator('sh-button[label="Show Report"]')).toBeVisible();
    await expect(page.locator('sh-button[label="OK"]')).toBeVisible();
  });

  test('VRE-08: no Proceed with Installation button on error', async ({ bridgedPage: page }) => {
    await goToStep2ViaNotOk(page);
    await expect(page.locator('sh-button[label="Proceed with Installation"]')).toHaveCount(0);
  });

  test('VRE-09: OK button is clickable without crash', async ({ bridgedPage: page }) => {
    await goToStep2ViaNotOk(page);
    await page.locator('sh-button[label="OK"]').click();
    await expect(page.locator('app-verification-result')).toBeVisible();
  });

  test('VRE-10: Show Report button is clickable without crash', async ({ bridgedPage: page }) => {
    await goToStep2ViaNotOk(page);
    await page.locator('sh-button[label="Show Report"]').click();
    await expect(page.locator('app-verification-result')).toBeVisible();
  });

  // ── M-02: copyright text present ──────────────────────────────────────────

  test('VRE-11: copyright text present in footer', async ({ bridgedPage: page }) => {
    // The verification-result template renders <sh-text>{{ 'common.copyright' | t }}</sh-text>
    // in the .footer element on both success and error paths.
    await goToStep2ViaNotOk(page);
    await expect(
      page.locator('app-verification-result .footer sh-text')
    ).toContainText('© Copyright 2025 Siemens Healthineers AG');
  });

  // ── M-03: OK does NOT send CloseApp ───────────────────────────────────────

  test('VRE-12: OK does not send CloseApp to backend', async ({ bridgedPage: page }) => {
    // On the error path there is no Cancel button — only OK and Show Report.
    // Neither should trigger a CloseApp message (they dismiss the verification,
    // but do not close the application).
    await goToStep2ViaNotOk(page);
    await page.locator('sh-button[label="OK"]').click();
    const sent = await getMessagesSent(page);
    const closeAppMessages = sent.filter(m => m.Action === 'CloseApp');
    expect(closeAppMessages).toHaveLength(0);
  });

  // ── M-08: Show Report does NOT send CloseApp ──────────────────────────────

  test('VRE-13: Show Report does not send CloseApp to backend', async ({ bridgedPage: page }) => {
    await goToStep2ViaNotOk(page);
    await page.locator('sh-button[label="Show Report"]').click();
    const sent = await getMessagesSent(page);
    const closeAppMessages = sent.filter(m => m.Action === 'CloseApp');
    expect(closeAppMessages).toHaveLength(0);
  });
});
