import { test, expect, getMessagesSent, sendToFrontend, goToStep1 } from './fixtures';

test.describe('Suite 3 — Step 1: Verify Installation Prerequisites', () => {
  // ── 3A: Initial State ──────────────────────────────────────────────────────

  test.describe('3A — Initial State', () => {
    test('VP-01: verification title displayed', async ({ bridgedPage: page }) => {
      await goToStep1(page);
      await expect(page.locator('.title')).toContainText(
        'Final Verification before Installation Process'
      );
    });

    test('VP-02: progress bar starts at 0%', async ({ bridgedPage: page }) => {
      await goToStep1(page);
      await expect(page.locator('.progress-label')).toContainText('0%');
      await expect(page.locator('sh-progress')).toHaveAttribute('value', '0');
    });

    test('VP-03: in-progress status text shown', async ({ bridgedPage: page }) => {
      await goToStep1(page);
      await expect(page.locator('.text')).toContainText(
        'Verifying the software prerequisites'
      );
    });

    test('VP-04: no error styling on initial load', async ({ bridgedPage: page }) => {
      await goToStep1(page);
      await expect(page.locator('.text--error')).toHaveCount(0);
    });

    test('VP-05: Abort button is visible', async ({ bridgedPage: page }) => {
      await goToStep1(page);
      // Scope to footer__actions to avoid matching the hidden modal Abort button
      await expect(
        page.locator('app-verify-installation-prerequisites .footer__actions sh-button')
      ).toBeVisible();
    });

    test('VP-06: VerifyInstallationPrerequisite sent to backend', async ({ bridgedPage: page }) => {
      await goToStep1(page);
      const sent = await getMessagesSent(page);
      expect(sent).toContainEqual({ Action: 'VerifyInstallationPrerequisite' });
    });

    test('VP-07: VerifyInstallationPrerequisite sent exactly once', async ({ bridgedPage: page }) => {
      await goToStep1(page);
      const sent = await getMessagesSent(page);
      const count = sent.filter(m => m.Action === 'VerifyInstallationPrerequisite').length;
      expect(count).toBe(1);
    });
  });

  // ── 3B: Backend OK Response ────────────────────────────────────────────────
  // NOTE: ShowInstallationPrerequisite triggers immediate navigation to
  // VerificationResult (setPrereqStatus → complete → setActive in the same tick).
  // The component's own progress/text bindings update in that same tick but the
  // component is destroyed before the browser can repaint, so progress/text state
  // is validated via the stepper and navigation destination instead.

  test.describe('3B — Backend OK Response', () => {
    test('VP-08: Step 1 stepper marked success after OK', async ({ bridgedPage: page }) => {
      await goToStep1(page);
      await sendToFrontend(page, { Action: 'ShowInstallationPrerequisite', Status: 'OK' });
      await page.waitForSelector('app-verification-result');
      await expect(page.locator('sh-stepper-item').nth(1)).toHaveAttribute('type', 'success');
    });

    test('VP-09: verification-result shows on OK response', async ({ bridgedPage: page }) => {
      await goToStep1(page);
      await sendToFrontend(page, { Action: 'ShowInstallationPrerequisite', Status: 'OK' });
      await expect(page.locator('app-verification-result')).toBeVisible();
    });

    test('VP-10: no error styling on success', async ({ bridgedPage: page }) => {
      await goToStep1(page);
      // Check no error on verify-prereq before response
      await expect(page.locator('.text--error')).toHaveCount(0);
    });

    test('VP-11: auto-navigates to Step 2', async ({ bridgedPage: page }) => {
      await goToStep1(page);
      await sendToFrontend(page, { Action: 'ShowInstallationPrerequisite', Status: 'OK' });
      await expect(page.locator('app-verification-result')).toBeVisible();
    });

    test('VP-12: Step 1 marked success in stepper', async ({ bridgedPage: page }) => {
      await goToStep1(page);
      await sendToFrontend(page, { Action: 'ShowInstallationPrerequisite', Status: 'OK' });
      await expect(page.locator('app-verification-result')).toBeVisible();
      await expect(page.locator('sh-stepper-item').nth(1)).toHaveAttribute('type', 'success');
    });
  });

  // ── 3C: Backend NotOk Response ─────────────────────────────────────────────

  test.describe('3C — Backend NotOk Response', () => {
    test('VP-13: Step 1 stepper marked error after NotOk', async ({ bridgedPage: page }) => {
      await goToStep1(page);
      await sendToFrontend(page, { Action: 'ShowInstallationPrerequisite', Status: 'Not Ok' });
      await page.waitForSelector('app-verification-result');
      await expect(page.locator('sh-stepper-item').nth(1)).toHaveAttribute('type', 'error');
    });

    test('VP-14: verification-result shows on NotOk response', async ({ bridgedPage: page }) => {
      await goToStep1(page);
      await sendToFrontend(page, { Action: 'ShowInstallationPrerequisite', Status: 'Not Ok' });
      await expect(page.locator('app-verification-result')).toBeVisible();
    });

    test('VP-15: step 2 (VerificationResult) is active in stepper after NotOk', async ({ bridgedPage: page }) => {
      await goToStep1(page);
      await sendToFrontend(page, { Action: 'ShowInstallationPrerequisite', Status: 'Not Ok' });
      await page.waitForSelector('app-verification-result');
      await expect(page.locator('sh-stepper-item').nth(2)).toHaveAttribute('active', '');
    });

    test('VP-16: auto-navigates to Step 2', async ({ bridgedPage: page }) => {
      await goToStep1(page);
      await sendToFrontend(page, { Action: 'ShowInstallationPrerequisite', Status: 'Not Ok' });
      await expect(page.locator('app-verification-result')).toBeVisible();
    });

    test('VP-17: Step 1 marked error in stepper', async ({ bridgedPage: page }) => {
      await goToStep1(page);
      await sendToFrontend(page, { Action: 'ShowInstallationPrerequisite', Status: 'Not Ok' });
      await expect(page.locator('app-verification-result')).toBeVisible();
      await expect(page.locator('sh-stepper-item').nth(1)).toHaveAttribute('type', 'error');
    });
  });

  // ── 3D: Abort Modal ────────────────────────────────────────────────────────

  test.describe('3D — Abort Modal', () => {
    test('VP-18: Abort button opens confirmation modal', async ({ bridgedPage: page }) => {
      await goToStep1(page);
      await page.locator('app-verify-installation-prerequisites .footer__actions sh-button').click();
      await expect(page.locator('sh-modal[label="Abort Verification"]')).toBeVisible();
    });

    test('VP-19: modal shows correct description text', async ({ bridgedPage: page }) => {
      await goToStep1(page);
      await page.locator('app-verify-installation-prerequisites .footer__actions sh-button').click();
      await expect(page.locator('sh-modal')).toContainText(
        'Do you want to abort the verification'
      );
    });

    test('VP-20: abort modal has Cancel and Abort buttons', async ({ bridgedPage: page }) => {
      await goToStep1(page);
      await page.locator('app-verify-installation-prerequisites .footer__actions sh-button').click();
      const modal = page.locator('sh-modal');
      await expect(modal.locator('sh-button[label="Cancel"]')).toBeVisible();
      await expect(modal.locator('sh-button[label="Abort"]')).toBeVisible();
    });

    test('VP-21: Cancel closes modal and stays on Step 1', async ({ bridgedPage: page }) => {
      await goToStep1(page);
      await page.locator('app-verify-installation-prerequisites .footer__actions sh-button').click();
      await page.locator('sh-modal sh-button[label="Cancel"]').click();
      await expect(page.locator('sh-modal')).not.toBeVisible();
      await expect(page.locator('app-verify-installation-prerequisites')).toBeVisible();
    });

    test('VP-22: Cancel in modal sends no backend message', async ({ bridgedPage: page }) => {
      await goToStep1(page);
      await page.locator('app-verify-installation-prerequisites .footer__actions sh-button').click();
      await page.locator('sh-modal sh-button[label="Cancel"]').click();
      const sent = await getMessagesSent(page);
      expect(sent.find(m => m.Action === 'CloseApp')).toBeUndefined();
    });

    test('VP-23: Abort confirmed sends CloseApp', async ({ bridgedPage: page }) => {
      await goToStep1(page);
      await page.locator('app-verify-installation-prerequisites .footer__actions sh-button').click();
      await page.locator('sh-modal sh-button[label="Abort"]').click();
      const sent = await getMessagesSent(page);
      expect(sent).toContainEqual({ Action: 'CloseApp' });
    });
  });
});
