import { test, expect, getMessagesSent, goToStep2ViaOk, goToStep3 } from './fixtures';

test.describe('Suite 4 — Step 2: Verification Result (Success Path)', () => {
  test('VRS-01: title displayed', async ({ bridgedPage: page }) => {
    await goToStep2ViaOk(page);
    await expect(page.locator('.title')).toContainText('Verification Result');
  });

  test('VRS-02: success notification shown', async ({ bridgedPage: page }) => {
    await goToStep2ViaOk(page);
    await expect(page.locator('sh-notification-item[type="success"]')).toBeVisible();
  });

  test('VRS-03: success title text', async ({ bridgedPage: page }) => {
    await goToStep2ViaOk(page);
    await expect(page.locator('sh-notification-item[type="success"]')).toHaveAttribute(
      'label',
      'Success'
    );
  });

  test('VRS-04: success subtitle text', async ({ bridgedPage: page }) => {
    await goToStep2ViaOk(page);
    await expect(page.locator('sh-notification-item[type="success"]')).toContainText(
      'Verification of the software prerequisites completed'
    );
  });

  test('VRS-05: success body text', async ({ bridgedPage: page }) => {
    await goToStep2ViaOk(page);
    await expect(page.locator('.body')).toContainText('ready for software installation');
  });

  test('VRS-06: success info hint', async ({ bridgedPage: page }) => {
    await goToStep2ViaOk(page);
    await expect(page.locator('sh-menu-item[icon="information"]')).toContainText(
      'To continue with the installation'
    );
  });

  test('VRS-07: Cancel and Proceed with Installation buttons visible', async ({
    bridgedPage: page,
  }) => {
    await goToStep2ViaOk(page);
    await expect(page.locator('sh-button[label="Cancel"]')).toBeVisible();
    await expect(page.locator('sh-button[label="Proceed with Installation"]')).toBeVisible();
  });

  test('VRS-08: no Show Report button on success', async ({ bridgedPage: page }) => {
    await goToStep2ViaOk(page);
    await expect(page.locator('sh-button[label="Show Report"]')).toHaveCount(0);
  });

  test('VRS-09: Proceed with Installation advances to Step 3', async ({ bridgedPage: page }) => {
    await goToStep3(page);
    await expect(page.locator('app-save-patient-images')).toBeVisible();
    await expect(page.locator('sh-stepper-item').nth(3)).toHaveAttribute('active', '');
  });

  test('VRS-10: Step 2 marked success after Proceed', async ({ bridgedPage: page }) => {
    await goToStep3(page);
    await expect(page.locator('sh-stepper-item').nth(2)).toHaveAttribute('type', 'success');
  });

  test('VRS-11: Cancel sends CloseApp', async ({ bridgedPage: page }) => {
    await goToStep2ViaOk(page);
    await page.locator('sh-button[label="Cancel"]').click();
    const sent = await getMessagesSent(page);
    expect(sent).toContainEqual({ Action: 'CloseApp' });
  });

  // ── M-02: copyright text present ──────────────────────────────────────────

  test('VRS-12: copyright text present in footer', async ({ bridgedPage: page }) => {
    // The verification-result template renders <sh-text>{{ 'common.copyright' | t }}</sh-text>
    // in the .footer element on both success and error paths.
    await goToStep2ViaOk(page);
    await expect(
      page.locator('app-verification-result .footer sh-text')
    ).toContainText('© Copyright 2025 Siemens Healthineers AG');
  });
});
