import { test, expect, getMessagesSent, goToStep4, goToStep5 } from './fixtures';

test.describe('Suite 7 — Step 4: Drive to Park Position', () => {
  test('DTP-01: title displayed', async ({ bridgedPage: page }) => {
    await goToStep4(page);
    await expect(page.locator('.title')).toContainText('Drive To Park Position');
  });

  test('DTP-02: Step 1 instruction visible', async ({ bridgedPage: page }) => {
    await goToStep4(page);
    await expect(page.locator('.text').nth(0)).toContainText('Select the Park Position');
  });

  test('DTP-03: Step 2 instruction visible', async ({ bridgedPage: page }) => {
    await goToStep4(page);
    await expect(page.locator('.text').nth(1)).toContainText(
      'move the system approximately 20 cm'
    );
  });

  test('DTP-04: Step 3 instruction visible', async ({ bridgedPage: page }) => {
    await goToStep4(page);
    await expect(page.locator('.text').nth(2)).toContainText('Stand Test');
  });

  test('DTP-05: Step 4 instruction visible', async ({ bridgedPage: page }) => {
    await goToStep4(page);
    await expect(page.locator('.text').nth(3)).toContainText('Emergency Stop');
  });

  test('DTP-06: info bar hint present', async ({ bridgedPage: page }) => {
    await goToStep4(page);
    await expect(page.locator('sh-menu-item[icon="information"]')).toBeVisible();
  });

  test('DTP-07: Cancel and Proceed buttons visible', async ({ bridgedPage: page }) => {
    await goToStep4(page);
    await expect(page.locator('sh-button[label="Cancel"]')).toBeVisible();
    await expect(page.locator('sh-button[label="Proceed"]')).toBeVisible();
  });

  test('DTP-08: copyright text present', async ({ bridgedPage: page }) => {
    await goToStep4(page);
    await expect(page.locator('app-drive-to-park-position .footer sh-text')).toContainText(
      '© Copyright 2025 Siemens Healthineers AG'
    );
  });

  test('DTP-09: Proceed advances to Step 5', async ({ bridgedPage: page }) => {
    await goToStep5(page);
    await expect(page.locator('app-installation-in-progress')).toBeVisible();
    await expect(page.locator('sh-stepper-item').nth(5)).toHaveAttribute('active', '');
  });

  test('DTP-10: Step 4 marked success after Proceed', async ({ bridgedPage: page }) => {
    await goToStep5(page);
    await expect(page.locator('sh-stepper-item').nth(4)).toHaveAttribute('type', 'success');
  });

  test('DTP-11: Cancel sends CloseApp', async ({ bridgedPage: page }) => {
    await goToStep4(page);
    await page.locator('sh-button[label="Cancel"]').click();
    const sent = await getMessagesSent(page);
    expect(sent).toContainEqual({ Action: 'CloseApp' });
  });
});
