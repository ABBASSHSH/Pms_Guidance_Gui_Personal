import { test, expect, getMessagesSent, goToStep1 } from './fixtures';

test.describe('Suite 2 — Step 0: Introduction', () => {
  test('IN-01: title is displayed', async ({ bridgedPage: page }) => {
    await expect(page.locator('.title')).toContainText('Software Installation Process');
  });

  test('IN-02: description text is displayed', async ({ bridgedPage: page }) => {
    await expect(page.locator('.text')).toContainText(
      'A software package is available for installation'
    );
  });

  test('IN-03: info bar hint is present', async ({ bridgedPage: page }) => {
    await expect(page.locator('sh-menu-item[icon="information"]')).toBeVisible();
  });

  test('IN-04: Cancel and Proceed buttons are present', async ({ bridgedPage: page }) => {
    await expect(page.locator('sh-button[label="Cancel"]')).toBeVisible();
    await expect(page.locator('sh-button[label="Proceed"]')).toBeVisible();
  });

  test('IN-05: copyright text is present', async ({ bridgedPage: page }) => {
    await expect(page.locator('app-introduction .footer sh-text')).toContainText(
      '© Copyright 2025 Siemens Healthineers AG'
    );
  });

  test('IN-06: Proceed advances to Step 1', async ({ bridgedPage: page }) => {
    await goToStep1(page);
    await expect(page.locator('app-verify-installation-prerequisites')).toBeVisible();
    await expect(page.locator('sh-stepper-item').nth(1)).toHaveAttribute('active', '');
  });

  test('IN-07: Step 0 marked success after Proceed', async ({ bridgedPage: page }) => {
    await goToStep1(page);
    await expect(page.locator('sh-stepper-item').nth(0)).toHaveAttribute('type', 'success');
  });

  test('IN-08: Cancel sends CloseApp to backend', async ({ bridgedPage: page }) => {
    await page.locator('sh-button[label="Cancel"]').click();
    const sent = await getMessagesSent(page);
    expect(sent).toContainEqual({ Action: 'CloseApp' });
  });

  // ── M-01: info bar label text ─────────────────────────────────────────────

  test('IN-09: info bar label text is correct', async ({ bridgedPage: page }) => {
    // introduction.component.html uses [label] property binding on sh-menu-item
    // (not [attr.label]), so the label attribute is not in the DOM.
    // Verify by checking the text content of the sh-menu-item element instead.
    await expect(page.locator('sh-menu-item[icon="information"]')).toContainText(
      'Please click on "Proceed"'
    );
  });
});
