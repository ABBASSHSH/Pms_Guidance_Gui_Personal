import { test, expect, getMessagesSent, goToStep3, goToStep4 } from './fixtures';

test.describe('Suite 6 — Step 3: Save Patient Images', () => {
  test('SPI-01: title displayed', async ({ bridgedPage: page }) => {
    await goToStep3(page);
    await expect(page.locator('.title')).toContainText('Save Patient Images');
  });

  test('SPI-02: description text present', async ({ bridgedPage: page }) => {
    await goToStep3(page);
    await expect(page.locator('.text')).toContainText('Images that are not saved will be lost');
  });

  test('SPI-03: info bar hint present', async ({ bridgedPage: page }) => {
    await goToStep3(page);
    await expect(page.locator('sh-menu-item[icon="information"]')).toBeVisible();
  });

  test('SPI-04: Cancel and Proceed buttons visible', async ({ bridgedPage: page }) => {
    await goToStep3(page);
    await expect(page.locator('sh-button[label="Cancel"]')).toBeVisible();
    await expect(page.locator('sh-button[label="Proceed"]')).toBeVisible();
  });

  test('SPI-05: copyright text present', async ({ bridgedPage: page }) => {
    await goToStep3(page);
    await expect(page.locator('app-save-patient-images .footer sh-text')).toContainText(
      '© Copyright 2025 Siemens Healthineers AG'
    );
  });

  test('SPI-06: Proceed advances to Step 4', async ({ bridgedPage: page }) => {
    await goToStep4(page);
    await expect(page.locator('app-drive-to-park-position')).toBeVisible();
    await expect(page.locator('sh-stepper-item').nth(4)).toHaveAttribute('active', '');
  });

  test('SPI-07: Step 3 marked success after Proceed', async ({ bridgedPage: page }) => {
    await goToStep4(page);
    await expect(page.locator('sh-stepper-item').nth(3)).toHaveAttribute('type', 'success');
  });

  test('SPI-08: Cancel sends CloseApp', async ({ bridgedPage: page }) => {
    await goToStep3(page);
    await page.locator('sh-button[label="Cancel"]').click();
    const sent = await getMessagesSent(page);
    expect(sent).toContainEqual({ Action: 'CloseApp' });
  });
});
