import { test, expect, getMessagesSent, goToStep5 } from './fixtures';

test.describe('Suite 8 — Step 5: Installation In Progress', () => {
  test('IIP-01: spinner is visible', async ({ bridgedPage: page }) => {
    await goToStep5(page);
    await expect(page.locator('sh-spinner')).toBeVisible();
  });

  test('IIP-02: spinner label shows correct text', async ({ bridgedPage: page }) => {
    await goToStep5(page);
    await expect(page.locator('sh-spinner')).toContainText('Installing software. Please wait...');
  });

  test('IIP-03: no user action buttons present', async ({ bridgedPage: page }) => {
    await goToStep5(page);
    await expect(page.locator('sh-button')).toHaveCount(0);
  });

  test('IIP-04: Step 5 active in stepper', async ({ bridgedPage: page }) => {
    await goToStep5(page);
    await expect(page.locator('sh-stepper-item').nth(5)).toHaveAttribute('active', '');
  });

  test('IIP-05: InstallSoftware sent to backend', async ({ bridgedPage: page }) => {
    await goToStep5(page);
    const sent = await getMessagesSent(page);
    expect(sent).toContainEqual({ Action: 'InstallSoftware' });
  });

  test('IIP-06: InstallSoftware sent exactly once', async ({ bridgedPage: page }) => {
    await goToStep5(page);
    const sent = await getMessagesSent(page);
    const count = sent.filter(m => m.Action === 'InstallSoftware').length;
    expect(count).toBe(1);
  });

  // ── M-07: no copyright footer (regression guard) ──────────────────────────

  test('IIP-07: installation page has no footer copyright text', async ({ bridgedPage: page }) => {
    // Unlike all other steps, the installation-in-progress template intentionally has
    // no .footer element — it is a full-screen spinner with no user-action controls.
    // This test guards against accidentally adding a misplaced footer in future.
    await goToStep5(page);
    await expect(page.locator('app-installation-in-progress sh-text')).toHaveCount(0);
  });

  // ── Navigation terminal state ─────────────────────────────────────────────

  test('IIP-08: no further navigation is possible (no buttons present)', async ({
    bridgedPage: page,
  }) => {
    // Step 5 is the terminal step: the component renders no buttons, so the user
    // cannot navigate away. This guards against accidental forward navigation.
    await goToStep5(page);
    await expect(page.locator('app-installation-in-progress sh-button')).toHaveCount(0);
    await expect(page.locator('app-save-patient-images')).toHaveCount(0);
  });
});
