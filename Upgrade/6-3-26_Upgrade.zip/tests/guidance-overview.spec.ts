import {
  test,
  expect,
  sendToFrontend,
  goToStep1,
  goToStep2ViaOk,
  goToStep2ViaNotOk,
  goToStep3,
  goToStep4,
  goToStep5,
} from './fixtures';

test.describe('Suite 9 — Left Stepper Panel (Guidance Overview)', () => {
  // ── 9A: Structure and Labels ───────────────────────────────────────────────

  test.describe('9A — Structure and Labels', () => {
    test('GO-01: stepper panel is visible', async ({ bridgedPage: page }) => {
      await expect(page.locator('app-guidance-overview')).toBeVisible();
    });

    test('GO-02: sh-stepper has vertical and color="primary"', async ({ bridgedPage: page }) => {
      const stepper = page.locator('sh-stepper');
      await expect(stepper).toHaveAttribute('vertical', '');
      await expect(stepper).toHaveAttribute('color', 'primary');
    });

    test('GO-03: exactly 6 stepper items rendered', async ({ bridgedPage: page }) => {
      await expect(page.locator('sh-stepper-item')).toHaveCount(6);
    });

    test('GO-04: step items in correct order', async ({ bridgedPage: page }) => {
      const items = page.locator('sh-stepper-item');
      const labels = [
        'Introduction',
        'Verifying Installation Prerequisites',
        'Verification Result',
        'Save Patient Images',
        'Driving to Park Position',
        'Installation',
      ];
      for (let i = 0; i < labels.length; i++) {
        await expect(items.nth(i)).toHaveAttribute('label', labels[i]);
      }
    });

    test('GO-05: Step 0 label', async ({ bridgedPage: page }) => {
      await expect(page.locator('sh-stepper-item').nth(0)).toHaveAttribute('label', 'Introduction');
    });

    test('GO-06: Step 1 label', async ({ bridgedPage: page }) => {
      await expect(page.locator('sh-stepper-item').nth(1)).toHaveAttribute(
        'label',
        'Verifying Installation Prerequisites'
      );
    });

    test('GO-07: Step 2 label', async ({ bridgedPage: page }) => {
      await expect(page.locator('sh-stepper-item').nth(2)).toHaveAttribute(
        'label',
        'Verification Result'
      );
    });

    test('GO-08: Step 3 label', async ({ bridgedPage: page }) => {
      await expect(page.locator('sh-stepper-item').nth(3)).toHaveAttribute(
        'label',
        'Save Patient Images'
      );
    });

    test('GO-09: Step 4 label', async ({ bridgedPage: page }) => {
      await expect(page.locator('sh-stepper-item').nth(4)).toHaveAttribute(
        'label',
        'Driving to Park Position'
      );
    });

    test('GO-10: Step 5 label', async ({ bridgedPage: page }) => {
      await expect(page.locator('sh-stepper-item').nth(5)).toHaveAttribute(
        'label',
        'Installation'
      );
    });

    test('GO-11: labels update on language change to German', async ({ bridgedPage: page }) => {
      // Intercept and verify that requesting German triggers a fetch of de.json.
      // The I18nService calls HttpClient.get('assets/i18n/de.json') when
      // ShowSystemLanguage with Language='German' is received.
      const deJsonPromise = page.waitForResponse(
        resp => resp.url().includes('/assets/i18n/de.json') && resp.status() === 200,
        { timeout: 10000 }
      );
      await sendToFrontend(page, { Action: 'ShowSystemLanguage', Language: 'German' });
      const deJsonResponse = await deJsonPromise;
      expect(deJsonResponse.status()).toBe(200);
      // Verify the response body contains a known German translation key/value
      const body = await deJsonResponse.json();
      expect(body['introduction.title']).toBe('Software-Installationsprozess');
    });
  });

  // ── 9B: Active State Tracking ──────────────────────────────────────────────

  test.describe('9B — Active State Tracking', () => {
    test('GO-12: Step 0 active on first load', async ({ bridgedPage: page }) => {
      const items = page.locator('sh-stepper-item');
      await expect(items.nth(0)).toHaveAttribute('active', '');
      for (let i = 1; i <= 5; i++) {
        await expect(items.nth(i)).not.toHaveAttribute('active', '');
      }
    });

    test('GO-13: only one step active at a time after each navigation', async ({
      bridgedPage: page,
    }) => {
      const assertOneActive = async () => {
        const count = await page.locator('sh-stepper-item[active]').count();
        expect(count).toBe(1);
      };
      await assertOneActive();
      await goToStep1(page);
      await assertOneActive();
      await sendToFrontend(page, { Action: 'ShowInstallationPrerequisite', Status: 'OK' });
      await page.waitForSelector('app-verification-result');
      await assertOneActive();
    });

    test('GO-14: active moves to Step 1 after Proceed on Introduction', async ({
      bridgedPage: page,
    }) => {
      await goToStep1(page);
      await expect(page.locator('sh-stepper-item').nth(1)).toHaveAttribute('active', '');
      await expect(page.locator('sh-stepper-item').nth(0)).not.toHaveAttribute('active', '');
    });

    test('GO-15: active moves to Step 2 after backend OK', async ({ bridgedPage: page }) => {
      await goToStep2ViaOk(page);
      await expect(page.locator('sh-stepper-item').nth(2)).toHaveAttribute('active', '');
      await expect(page.locator('sh-stepper-item').nth(1)).not.toHaveAttribute('active', '');
    });

    test('GO-16: active moves to Step 2 after backend NotOk', async ({ bridgedPage: page }) => {
      await goToStep2ViaNotOk(page);
      await expect(page.locator('sh-stepper-item').nth(2)).toHaveAttribute('active', '');
      await expect(page.locator('sh-stepper-item').nth(1)).not.toHaveAttribute('active', '');
    });

    test('GO-17: active moves to Step 3 after Proceed with Installation', async ({
      bridgedPage: page,
    }) => {
      await goToStep3(page);
      await expect(page.locator('sh-stepper-item').nth(3)).toHaveAttribute('active', '');
    });

    test('GO-18: active moves to Step 4 after Proceed on Save Images', async ({
      bridgedPage: page,
    }) => {
      await goToStep4(page);
      await expect(page.locator('sh-stepper-item').nth(4)).toHaveAttribute('active', '');
    });

    test('GO-19: active moves to Step 5 after Proceed on Drive to Park', async ({
      bridgedPage: page,
    }) => {
      await goToStep5(page);
      await expect(page.locator('sh-stepper-item').nth(5)).toHaveAttribute('active', '');
    });
  });

  // ── 9C: Terminal Step States ───────────────────────────────────────────────

  test.describe('9C — Terminal Step States (type attribute)', () => {
    test('GO-20: pending steps have no [type] on first load', async ({ bridgedPage: page }) => {
      for (let i = 1; i <= 5; i++) {
        await expect(page.locator('sh-stepper-item').nth(i)).not.toHaveAttribute('type');
      }
    });

    test('GO-21: active step has no [type]', async ({ bridgedPage: page }) => {
      await expect(page.locator('sh-stepper-item[active]')).not.toHaveAttribute('type');
    });

    test('GO-22: Step 0 gets type="success" after Proceed', async ({ bridgedPage: page }) => {
      await goToStep1(page);
      await expect(page.locator('sh-stepper-item').nth(0)).toHaveAttribute('type', 'success');
    });

    test('GO-23: Step 1 gets type="success" after backend OK', async ({ bridgedPage: page }) => {
      await goToStep2ViaOk(page);
      await expect(page.locator('sh-stepper-item').nth(1)).toHaveAttribute('type', 'success');
    });

    test('GO-24: Step 1 gets type="error" after backend NotOk', async ({ bridgedPage: page }) => {
      await goToStep2ViaNotOk(page);
      await expect(page.locator('sh-stepper-item').nth(1)).toHaveAttribute('type', 'error');
    });

    test('GO-25: Step 2 gets type="success" after Proceed with Installation', async ({
      bridgedPage: page,
    }) => {
      await goToStep3(page);
      await expect(page.locator('sh-stepper-item').nth(2)).toHaveAttribute('type', 'success');
    });

    test('GO-26: Step 3 gets type="success" after Proceed on Save Images', async ({
      bridgedPage: page,
    }) => {
      await goToStep4(page);
      await expect(page.locator('sh-stepper-item').nth(3)).toHaveAttribute('type', 'success');
    });

    test('GO-27: Step 4 gets type="success" after Proceed on Drive to Park', async ({
      bridgedPage: page,
    }) => {
      await goToStep5(page);
      await expect(page.locator('sh-stepper-item').nth(4)).toHaveAttribute('type', 'success');
    });
  });

  // ── 9D: State Persistence ──────────────────────────────────────────────────

  test.describe('9D — State Persistence', () => {
    test('GO-28: completed steps stay success as wizard advances', async ({
      bridgedPage: page,
    }) => {
      await goToStep3(page);
      await expect(page.locator('sh-stepper-item').nth(0)).toHaveAttribute('type', 'success');
      await expect(page.locator('sh-stepper-item').nth(1)).toHaveAttribute('type', 'success');
      await expect(page.locator('sh-stepper-item').nth(2)).toHaveAttribute('type', 'success');
    });

    test('GO-29: error step stays error after navigation', async ({ bridgedPage: page }) => {
      await goToStep2ViaNotOk(page);
      // Confirm we are on Step 2 and Step 1 still shows error
      await expect(page.locator('app-verification-result')).toBeVisible();
      await expect(page.locator('sh-stepper-item').nth(1)).toHaveAttribute('type', 'error');
    });

    test('GO-30: Abort does not mark Step 1 as completed', async ({ bridgedPage: page }) => {
      await goToStep1(page);
      await page.locator('app-verify-installation-prerequisites .footer__actions sh-button').click();
      await page.locator('sh-modal sh-button[label="Abort"]').click();
      // After CloseApp the app has no more pages to show but Step 1 must not be success
      const type = await page.locator('sh-stepper-item').nth(1).getAttribute('type');
      expect(type).not.toBe('success');
    });

    test('GO-31: stepper panel visible at every step', async ({ bridgedPage: page }) => {
      const assertVisible = () => expect(page.locator('app-guidance-overview')).toBeVisible();
      await assertVisible();
      await goToStep1(page);
      await assertVisible();
      await sendToFrontend(page, { Action: 'ShowInstallationPrerequisite', Status: 'OK' });
      await page.waitForSelector('app-verification-result');
      await assertVisible();
      await page.locator('sh-button[label="Proceed with Installation"]').click();
      await page.waitForSelector('app-save-patient-images');
      await assertVisible();
      await page.locator('sh-button[label="Proceed"]').click();
      await page.waitForSelector('app-drive-to-park-position');
      await assertVisible();
      await page.locator('sh-button[label="Proceed"]').click();
      await page.waitForSelector('app-installation-in-progress');
      await assertVisible();
    });
  });

  // ── 9E: Initial State (Step 0) ─────────────────────────────────────────────

  test.describe('9E — Initial State Coverage', () => {
    test('GO-32: Step 0 has no [type] attribute on first load', async ({ bridgedPage: page }) => {
      // M-04: GO-20 correctly checks steps 1-5 have no type on load, but omits
      // Step 0 (Introduction) which is the active step and must also have no type.
      // Step 0 only receives type="success" after the user clicks Proceed.
      await expect(page.locator('sh-stepper-item').nth(0)).not.toHaveAttribute('type');
    });
  });
});
