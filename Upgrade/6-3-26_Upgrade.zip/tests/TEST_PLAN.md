# Playwright E2E Test Plan — Software Upgrade UI

## Application Overview

A **linear 6-step wizard** that guides a user through a medical software upgrade.
The wizard runs inside a WebView2 host. Navigation is driven by user clicks and backend messages.

### Wizard Step Flow

```
Step 0 – Introduction
    → Proceed  → Step 1
    → Cancel   → CloseApp

Step 1 – Verify Installation Prerequisites
    → Backend OK    → auto → Step 2 (success state)
    → Backend NotOk → auto → Step 2 (error state)
    → Abort confirm → CloseApp
    → Abort cancel  → stay on Step 1

Step 2 – Verification Result
    [Success] → Proceed with Installation → Step 3
    [Success] → Cancel                   → CloseApp
    [Error]   → Show Report              → (no-op)
    [Error]   → OK                       → (no-op)

Step 3 – Save Patient Images
    → Proceed → Step 4
    → Cancel  → CloseApp

Step 4 – Drive to Park Position
    → Proceed → Step 5
    → Cancel  → CloseApp

Step 5 – Installation In Progress
    → Spinner only — no user action; backend drives exit
```

---

## Communication Architecture

```
Backend (WebView2 host)
    │  postMessage(JSON)
    ▼
window.chrome.webview
    │
    ▼
ConnectionManager.messages$  ──→  Converter  ──→  HANDLERS[]
                                                     ├─ ShowInstallationPrerequisite
                                                     │    sets prereqStatus, marks step, navigates
                                                     └─ ShowSystemLanguage
                                                          calls i18n.setLanguage()

Frontend → Backend:
    CommunicationService.send(action) → chrome.webview.postMessage({ Action })

Outbound actions:
    'VerifyInstallationPrerequisite'   on entering Step 1
    'InstallSoftware'                  on entering Step 5
    'CloseApp'                         on Cancel / Abort confirmed
```

### Playwright WebView2 Bridge

The tests own a lightweight `window.chrome.webview` implementation injected via `page.addInitScript`.
It runs **before Angular bootstraps**, so `ConnectionManager.connect()` finds it in place. This has
no relation to the development `webview2.mock.ts` file — that file is never loaded during Playwright runs.

**What the bridge provides:**

| Capability | How it works |
|---|---|
| **Outbound spy** — capture messages Angular sends to the backend | Angular calls `chrome.webview.postMessage(payload)` → bridge appends to `window.__pw_messages_sent[]` |
| **Inbound trigger** — simulate a message arriving from the backend | Test calls `window.__pw_sendToFrontend(payload)` → bridge dispatches a `MessageEvent` to all registered listeners |

```typescript
// Injected in every test via a shared fixture — do not copy-paste per test
await page.addInitScript(() => {
  (window as any).__pw_messages_sent = [];
  const handlers: Function[] = [];
  (window as any).chrome = {
    webview: {
      addEventListener:    (_: string, fn: Function) => handlers.push(fn),
      removeEventListener: (_: string, fn: Function) => {
        const i = handlers.indexOf(fn); if (i > -1) handlers.splice(i, 1);
      },
      postMessage: (msg: any) => (window as any).__pw_messages_sent.push(msg),
    }
  };
  (window as any).__pw_sendToFrontend = (payload: object) => {
    const evt = { data: JSON.stringify(payload) } as MessageEvent;
    handlers.forEach(h => h(evt));
  };
});
```

**Reading outbound messages in a test:**
```typescript
const sent = await page.evaluate(() => (window as any).__pw_messages_sent);
expect(sent).toContainEqual({ Action: 'VerifyInstallationPrerequisite' });
```

**Sending an inbound message from a test:**
```typescript
await page.evaluate(() =>
  (window as any).__pw_sendToFrontend({ Action: 'ShowInstallationPrerequisite', Status: 'OK' })
);
await expect(page.locator('app-verification-result')).toBeVisible();
```

---

## Test Infrastructure

| Item | Detail |
|---|---|
| Framework | Playwright |
| App URL | `http://localhost:4200` (`npm start`) |
| WebView2 bridge | Playwright-owned `chrome.webview` stub injected via `addInitScript` — replaces the real WebView2 host for testing |
| Outbound spy | `window.__pw_messages_sent[]` — records every `chrome.webview.postMessage(payload)` call Angular makes |
| Inbound trigger | `page.evaluate(() => window.__pw_sendToFrontend({ ... }))` — simulates the backend sending a message to Angular |
| Fixtures | `tests/fixtures/index.ts` — shared fixture that injects the bridge before each test |

---

## Test Suites

---

### Suite 1 — App Shell
**File:** `tests/app-shell.spec.ts`

| ID | Test Case | Action / Trigger | Expected Result |
|---|---|---|---|
| AS-01 | App loads and shows the access bar | Navigate to `/` | `sh-access-bar` visible with label `"Software Upgrade"` |
| AS-02 | Left stepper panel is visible on load | Navigate to `/` | `app-guidance-overview` visible |
| AS-03 | Exactly 6 stepper items are rendered | Navigate to `/` | 6 `sh-stepper-item` elements in DOM |
| AS-04 | Introduction step is active on first load | Navigate to `/` | Step 0 `sh-stepper-item` has `active` attribute |
| AS-05 | App applies dark theme | Navigate to `/` | `sh-page` has `theme="dark"` |
| AS-06 | Introduction content panel is shown | Navigate to `/` | `app-introduction` visible |

---

### Suite 2 — Step 0: Introduction
**File:** `tests/introduction.spec.ts`

| ID | Test Case | Action / Trigger | Expected Result |
|---|---|---|---|
| IN-01 | Title is displayed | Load app | `"Software Installation Process"` visible |
| IN-02 | Description text is displayed | Load app | `"A software package is available for installation"` visible |
| IN-03 | Info bar hint is present | Load app | `sh-menu-item` with `information` icon visible |
| IN-04 | Cancel and Proceed buttons are present | Load app | Both `sh-button` elements visible |
| IN-05 | Copyright text is present | Load app | `"© Copyright 2025 Siemens Healthineers AG"` visible |
| IN-06 | Proceed advances to Step 1 | Click Proceed | `app-verify-installation-prerequisites` visible; Step 1 active in stepper |
| IN-07 | Step 0 marked success after Proceed | Click Proceed | Step 0 `sh-stepper-item` has `type="success"` |
| IN-08 | Cancel sends CloseApp to backend | Click Cancel | `__pw_messages_sent` contains `{ Action: 'CloseApp' }` |

---

### Suite 3 — Step 1: Verify Installation Prerequisites
**File:** `tests/verify-prereq.spec.ts`

#### 3A — Initial State

| ID | Test Case | Action / Trigger | Expected Result |
|---|---|---|---|
| VP-01 | Verification title displayed | Navigate to Step 1 | `"Final Verification before Installation Process"` visible |
| VP-02 | Progress bar starts at 0% | Navigate to Step 1 | Progress label shows `"0%"`; `sh-progress` has `value="0"` |
| VP-03 | In-progress status text shown | Navigate to Step 1 | `"Verifying the software prerequisites"` visible |
| VP-04 | No error styling on initial load | Navigate to Step 1 | `.text--error` class absent on status text |
| VP-05 | Abort button is visible | Navigate to Step 1 | `sh-button` with label `"Abort"` visible |
| VP-06 | VerifyInstallationPrerequisite sent to backend | Navigate to Step 1 | `__pw_messages_sent` contains `{ Action: 'VerifyInstallationPrerequisite' }` |
| VP-07 | VerifyInstallationPrerequisite sent exactly once | Navigate to Step 1 | Action appears exactly 1× in `__pw_messages_sent` |

#### 3B — Backend OK Response

| ID | Test Case | Action / Trigger | Expected Result |
|---|---|---|---|
| VP-08 | Progress updates to 100% | Bridge sends `{ Action: 'ShowInstallationPrerequisite', Status: 'OK' }` | Progress label shows `"100%"` |
| VP-09 | Status text updates to success | Bridge sends OK | `"Verification completed successfully"` visible |
| VP-10 | No error styling on success | Bridge sends OK | `.text--error` class absent |
| VP-11 | Auto-navigates to Step 2 | Bridge sends OK | `app-verification-result` visible |
| VP-12 | Step 1 marked success in stepper | Bridge sends OK | Step 1 `sh-stepper-item` has `type="success"` |

#### 3C — Backend NotOk Response

| ID | Test Case | Action / Trigger | Expected Result |
|---|---|---|---|
| VP-13 | Progress updates to 75% | Bridge sends `{ Action: 'ShowInstallationPrerequisite', Status: 'Not Ok' }` | Progress label shows `"75%"` |
| VP-14 | Status text updates to error | Bridge sends NotOk | `"Verification failed"` visible |
| VP-15 | Error styling applied | Bridge sends NotOk | `.text--error` class present on status text |
| VP-16 | Auto-navigates to Step 2 | Bridge sends NotOk | `app-verification-result` visible |
| VP-17 | Step 1 marked error in stepper | Bridge sends NotOk | Step 1 `sh-stepper-item` has `type="error"` |

#### 3D — Abort Modal

| ID | Test Case | Action / Trigger | Expected Result |
|---|---|---|---|
| VP-18 | Abort button opens confirmation modal | Click Abort | `sh-modal` with label `"Abort Verification"` visible |
| VP-19 | Modal shows correct description text | Open modal | `"Do you want to abort the verification"` visible in modal |
| VP-20 | Abort modal has Cancel and Abort buttons | Open modal | Both `sh-button` elements visible inside modal |
| VP-21 | Cancel closes modal; stays on Step 1 | Click Cancel in modal | Modal not visible; `app-verify-installation-prerequisites` still visible |
| VP-22 | Cancel in modal sends no backend message | Click Cancel in modal | `CloseApp` absent from `__pw_messages_sent` |
| VP-23 | Abort confirms and sends CloseApp | Click Abort in modal | `__pw_messages_sent` contains `{ Action: 'CloseApp' }` |

---

### Suite 4 — Step 2: Verification Result (Success Path)
**File:** `tests/verification-result-success.spec.ts`

| ID | Test Case | Action / Trigger | Expected Result |
|---|---|---|---|
| VRS-01 | Title displayed | Enter Step 2 via OK | `"Verification Result"` visible |
| VRS-02 | Success notification shown | Enter Step 2 via OK | `sh-notification-item[type="success"]` visible |
| VRS-03 | Success title text | Enter Step 2 via OK | `"Success"` visible |
| VRS-04 | Success subtitle text | Enter Step 2 via OK | `"Verification of the software prerequisites completed"` visible |
| VRS-05 | Success body text | Enter Step 2 via OK | `"ready for software installation"` visible |
| VRS-06 | Success info hint | Enter Step 2 via OK | `"To continue with the installation"` visible |
| VRS-07 | Cancel and Proceed with Installation buttons visible | Enter Step 2 via OK | Both buttons present |
| VRS-08 | No Show Report button on success | Enter Step 2 via OK | `sh-button[label="Show Report"]` not in DOM |
| VRS-09 | Proceed with Installation advances to Step 3 | Click Proceed with Installation | `app-save-patient-images` visible; Step 3 active in stepper |
| VRS-10 | Step 2 marked success in stepper after Proceed | Click Proceed with Installation | Step 2 `sh-stepper-item` has `type="success"` |
| VRS-11 | Cancel sends CloseApp | Click Cancel | `__pw_messages_sent` contains `{ Action: 'CloseApp' }` |

---

### Suite 5 — Step 2: Verification Result (Error Path)
**File:** `tests/verification-result-error.spec.ts`

| ID | Test Case | Action / Trigger | Expected Result |
|---|---|---|---|
| VRE-01 | Title displayed | Enter Step 2 via NotOk | `"Verification Result"` visible |
| VRE-02 | Error notification shown | Enter Step 2 via NotOk | `sh-notification-item[type="error"]` visible |
| VRE-03 | Error title text | Enter Step 2 via NotOk | `"Error"` visible |
| VRE-04 | Error subtitle text | Enter Step 2 via NotOk | `"Prerequisites for the software update failed"` visible |
| VRE-05 | Error body text | Enter Step 2 via NotOk | `"Proceeding with the software installation is not possible"` visible |
| VRE-06 | Error info hint | Enter Step 2 via NotOk | `"system stays with the previous software"` visible |
| VRE-07 | Show Report and OK buttons visible | Enter Step 2 via NotOk | Both buttons present |
| VRE-08 | No Proceed with Installation button on error | Enter Step 2 via NotOk | `sh-button[label="Proceed with Installation"]` not in DOM |
| VRE-09 | OK button is clickable without crash | Click OK | No error; no navigation |
| VRE-10 | Show Report button is clickable without crash | Click Show Report | No error; no navigation |

---

### Suite 6 — Step 3: Save Patient Images
**File:** `tests/save-patient-images.spec.ts`

| ID | Test Case | Action / Trigger | Expected Result |
|---|---|---|---|
| SPI-01 | Title displayed | Navigate to Step 3 | `"Save Patient Images"` visible |
| SPI-02 | Description text present | Navigate to Step 3 | `"Images that are not saved will be lost"` visible |
| SPI-03 | Info bar hint present | Navigate to Step 3 | `sh-menu-item` with `information` icon visible |
| SPI-04 | Cancel and Proceed buttons visible | Navigate to Step 3 | Both `sh-button` elements present |
| SPI-05 | Copyright text present | Navigate to Step 3 | `"© Copyright 2025 Siemens Healthineers AG"` visible |
| SPI-06 | Proceed advances to Step 4 | Click Proceed | `app-drive-to-park-position` visible; Step 4 active in stepper |
| SPI-07 | Step 3 marked success after Proceed | Click Proceed | Step 3 `sh-stepper-item` has `type="success"` |
| SPI-08 | Cancel sends CloseApp | Click Cancel | `__pw_messages_sent` contains `{ Action: 'CloseApp' }` |

---

### Suite 7 — Step 4: Drive to Park Position
**File:** `tests/drive-to-park.spec.ts`

| ID | Test Case | Action / Trigger | Expected Result |
|---|---|---|---|
| DTP-01 | Title displayed | Navigate to Step 4 | `"Drive To Park Position"` visible |
| DTP-02 | Step 1 instruction visible | Navigate to Step 4 | `"Select the Park Position"` visible |
| DTP-03 | Step 2 instruction visible | Navigate to Step 4 | `"move the system approximately 20 cm"` visible |
| DTP-04 | Step 3 instruction visible | Navigate to Step 4 | `"Stand Test"` visible |
| DTP-05 | Step 4 instruction visible | Navigate to Step 4 | `"Emergency Stop"` visible |
| DTP-06 | Info bar hint present | Navigate to Step 4 | `sh-menu-item` with `information` icon visible |
| DTP-07 | Cancel and Proceed buttons visible | Navigate to Step 4 | Both `sh-button` elements present |
| DTP-08 | Copyright text present | Navigate to Step 4 | `"© Copyright 2025 Siemens Healthineers AG"` visible |
| DTP-09 | Proceed advances to Step 5 | Click Proceed | `app-installation-in-progress` visible; Step 5 active in stepper |
| DTP-10 | Step 4 marked success after Proceed | Click Proceed | Step 4 `sh-stepper-item` has `type="success"` |
| DTP-11 | Cancel sends CloseApp | Click Cancel | `__pw_messages_sent` contains `{ Action: 'CloseApp' }` |

---

### Suite 8 — Step 5: Installation In Progress
**File:** `tests/installation-in-progress.spec.ts`

| ID | Test Case | Action / Trigger | Expected Result |
|---|---|---|---|
| IIP-01 | Spinner is visible | Navigate to Step 5 | `sh-spinner` element present |
| IIP-02 | Spinner label shows correct text | Navigate to Step 5 | `"Installing software. Please wait..."` visible |
| IIP-03 | No user action buttons present | Navigate to Step 5 | No Proceed / Cancel / Abort `sh-button` in DOM |
| IIP-04 | Step 5 active in stepper | Navigate to Step 5 | Step 5 `sh-stepper-item` has `active` attribute |
| IIP-05 | InstallSoftware sent to backend | Navigate to Step 5 | `__pw_messages_sent` contains `{ Action: 'InstallSoftware' }` |
| IIP-06 | InstallSoftware sent exactly once | Navigate to Step 5 | Action appears exactly 1× in `__pw_messages_sent` |

---

### Suite 9 — Left Stepper Panel (Guidance Overview)
**File:** `tests/guidance-overview.spec.ts`

#### 9A — Structure and Labels

| ID | Test Case | Action / Trigger | Expected Result |
|---|---|---|---|
| GO-01 | Stepper panel is visible | Load app | `app-guidance-overview` visible throughout |
| GO-02 | `sh-stepper` has correct attributes | Load app | `vertical` and `color="primary"` present |
| GO-03 | Exactly 6 stepper items rendered | Load app | 6 `sh-stepper-item` elements in DOM |
| GO-04 | Step items in correct order | Load app | Labels appear top-to-bottom in wizard sequence order |
| GO-05 | Step 0 label | Load app | `"Introduction"` in stepper |
| GO-06 | Step 1 label | Load app | `"Verifying Installation Prerequisites"` in stepper |
| GO-07 | Step 2 label | Load app | `"Verification Result"` in stepper |
| GO-08 | Step 3 label | Load app | `"Save Patient Images"` in stepper |
| GO-09 | Step 4 label | Load app | `"Driving to Park Position"` in stepper |
| GO-10 | Step 5 label | Load app | `"Installation"` in stepper |
| GO-11 | Labels update on language change | Bridge sends `{ Action: 'ShowSystemLanguage', Language: 'German' }` | All step labels show corresponding German text from `de.json` |

#### 9B — Active State Tracking

| ID | Test Case | Action / Trigger | Expected Result |
|---|---|---|---|
| GO-12 | Step 0 active on first load | Load app | Step 0 has `active`; Steps 1–5 do not |
| GO-13 | Only one step active at a time | Any navigation | Exactly 1 `sh-stepper-item[active]` in DOM at all times |
| GO-14 | Active moves to Step 1 after Proceed on Introduction | Click Proceed | Step 1 has `active`; Step 0 does not |
| GO-15 | Active moves to Step 2 after backend OK | Bridge sends `{ Action: 'ShowInstallationPrerequisite', Status: 'OK' }` | Step 2 has `active`; Step 1 does not |
| GO-16 | Active moves to Step 2 after backend NotOk | Bridge sends `{ Action: 'ShowInstallationPrerequisite', Status: 'Not Ok' }` | Step 2 has `active`; Step 1 does not |
| GO-17 | Active moves to Step 3 after Proceed with Installation | Click Proceed with Installation | Step 3 has `active` |
| GO-18 | Active moves to Step 4 after Proceed on Save Images | Click Proceed | Step 4 has `active` |
| GO-19 | Active moves to Step 5 after Proceed on Drive to Park | Click Proceed | Step 5 has `active` |

#### 9C — Terminal Step States (`[type]` attribute)

| ID | Test Case | Action / Trigger | Expected Result |
|---|---|---|---|
| GO-20 | Pending steps have no `[type]` on first load | Load app | Steps 1–5 have no `type` attribute |
| GO-21 | Active step has no `[type]` | Any active step | Active `sh-stepper-item` has no `type` attribute |
| GO-22 | Step 0 gets `type="success"` after Proceed | Click Proceed on Introduction | Step 0: `type="success"` |
| GO-23 | Step 1 gets `type="success"` after backend OK | Bridge sends `{ Action: 'ShowInstallationPrerequisite', Status: 'OK' }` | Step 1: `type="success"` |
| GO-24 | Step 1 gets `type="error"` after backend NotOk | Bridge sends `{ Action: 'ShowInstallationPrerequisite', Status: 'Not Ok' }` | Step 1: `type="error"` |
| GO-25 | Step 2 gets `type="success"` after Proceed with Installation | Click Proceed with Installation | Step 2: `type="success"` |
| GO-26 | Step 3 gets `type="success"` after Proceed on Save Images | Click Proceed | Step 3: `type="success"` |
| GO-27 | Step 4 gets `type="success"` after Proceed on Drive to Park | Click Proceed | Step 4: `type="success"` |

#### 9D — State Persistence

| ID | Test Case | Action / Trigger | Expected Result |
|---|---|---|---|
| GO-28 | Completed steps stay `success` as wizard advances | Reach Step 3 | Steps 0–2 still show `type="success"` |
| GO-29 | Error step stays `error` after navigation | Bridge sends NotOk → view Step 2 | Step 1 `type="error"` persists |
| GO-30 | Abort does not mark Step 1 as completed | Abort confirmed on Step 1 | Step 1 does not get `type="success"` |
| GO-31 | Stepper panel visible at every step | Navigate through all steps | `app-guidance-overview` visible at Steps 0–5 |

---

### Suite 10 — Frontend → Backend Outbound Messages
**File:** `tests/messaging-outbound.spec.ts`

| ID | Test Case | Action / Trigger | Expected `__pw_messages_sent` |
|---|---|---|---|
| OUT-01 | App boot sends nothing | Load app; do not click | `__pw_messages_sent` is empty |
| OUT-02 | Entering Step 1 sends VerifyInstallationPrerequisite | Click Proceed on Step 0 | Contains `{ Action: 'VerifyInstallationPrerequisite' }` |
| OUT-03 | VerifyInstallationPrerequisite sent exactly once | Enter Step 1 | Action appears exactly 1× |
| OUT-04 | Cancel on Introduction sends CloseApp | Click Cancel on Step 0 | Contains `{ Action: 'CloseApp' }` |
| OUT-05 | Cancel on Verification Result (success) sends CloseApp | Bridge sends OK; navigate to Step 2; click Cancel | Contains `{ Action: 'CloseApp' }` |
| OUT-06 | Abort confirmed on Step 1 sends CloseApp | Open modal; click Abort | Contains `{ Action: 'CloseApp' }` |
| OUT-07 | Abort cancelled sends nothing | Open modal; click Cancel | `CloseApp` absent from sent messages |
| OUT-08 | Cancel on Save Patient Images sends CloseApp | Click Cancel on Step 3 | Contains `{ Action: 'CloseApp' }` |
| OUT-09 | Cancel on Drive to Park sends CloseApp | Click Cancel on Step 4 | Contains `{ Action: 'CloseApp' }` |
| OUT-10 | Entering Step 5 sends InstallSoftware | Click Proceed on Step 4 | Contains `{ Action: 'InstallSoftware' }` |
| OUT-11 | InstallSoftware sent exactly once | Enter Step 5 | Action appears exactly 1× |
| OUT-12 | Full happy path sends only expected actions | Complete all steps | Sent actions are exactly: `VerifyInstallationPrerequisite`, `InstallSoftware` (no extras) |
| OUT-13 | Every postMessage payload has an Action field | Any trigger | All entries in `__pw_messages_sent` have an `Action` key |

---

### Suite 11 — Backend → Frontend: ShowSystemLanguage
**File:** `tests/messaging-system-language.spec.ts`

> These tests verify that when Angular receives a `ShowSystemLanguage` message via `window.chrome.webview`, the UI language updates correctly. The test sends the message using `__pw_sendToFrontend`, which dispatches a `MessageEvent` to `ConnectionManager` — identical to what the real WebView2 host would do.

| ID | Test Case | Action / Trigger | Expected Result |
|---|---|---|---|
| SL-01 | English language message keeps English UI | Bridge sends `{ Action: 'ShowSystemLanguage', Language: 'English' }` | App text in English |
| SL-02 | German language message switches UI to German | Bridge sends `{ Action: 'ShowSystemLanguage', Language: 'German' }` | App text shows German strings from `de.json` |
| SL-03 | Language applied before first render | Bridge sends German message via `addInitScript` before Angular boots | First render shows correct German text |
| SL-04 | Unknown language falls back gracefully | Bridge sends `{ Action: 'ShowSystemLanguage', Language: 'zz-ZZ' }` | No crash; existing language unchanged |
| SL-05 | Missing Language field ignored gracefully | Bridge sends `{ Action: 'ShowSystemLanguage' }` | No crash; no navigation |
| SL-06 | Language change mid-flow updates stepper labels | Bridge sends German while on Step 1 | Stepper labels update to German immediately |

---

### Suite 12 — Backend → Frontend: ShowInstallationPrerequisite
**File:** `tests/messaging-prereq-result.spec.ts`

> These tests verify that when Angular receives a `ShowInstallationPrerequisite` message via `window.chrome.webview`, it processes the `Status` field correctly, updates the UI, and navigates to Step 2. The test sends the message using `__pw_sendToFrontend` — identical to what the real WebView2 host sends.

#### 12A — Status OK

| ID | Test Case | Action / Trigger | Expected Result |
|---|---|---|---|
| PR-01 | Progress bar reaches 100% | Bridge sends `{ Action: 'ShowInstallationPrerequisite', Status: 'OK' }` | Progress label shows `"100%"` |
| PR-02 | Status text updates to success | Bridge sends OK | `"Verification completed successfully"` visible |
| PR-03 | No error styling | Bridge sends OK | `.text--error` absent |
| PR-04 | Auto-navigates to Step 2 | Bridge sends OK | `app-verification-result` visible |
| PR-05 | Step 1 marked success in stepper | Bridge sends OK | Step 1 `sh-stepper-item` has `type="success"` |
| PR-06 | Step 2 shows success notification | Bridge sends OK; view Step 2 | `sh-notification-item[type="success"]` visible |

#### 12B — Status NotOk

| ID | Test Case | Action / Trigger | Expected Result |
|---|---|---|---|
| PR-07 | Progress bar reaches 75% | Bridge sends `{ Action: 'ShowInstallationPrerequisite', Status: 'Not Ok' }` | Progress label shows `"75%"` |
| PR-08 | Status text updates to error | Bridge sends NotOk | `"Verification failed"` visible |
| PR-09 | Error styling applied | Bridge sends NotOk | `.text--error` present on status text |
| PR-10 | Auto-navigates to Step 2 | Bridge sends NotOk | `app-verification-result` visible |
| PR-11 | Step 1 marked error in stepper | Bridge sends NotOk | Step 1 `sh-stepper-item` has `type="error"` |
| PR-12 | Step 2 shows error notification | Bridge sends NotOk; view Step 2 | `sh-notification-item[type="error"]` visible |

#### 12C — Invalid and Edge Cases

| ID | Test Case | Action / Trigger | Expected Result |
|---|---|---|---|
| PR-13 | Invalid Status field — no navigation | Bridge sends `{ Action: 'ShowInstallationPrerequisite', Status: 'bad' }` | No navigation; progress unchanged |
| PR-14 | Missing Status field — no crash | Bridge sends `{ Action: 'ShowInstallationPrerequisite' }` | No crash; no navigation |
| PR-15 | Duplicate OK message — idempotent | Bridge sends OK twice | Navigation happens once; no double-step |
| PR-16 | Message received while abort modal open | Bridge sends OK while modal visible | Modal dismissed; navigates to Step 2 |

---

### Suite 13 — Communication Robustness
**File:** `tests/messaging-robustness.spec.ts`

> These tests verify that Angular's `ConnectionManager` and `Converter` handle malformed or unexpected messages from the WebView2 host without crashing or changing UI state.

| ID | Test Case | Action / Trigger | Expected Result |
|---|---|---|---|
| RB-01 | Empty JSON object | Bridge sends `{}` | No crash; no navigation |
| RB-02 | Message with no Action field | Bridge sends `{ Status: 'OK' }` | Discarded silently; no crash |
| RB-03 | Unknown Action value | Bridge sends `{ Action: 'UnknownAction' }` | Discarded silently; no crash |
| RB-04 | Malformed JSON string | Bridge dispatches raw `"not-json{{{"` as `MessageEvent.data` | No crash; ConnectionManager discards |
| RB-05 | Null message data | Bridge dispatches `null` as `MessageEvent.data` | No crash; ConnectionManager discards |
| RB-06 | Rapid repeated OK messages | Bridge sends OK 10× in quick succession | UI stable; no crash; navigated once |
| RB-07 | Wrong action casing | Bridge sends `{ Action: 'showInstallationPrerequisite' }` | Not handled (case-sensitive); no crash |
| RB-08 | Large payload with extra fields | Bridge sends OK + 10 KB of extra fields | Parsed OK; extra fields ignored; navigates normally |

---

### Suite 14 — Full E2E Flows
**File:** `tests/e2e-flows.spec.ts`

#### 14A — Happy Path

| ID | Test Case | Action / Trigger | Expected Result |
|---|---|---|---|
| E2E-01 | Complete success flow | Proceed → Step 1 → Bridge sends OK → Proceed with Installation → Proceed → Proceed | All 6 steps rendered in order; Installation spinner visible at end |
| E2E-02 | Stepper tracks progress through all steps | Full happy path | After each step, correct stepper item is active |
| E2E-03 | All completed steps show success type | Full happy path | Steps 0–4 all have `type="success"` on reaching Step 5 |
| E2E-04 | Outbound messages correct in order | Full happy path | `__pw_messages_sent` contains `VerifyInstallationPrerequisite` then `InstallSoftware` |
| E2E-05 | No console errors during full flow | Full happy path | Zero browser console errors |

#### 14B — Error / Cancel Path

| ID | Test Case | Action / Trigger | Expected Result |
|---|---|---|---|
| E2E-06 | Prereq fails → error result shown | Proceed → Step 1 → Bridge sends NotOk | Step 2 shows error notification; Step 1 has `type="error"` |
| E2E-07 | Cancel on Introduction closes app | Click Cancel on Step 0 | `CloseApp` in `__pw_messages_sent`; no further navigation |
| E2E-08 | Cancel on Save Images closes app | Navigate to Step 3; click Cancel | `CloseApp` in `__pw_messages_sent` |
| E2E-09 | Cancel on Drive to Park closes app | Navigate to Step 4; click Cancel | `CloseApp` in `__pw_messages_sent` |
| E2E-10 | Abort on Step 1 closes app | Open modal; confirm abort | `CloseApp` in `__pw_messages_sent`; no Step 2 navigation |
| E2E-11 | Abort cancelled → verification continues | Open modal; cancel | Modal dismissed; still on Step 1; no `CloseApp` sent |

#### 14C — Backend-Driven Sequencing

| ID | Test Case | Action / Trigger | Expected Result |
|---|---|---|---|
| E2E-12 | Language set before any step renders | Bridge sends German via `addInitScript` before Angular boots | First step shows German text |
| E2E-13 | Language switch mid-flow updates all labels | Bridge sends German while on Step 1 | Stepper and content labels update immediately |
| E2E-14 | Full round-trip: outbound then inbound | Enter Step 1 → verify `VerifyInstallationPrerequisite` sent → Bridge sends OK | `__pw_messages_sent` contains `VerifyInstallationPrerequisite`; UI navigates to Step 2 |
| E2E-15 | App does not crash during full run | Complete happy path | No unhandled exceptions; all components render |

---

## Test Count Summary

| Suite | Cases | File |
|---|---|---|
| 1 — App Shell | 6 | `app-shell.spec.ts` |
| 2 — Introduction | 8 | `introduction.spec.ts` |
| 3 — Verify Installation Prerequisites | 23 | `verify-prereq.spec.ts` |
| 4 — Verification Result (Success) | 11 | `verification-result-success.spec.ts` |
| 5 — Verification Result (Error) | 10 | `verification-result-error.spec.ts` |
| 6 — Save Patient Images | 8 | `save-patient-images.spec.ts` |
| 7 — Drive to Park Position | 11 | `drive-to-park.spec.ts` |
| 8 — Installation In Progress | 6 | `installation-in-progress.spec.ts` |
| 9 — Guidance Overview / Left Stepper | 31 | `guidance-overview.spec.ts` |
| 10 — Outbound Messages | 13 | `messaging-outbound.spec.ts` |
| 11 — ShowSystemLanguage | 6 | `messaging-system-language.spec.ts` |
| 12 — ShowInstallationPrerequisite | 16 | `messaging-prereq-result.spec.ts` |
| 13 — Communication Robustness | 8 | `messaging-robustness.spec.ts` |
| 14 — Full E2E Flows | 15 | `e2e-flows.spec.ts` |
| **Total** | **172** | **14 files** |

---

## Implementation Priority

| Priority | Suites | Reason |
|---|---|---|
| **P1** | 14A Happy Path, 14C Backend-Driven | Core flow must work end-to-end |
| **P1** | 10 Outbound Messages | Every backend call must be verified correct |
| **P1** | 12 ShowInstallationPrerequisite | Most complex message — drives navigation and UI state |
| **P1** | 3 Verify Installation Prerequisites | Most complex step — progress, error state, abort modal |
| **P1** | 9B + 9C Active state and step types | Stepper must always reflect wizard position |
| **P2** | 4 + 5 Verification Result (both paths) | Two distinct UI branches from the same entry point |
| **P2** | 9A + 9D Labels and state persistence | Label correctness and durability across navigation |
| **P2** | 11 ShowSystemLanguage | Internationalisation |
| **P2** | 14B Error / Cancel Path | Medically significant abort and cancel flows |
| **P2** | 2, 6, 7 Introduction, Save Images, Drive to Park | Simpler steps — render correctness and navigation |
| **P3** | 13 Communication Robustness | Defensive malformed-message coverage |
| **P3** | 1, 8 App Shell, Installation In Progress | Structural sanity checks and spinner verification |

---

## Implementation Notes

- **WebView2 bridge**: The Playwright fixture injects `window.chrome.webview` via `addInitScript` before Angular loads. The development `webview2.mock.ts` file is **not used** in tests — it is only active in the dev server for manual browser testing.
- **Outbound message assertions**: After the triggering UI action, read `await page.evaluate(() => (window as any).__pw_messages_sent)` and assert the expected `{ Action: '...' }` payload is present. This confirms Angular called `chrome.webview.postMessage(...)` correctly.
- **Inbound message simulation**: Call `await page.evaluate(() => (window as any).__pw_sendToFrontend({ Action: '...', ... }))` to simulate the backend sending a message. The bridge dispatches it as a `MessageEvent` on `window.chrome.webview`, which `ConnectionManager` picks up exactly as it would from the real WebView2 host.
- **No real backend needed**: Every backend → frontend message is simulated by `__pw_sendToFrontend`. Every frontend → backend message is captured by `__pw_messages_sent`. Tests are fully self-contained.
- **Text assertions**: Use resolved English strings from `src/assets/i18n/en.json`, not raw i18n keys.
- **SHUI element selectors**: `page.locator('sh-button[label="Proceed"]')`, `page.locator('sh-stepper-item[active]')`.
- **Wait strategy**: Always `await expect(locator).toBeVisible()` after navigation — never `waitForTimeout`.
- **Test isolation**: Each test navigates from `/` with a fresh page — no shared state between tests.
