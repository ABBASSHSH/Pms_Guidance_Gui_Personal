import { defineConfig, devices } from '@playwright/test';

export default defineConfig({
  // Look for test files in the "tests" directory, relative to this configuration file.
  testDir: 'tests',

  // Exclude the fixture helper from being treated as a test file.
  testIgnore: ['**/fixtures/**'],

  // Run all tests in parallel.
  fullyParallel: true,

  // Fail the build on CI if you accidentally left test.only in the source code.
  forbidOnly: !!process.env['CI'],

  // Retry on CI only.
  retries: process.env['CI'] ? 2 : 0,

  // Opt out of parallel tests on CI.
  workers: process.env['CI'] ? 1 : undefined,

  // Reporter: HTML report + short console summary.
  reporter: [['html', { open: 'never' }], ['list']],

  use: {
    // Base URL to use in actions like `await page.goto('/')`.
    baseURL: 'http://localhost:4200',

    // Collect trace when retrying the failed test.
    trace: 'on-first-retry',

    // Screenshot on every failure for easy diagnosis.
    screenshot: 'only-on-failure',

    // Record video on first retry so failures are reproducible.
    video: 'on-first-retry',

    // Global action/navigation timeout per step.
    actionTimeout: 10_000,
    navigationTimeout: 15_000,
  },

  // Global test timeout (ms). Long enough for the full 6-step happy path.
  timeout: 30_000,

  // How long to wait for expect() assertions.
  expect: {
    timeout: 8_000,
  },

  // Configure projects for major browsers.
  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
    },
  ],

  // Run your local dev server before starting the tests.
  webServer: {
    command: 'npm run start',
    url: 'http://localhost:4200',
    reuseExistingServer: !process.env['CI'],
    timeout: 120000,
  },
});