import { bootstrapApplication } from '@angular/platform-browser';
import { AppComponent } from './app/app.component';
import { appConfig } from './app/app.config';
import { bootstrapShui } from './app/core/shui/shui.bootstrap';
import { initializeWebView2Mock } from './app/core/communication/webview2.mock';

async function main(): Promise<void> {
  // Install the WebView2 mock BEFORE bootstrapping Angular so that
  // window.chrome.webview is present when ConnectionManager.connect() runs.
  initializeWebView2Mock();

  bootstrapShui();

  await bootstrapApplication(AppComponent, appConfig);
}

main().catch(err => console.error(err));
