import { AsyncPipe } from '@angular/common';
import { Component, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { map } from 'rxjs';

import { UiStateManagementService } from '../../core/update/ui-state-management-service';
import { CommunicationService } from '../../core/communication/communication.service';
import { PrereqStatus } from '../../core/update/update.models';
import { LogService } from '../../core/log/log.service';
import { TranslatePipe } from '../../core/i18n';

@Component({
    selector: 'app-verification-result',
    imports: [AsyncPipe, TranslatePipe],
    templateUrl: './verification-result.component.html',
    styleUrls: ['./verification-result.component.css'],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class VerificationResultComponent {
  private readonly source = 'VerificationResultComponent';

  readonly vm$ = this.uiStateUpdate.prereqStatus$.pipe(
    map(status => ({
      prereqStatus: status,
      isOk: status === PrereqStatus.OK,
    }))
  );

  constructor(
    private readonly uiStateUpdate: UiStateManagementService,
    private readonly comm: CommunicationService,
    private readonly log: LogService
  ) {}

  onProceedInstall(): void {
    this.log.info(this.source, 'proceed', 'Proceed with installation clicked');
    this.log.flush();
    this.uiStateUpdate.next();
  }

  onCancel(): void {
    this.log.info(this.source, 'cancel', 'Cancel clicked');
    this.log.flush();
    this.comm.send('CloseApp');
  }

  onOk(): void {
    this.log.info(this.source, 'ok', 'OK clicked');
    this.log.flush();
  }

  onShowReport(): void {
    this.log.info(this.source, 'showReport', 'Show report clicked');
    this.log.flush();
  }
}
