﻿import { ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { VerifyInstallationPrerequisitesComponent } from './verify-installation-prerequisites.component';
import { UiStateManagementService } from '../../core/update/ui-state-management-service';
import { CommunicationService } from '../../core/communication/communication.service';
import { LogService } from '../../core/log/log.service';
import { I18nService } from '../../core/i18n';
import { BehaviorSubject } from 'rxjs';
import { GuidanceOverviewState, StepId, StepStatus, PrereqStatus, GUIDANCE_OVERVIEW_LABELS } from '../../core/update/update.models';

describe('VerifyInstallationPrerequisitesComponent', () => {
  let component: VerifyInstallationPrerequisitesComponent;
  let fixture: ComponentFixture<VerifyInstallationPrerequisitesComponent>;
  let mockStateService: jasmine.SpyObj<UiStateManagementService>;
  let mockCommService: jasmine.SpyObj<CommunicationService>;
  let mockLogService: jasmine.SpyObj<LogService>;
  let mockI18nService: jasmine.SpyObj<I18nService>;
  let prereqSubject: BehaviorSubject<PrereqStatus>;

  const INITIAL_STATUS_TEXT_KEY = 'verification.status.inProgress';
  const SUCCESS_STATUS_TEXT_KEY = 'verification.status.success';
  const ERROR_STATUS_TEXT_KEY = 'verification.status.error';

  const createMockState = (): GuidanceOverviewState => {
    const stepStatuses = {} as Record<StepId, StepStatus>;
    GUIDANCE_OVERVIEW_LABELS.forEach(config => {
      stepStatuses[config.id] = config.id === StepId.VerifyPrereq ? StepStatus.Active : StepStatus.Pending;
    });
    return { stepStatuses };
  };

  beforeEach(async () => {
    prereqSubject = new BehaviorSubject<PrereqStatus>(PrereqStatus.Unknown);

    mockStateService = jasmine.createSpyObj('UiStateManagementService', [
      'next', 'complete', 'error', 'setActive', 'setPrereqStatus',
    ]);
    Object.defineProperty(mockStateService, 'state$', {
      get: () => new BehaviorSubject<GuidanceOverviewState>(createMockState()).asObservable(),
    });
    Object.defineProperty(mockStateService, 'prereqStatus$', {
      get: () => prereqSubject.asObservable(),
    });

    mockCommService = jasmine.createSpyObj('CommunicationService', ['send']);
    mockLogService = jasmine.createSpyObj('LogService', ['info', 'debug', 'warn', 'error', 'flush']);
    mockI18nService = jasmine.createSpyObj('I18nService', ['translate', 'setLanguage']);
    mockI18nService.translate.and.callFake((key: string) => key);

    await TestBed.configureTestingModule({
      imports: [VerifyInstallationPrerequisitesComponent],
      providers: [
        { provide: UiStateManagementService, useValue: mockStateService },
        { provide: CommunicationService, useValue: mockCommService },
        { provide: LogService, useValue: mockLogService },
        { provide: I18nService, useValue: mockI18nService },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(VerifyInstallationPrerequisitesComponent);
    component = fixture.componentInstance;
  });

  // ── Component Initialization ──────────────────────────────────────────────

  describe('Component Initialization', () => {
    it('should create', () => {
      expect(component).toBeTruthy();
    });

    it('should have initial progress of 0', () => {
      expect(component.progress).toBe(0);
    });

    it('should have initial statusTextKey', () => {
      expect(component.statusTextKey).toBe(INITIAL_STATUS_TEXT_KEY);
    });

    it('should have isError false initially', () => {
      expect(component.isError).toBe(false);
    });

    it('should have showAbortModal false initially', () => {
      expect(component.showAbortModal).toBeFalse();
    });
  });

  // ── ngOnInit Lifecycle ────────────────────────────────────────────────────

  describe('ngOnInit Lifecycle', () => {
    it('should log step entry on init', fakeAsync(() => {
      fixture.detectChanges();
      tick();

      expect(mockLogService.info).toHaveBeenCalledWith(
        'VerifyPrerequisites',
        'step.entered',
        'Entered Verify Installation Prerequisites step.'
      );
    }));

    it('should send VerifyInstallationPrerequisite to backend', fakeAsync(() => {
      fixture.detectChanges();
      tick();

      expect(mockCommService.send).toHaveBeenCalledWith('VerifyInstallationPrerequisite');
    }));

    it('should log debug message after sending', fakeAsync(() => {
      fixture.detectChanges();
      tick();

      expect(mockLogService.debug).toHaveBeenCalledWith(
        'VerifyPrerequisites',
        'be.request',
        'Sent VerifyInstallationPrerequisite to backend.'
      );
    }));

    it('should flush logs after entering and sending backend request', fakeAsync(() => {
      fixture.detectChanges();
      tick();

      expect(mockLogService.flush).toHaveBeenCalledTimes(1);
    }));

    it('should flush after all init logging, not before', fakeAsync(() => {
      const callOrder: string[] = [];
      mockLogService.info.and.callFake(() => callOrder.push('info'));
      mockLogService.debug.and.callFake(() => callOrder.push('debug'));
      mockLogService.flush.and.callFake(() => callOrder.push('flush'));

      fixture.detectChanges();
      tick();

      expect(callOrder).toEqual(['info', 'debug', 'flush']);
    }));

    it('should subscribe to prereqStatus$ changes', fakeAsync(() => {
      fixture.detectChanges();
      tick();

      prereqSubject.next(PrereqStatus.OK);
      tick();

      expect(component.progress).toBe(100);
    }));
  });

  // ── Success Scenario ──────────────────────────────────────────────────────

  describe('Success Scenario', () => {
    it('should set progress to 100 on success', fakeAsync(() => {
      fixture.detectChanges();
      tick();

      prereqSubject.next(PrereqStatus.OK);
      tick();

      expect(component.progress).toBe(100);
    }));

    it('should update statusTextKey on success', fakeAsync(() => {
      fixture.detectChanges();
      tick();

      prereqSubject.next(PrereqStatus.OK);
      tick();

      expect(component.statusTextKey).toBe(SUCCESS_STATUS_TEXT_KEY);
    }));

    it('should keep isError false on success', fakeAsync(() => {
      fixture.detectChanges();
      tick();

      prereqSubject.next(PrereqStatus.OK);
      tick();

      expect(component.isError).toBe(false);
    }));

    it('should not call uiStateUpdate.next() on success', fakeAsync(() => {
      fixture.detectChanges();
      tick();

      prereqSubject.next(PrereqStatus.OK);
      tick();

      expect(mockStateService.next).not.toHaveBeenCalled();
    }));
  });

  // ── Error Scenario ────────────────────────────────────────────────────────

  describe('Error Scenario', () => {
    it('should set isError to true on error', fakeAsync(() => {
      fixture.detectChanges();
      tick();

      prereqSubject.next(PrereqStatus.NotOk);
      tick();

      expect(component.isError).toBe(true);
    }));

    it('should update statusTextKey on error', fakeAsync(() => {
      fixture.detectChanges();
      tick();

      prereqSubject.next(PrereqStatus.NotOk);
      tick();

      expect(component.statusTextKey).toBe(ERROR_STATUS_TEXT_KEY);
    }));

    it('should set progress to 75 on error', fakeAsync(() => {
      fixture.detectChanges();
      tick();

      prereqSubject.next(PrereqStatus.NotOk);
      tick();

      expect(component.progress).toBe(75);
    }));

    it('should not call uiStateUpdate.next() on error', fakeAsync(() => {
      fixture.detectChanges();
      tick();

      prereqSubject.next(PrereqStatus.NotOk);
      tick();

      expect(mockStateService.next).not.toHaveBeenCalled();
    }));
  });

  // ── onAbort Handler ───────────────────────────────────────────────────────

  describe('onAbort Handler', () => {
    it('should show the abort confirmation modal', () => {
      expect(component.showAbortModal).toBeFalse();
      component.onAbort();
      expect(component.showAbortModal).toBeTrue();
    });

    it('should log warn when abort is triggered', () => {
      component.onAbort();

      expect(mockLogService.warn).toHaveBeenCalledWith(
        'VerifyPrerequisites',
        'ui.abort',
        jasmine.stringContaining('User pressed Abort')
      );
    });

    it('should handle multiple abort calls', () => {
      component.onAbort();
      component.onAbort();
      expect(mockLogService.warn).toHaveBeenCalledTimes(2);
    });
  });

  // ── onAbortConfirmed Handler ──────────────────────────────────────────────

  describe('onAbortConfirmed Handler', () => {
    it('should close the modal', () => {
      component.showAbortModal = true;
      component.onAbortConfirmed();
      expect(component.showAbortModal).toBeFalse();
    });

    it('should send CloseApp to backend', () => {
      component.onAbortConfirmed();
      expect(mockCommService.send).toHaveBeenCalledWith('CloseApp');
    });

    it('should log warn on confirmed abort', () => {
      component.onAbortConfirmed();
      expect(mockLogService.warn).toHaveBeenCalledWith(
        'VerifyPrerequisites',
        'ui.abort.confirmed',
        jasmine.stringContaining('User confirmed abort')
      );
    });

    it('should log debug after sending CloseApp', () => {
      component.onAbortConfirmed();
      expect(mockLogService.debug).toHaveBeenCalledWith(
        'VerifyPrerequisites',
        'be.request',
        'Sent CloseApp to backend.'
      );
    });

    it('should call setPrereqStatus with NotOk', () => {
      component.onAbortConfirmed();
      expect(mockStateService.setPrereqStatus).toHaveBeenCalledWith(PrereqStatus.NotOk);
    });

    it('should flush logs after sending CloseApp', () => {
      const callOrder: string[] = [];
      mockLogService.warn.and.callFake(() => callOrder.push('warn'));
      mockLogService.debug.and.callFake(() => callOrder.push('debug'));
      mockLogService.flush.and.callFake(() => callOrder.push('flush'));
      mockCommService.send.and.callFake(() => callOrder.push('send'));

      component.onAbortConfirmed();

      // Expected order: warn → send(CloseApp) → debug → flush
      // flush must come last to ensure no log loss after CloseApp
      const flushIndex = callOrder.indexOf('flush');
      const debugIndex = callOrder.lastIndexOf('debug');
      expect(flushIndex).toBeGreaterThan(-1);
      expect(flushIndex).toBeGreaterThan(debugIndex);
    });

    it('should update UI state via prereqStatus$ subscription', fakeAsync(() => {
      // Wire the spy so setPrereqStatus actually pushes into the subject,
      // simulating the real service behaviour.
      mockStateService.setPrereqStatus.and.callFake((s: PrereqStatus) => prereqSubject.next(s));

      fixture.detectChanges();
      tick();

      component.onAbortConfirmed();
      tick();

      expect(component.isError).toBeTrue();
      expect(component.progress).toBe(75);
      expect(component.statusTextKey).toBe(ERROR_STATUS_TEXT_KEY);
    }));
  });

  // ── onAbortCancelled Handler ──────────────────────────────────────────────

  describe('onAbortCancelled Handler', () => {
    it('should close the modal', () => {
      component.showAbortModal = true;
      component.onAbortCancelled();
      expect(component.showAbortModal).toBeFalse();
    });

    it('should not set isError', () => {
      component.isError = false;
      component.onAbortCancelled();
      expect(component.isError).toBeFalse();
    });

    it('should not call setPrereqStatus', () => {
      component.onAbortCancelled();
      expect(mockStateService.setPrereqStatus).not.toHaveBeenCalled();
    });

    it('should log info on cancelled abort', () => {
      component.onAbortCancelled();
      expect(mockLogService.info).toHaveBeenCalledWith(
        'VerifyPrerequisites',
        'ui.abort.cancelled',
        jasmine.stringContaining('User cancelled abort')
      );
    });

    it('should flush logs on cancelled abort', () => {
      component.onAbortCancelled();
      expect(mockLogService.flush).toHaveBeenCalledTimes(1);
    });
  });

  // ── DestroyRef and Cleanup ────────────────────────────────────────────────

  describe('DestroyRef and Cleanup', () => {
    it('should stop receiving prereqStatus$ updates after destroy', fakeAsync(() => {
      fixture.detectChanges();
      tick();

      fixture.destroy();

      prereqSubject.next(PrereqStatus.OK);
      tick();

      // progress stays at initial 0 because the subscription was torn down
      expect(component.progress).not.toBe(100);
    }));
  });

  // ── Logging Behavior ─────────────────────────────────────────────────────

  describe('Logging Behavior', () => {
    it('should use correct source for all init logs', fakeAsync(() => {
      fixture.detectChanges();
      tick();

      mockLogService.info.calls.all().forEach(call => {
        expect(call.args[0]).toBe('VerifyPrerequisites');
      });
      mockLogService.debug.calls.all().forEach(call => {
        expect(call.args[0]).toBe('VerifyPrerequisites');
      });
    }));

    it('should use correct event types for init', fakeAsync(() => {
      fixture.detectChanges();
      tick();

      expect(mockLogService.info).toHaveBeenCalledWith(
        jasmine.any(String),
        'step.entered',
        jasmine.any(String)
      );
      expect(mockLogService.debug).toHaveBeenCalledWith(
        jasmine.any(String),
        'be.request',
        jasmine.any(String)
      );
    }));

    it('should use warn level for abort, not info', () => {
      component.onAbort();

      expect(mockLogService.warn).toHaveBeenCalled();
      expect(mockLogService.info).not.toHaveBeenCalledWith(
        jasmine.any(String),
        'ui.abort',
        jasmine.any(String)
      );
    });
  });

  // ── Integration Tests ─────────────────────────────────────────────────────

  describe('Integration Tests', () => {
    it('should complete full success flow', fakeAsync(() => {
      fixture.detectChanges();
      tick();

      expect(mockCommService.send).toHaveBeenCalledWith('VerifyInstallationPrerequisite');

      prereqSubject.next(PrereqStatus.OK);
      tick();

      expect(component.progress).toBe(100);
      expect(component.statusTextKey).toBe(SUCCESS_STATUS_TEXT_KEY);
      expect(component.isError).toBe(false);
    }));

    it('should complete full error flow', fakeAsync(() => {
      fixture.detectChanges();
      tick();

      prereqSubject.next(PrereqStatus.NotOk);
      tick();

      expect(component.progress).toBe(75);
      expect(component.statusTextKey).toBe(ERROR_STATUS_TEXT_KEY);
      expect(component.isError).toBe(true);
    }));

    it('should handle abort during verification', () => {
      component.onAbort();

      expect(component.showAbortModal).toBeTrue();
      expect(mockLogService.warn).toHaveBeenCalledWith(
        'VerifyPrerequisites',
        'ui.abort',
        jasmine.stringContaining('User pressed Abort')
      );
    });

    it('should handle full abort-confirmed flow', () => {
      component.onAbort();
      component.onAbortConfirmed();

      expect(component.showAbortModal).toBeFalse();
      expect(mockCommService.send).toHaveBeenCalledWith('CloseApp');
      expect(mockStateService.setPrereqStatus).toHaveBeenCalledWith(PrereqStatus.NotOk);
    });

    it('should handle full abort-cancelled flow', () => {
      component.onAbort();
      component.onAbortCancelled();

      expect(component.showAbortModal).toBeFalse();
      expect(mockStateService.setPrereqStatus).not.toHaveBeenCalled();
      expect(mockCommService.send).not.toHaveBeenCalledWith('CloseApp');
    });

    it('should ignore Unknown prereqStatus', fakeAsync(() => {
      fixture.detectChanges();
      tick();

      prereqSubject.next(PrereqStatus.Unknown);
      tick();

      expect(component.progress).toBe(0);
      expect(component.statusTextKey).toBe(INITIAL_STATUS_TEXT_KEY);
    }));

    it('should handle rapid status changes', fakeAsync(() => {
      fixture.detectChanges();
      tick();

      prereqSubject.next(PrereqStatus.OK);
      prereqSubject.next(PrereqStatus.OK);
      tick();

      expect(component.progress).toBe(100);
      expect(component.isError).toBe(false);
    }));
  });
});
