import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { provideHttpClient } from '@angular/common/http';
import { GuidanceOverviewComponent } from './guidance-overview.component';
import { LogService } from '../../core/log/log.service';
import {
  StepId,
  StepStatus,
  GuidanceOverviewState,
  GUIDANCE_OVERVIEW_LABELS,
} from '../../core/update/update.models';

describe('GuidanceOverviewComponent', () => {
  let component: GuidanceOverviewComponent;
  let fixture: ComponentFixture<GuidanceOverviewComponent>;
  let mockLogService: jasmine.SpyObj<LogService>;

  const createMockState = (
    activeStepId: StepId = StepId.Introduction,
    overrides: Partial<Record<StepId, StepStatus>> = {}
  ): GuidanceOverviewState => {
    const stepStatuses: Record<StepId, StepStatus> = {
      [StepId.Introduction]: StepStatus.Pending,
      [StepId.VerifyPrereq]: StepStatus.Pending,
      [StepId.VerificationResult]: StepStatus.Pending,
      [StepId.SaveImages]: StepStatus.Pending,
      [StepId.DriveToPark]: StepStatus.Pending,
      [StepId.Installation]: StepStatus.Pending,
      // Mark the intended active step as Active unless overridden
      [activeStepId]: StepStatus.Active,
      ...overrides,
    };
    return {
      stepStatuses,
    };
  };

  beforeEach(async () => {
    mockLogService = jasmine.createSpyObj('LogService', ['debug', 'info', 'warn', 'error']);

    await TestBed.configureTestingModule({
      imports: [GuidanceOverviewComponent],
      providers: [
        provideHttpClient(),
        { provide: LogService, useValue: mockLogService },
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    }).compileComponents();

    fixture = TestBed.createComponent(GuidanceOverviewComponent);
    component = fixture.componentInstance;
  });

  describe('Component Creation', () => {
    it('should create', () => {
      expect(component).toBeTruthy();
    });

    it('should have steps array from GUIDANCE_OVERVIEW_LABELS', () => {
      expect(component.steps).toBe(GUIDANCE_OVERVIEW_LABELS);
      expect(component.steps.length).toBe(6);
    });

    it('should have all step IDs in order', () => {
      expect(component.steps[0].id).toBe(StepId.Introduction);
      expect(component.steps[1].id).toBe(StepId.VerifyPrereq);
      expect(component.steps[2].id).toBe(StepId.VerificationResult);
      expect(component.steps[3].id).toBe(StepId.SaveImages);
      expect(component.steps[4].id).toBe(StepId.DriveToPark);
      expect(component.steps[5].id).toBe(StepId.Installation);
    });
  });

  describe('getStatus', () => {
    beforeEach(() => {
      component.state = createMockState(StepId.Introduction, {
        [StepId.Introduction]: StepStatus.Active,
        [StepId.VerifyPrereq]: StepStatus.Pending,
        [StepId.VerificationResult]: StepStatus.Success,
        [StepId.SaveImages]: StepStatus.Error,
      });
    });

    it('should return Active status for Introduction', () => {
      expect(component.getStatus(StepId.Introduction)).toBe(StepStatus.Active);
    });

    it('should return Pending status for VerifyPrereq', () => {
      expect(component.getStatus(StepId.VerifyPrereq)).toBe(StepStatus.Pending);
    });

    it('should return Completed status for VerificationResult', () => {
      expect(component.getStatus(StepId.VerificationResult)).toBe(StepStatus.Success);
    });

    it('should return Error status for SaveImages', () => {
      expect(component.getStatus(StepId.SaveImages)).toBe(StepStatus.Error);
    });
  });

  describe('getType', () => {
    beforeEach(() => {
      component.state = createMockState(StepId.Introduction, {
        [StepId.Introduction]: StepStatus.Active,
        [StepId.VerifyPrereq]: StepStatus.Pending,
        [StepId.VerificationResult]: StepStatus.Success,
        [StepId.SaveImages]: StepStatus.Error,
        [StepId.DriveToPark]: StepStatus.Warning,
      });
    });

    it('should return "success" for Success status', () => {
      expect(component.getType(StepId.VerificationResult)).toBe('success');
    });

    it('should return "error" for Error status', () => {
      expect(component.getType(StepId.SaveImages)).toBe('error');
    });

    it('should return "warning" for Warning status', () => {
      expect(component.getType(StepId.DriveToPark)).toBe('warning');
    });

    it('should return null for Active status', () => {
      expect(component.getType(StepId.Introduction)).toBeNull();
    });

    it('should return null for Pending status', () => {
      expect(component.getType(StepId.VerifyPrereq)).toBeNull();
    });

    it('should pass through all terminal status values directly', () => {
      component.state = createMockState(StepId.Installation, {
        [StepId.Introduction]: StepStatus.Success,
        [StepId.VerifyPrereq]: StepStatus.Success,
        [StepId.VerificationResult]: StepStatus.Success,
      });

      expect(component.getType(StepId.Introduction)).toBe('success');
      expect(component.getType(StepId.VerifyPrereq)).toBe('success');
      expect(component.getType(StepId.VerificationResult)).toBe('success');
    });
  });

  describe('isActive', () => {
    it('should return true when step status is Active', () => {
      component.state = createMockState(StepId.Introduction, {
        [StepId.Introduction]: StepStatus.Active,
      });

      expect(component.isActive(StepId.Introduction)).toBeTrue();
    });

    it('should return false when step status is Pending (even if it is the intended active step)', () => {
      component.state = createMockState(StepId.VerifyPrereq, {
        [StepId.VerifyPrereq]: StepStatus.Pending, // Explicitly overridden to Pending
      });

      expect(component.isActive(StepId.VerifyPrereq)).toBeFalse();
    });

    it('should return false when step is not active and not activeStepId', () => {
      component.state = createMockState(StepId.Introduction, {
        [StepId.Introduction]: StepStatus.Active,
        [StepId.VerifyPrereq]: StepStatus.Pending,
      });

      expect(component.isActive(StepId.VerifyPrereq)).toBeFalse();
    });

    it('should return false for Completed step', () => {
      component.state = createMockState(StepId.VerifyPrereq, {
        [StepId.Introduction]: StepStatus.Success,
      });

      expect(component.isActive(StepId.Introduction)).toBeFalse();
    });

    it('should return false for Error step', () => {
      component.state = createMockState(StepId.SaveImages, {
        [StepId.VerifyPrereq]: StepStatus.Error,
      });

      expect(component.isActive(StepId.VerifyPrereq)).toBeFalse();
    });
  });

  describe('Template Rendering', () => {
    beforeEach(() => {
      component.state = createMockState(StepId.VerifyPrereq, {
        [StepId.Introduction]: StepStatus.Success,
        [StepId.VerifyPrereq]: StepStatus.Active,
      });
      fixture.detectChanges();
    });

    it('should render sh-stepper element', () => {
      const stepper = fixture.nativeElement.querySelector('sh-stepper');
      expect(stepper).toBeTruthy();
      expect(stepper.getAttribute('vertical')).toBe('');
      expect(stepper.getAttribute('color')).toBe('primary');
    });

    it('should render all 6 sh-stepper-item elements', () => {
      const items = fixture.nativeElement.querySelectorAll('sh-stepper-item');
      expect(items.length).toBe(6);
    });

    it('should set active attribute for active step', () => {
      const items = fixture.nativeElement.querySelectorAll('sh-stepper-item');
      expect(items[1].active).toBeTruthy(); // VerifyPrereq is active
    });

    it('should set type=success for completed steps', () => {
      const items = fixture.nativeElement.querySelectorAll('sh-stepper-item');
      expect(items[0].type).toBe('success'); // Introduction is completed
    });

    it('should not set type for pending steps', () => {
      const items = fixture.nativeElement.querySelectorAll('sh-stepper-item');
      expect(items[2].type).toBeFalsy(); // VerificationResult is pending
    });

    it('should set type=error for error steps', () => {
      component.state = createMockState(StepId.SaveImages, {
        [StepId.VerifyPrereq]: StepStatus.Error,
      });
      fixture.detectChanges();

      const items = fixture.nativeElement.querySelectorAll('sh-stepper-item');
      expect(items[1].type).toBe('error');
    });
  });

  describe('State Transitions', () => {
    it('should update display when state changes', () => {
      // Initial state
      component.state = createMockState(StepId.Introduction, {
        [StepId.Introduction]: StepStatus.Active,
      });
      fixture.detectChanges();

      let items = fixture.nativeElement.querySelectorAll('sh-stepper-item');
      expect(items[0].active).toBeTruthy();
      expect(items[1].active).toBeFalsy();

      // Transition to next step
      component.state = createMockState(StepId.VerifyPrereq, {
        [StepId.Introduction]: StepStatus.Success,
        [StepId.VerifyPrereq]: StepStatus.Active,
      });
      fixture.detectChanges();

      items = fixture.nativeElement.querySelectorAll('sh-stepper-item');
      expect(items[0].type).toBe('success');
      expect(items[0].active).toBeFalsy();
      expect(items[1].active).toBeTruthy();
    });

    it('should handle error state transition', () => {
      component.state = createMockState(StepId.VerificationResult, {
        [StepId.Introduction]: StepStatus.Success,
        [StepId.VerifyPrereq]: StepStatus.Error,
        [StepId.VerificationResult]: StepStatus.Active,
      });
      fixture.detectChanges();

      const items = fixture.nativeElement.querySelectorAll('sh-stepper-item');
      expect(items[1].type).toBe('error');
      expect(items[2].active).toBeTruthy();
    });
  });

  describe('Edge Cases', () => {
    it('should handle all steps in pending state', () => {
      component.state = createMockState(StepId.Introduction);
      fixture.detectChanges();

      const items = fixture.nativeElement.querySelectorAll('sh-stepper-item');
      items.forEach((item: any) => {
        expect(item.type).toBeFalsy();
      });
    });

    it('should handle last step being active', () => {
      component.state = createMockState(StepId.Installation, {
        [StepId.Introduction]: StepStatus.Success,
        [StepId.VerifyPrereq]: StepStatus.Success,
        [StepId.VerificationResult]: StepStatus.Success,
        [StepId.SaveImages]: StepStatus.Success,
        [StepId.DriveToPark]: StepStatus.Success,
        [StepId.Installation]: StepStatus.Active,
      });
      fixture.detectChanges();

      const items = fixture.nativeElement.querySelectorAll('sh-stepper-item');
      expect(items[5].active).toBeTruthy();
      for (let i = 0; i < 5; i++) {
        expect(items[i].type).toBe('success');
      }
    });

    it('should handle multiple error steps', () => {
      component.state = createMockState(StepId.SaveImages, {
        [StepId.VerifyPrereq]: StepStatus.Error,
        [StepId.VerificationResult]: StepStatus.Error,
      });
      fixture.detectChanges();

      const items = fixture.nativeElement.querySelectorAll('sh-stepper-item');
      expect(items[1].type).toBe('error');
      expect(items[2].type).toBe('error');
    });
  });
});
