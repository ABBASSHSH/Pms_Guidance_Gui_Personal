import { Component, Input, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { StepId, StepStatus, GuidanceOverviewState, GuidanceOverviewLabel, GUIDANCE_OVERVIEW_LABELS } from '../../core/update/update.models';
import { TranslatePipe } from '../../core/i18n';

@Component({
    selector: 'app-guidance-overview',
    imports: [TranslatePipe],
    templateUrl: './guidance-overview.component.html',
    styleUrls: ['./guidance-overview.component.css'],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class GuidanceOverviewComponent {
  @Input({ required: true }) state!: GuidanceOverviewState;

  /** Steps labels for iteration */
  readonly steps: readonly GuidanceOverviewLabel[] = GUIDANCE_OVERVIEW_LABELS;

  /** Returns the lifecycle status of the given step. */
  getStatus(stepId: StepId): StepStatus {
    return this.state.stepStatuses[stepId];
  }

  /**
   * Returns the SHUI `[type]` value for a step.
   * Terminal statuses (`Success`, `Error`, `Warning`) are passed through directly since their enum
   * values match the SHUI attribute strings. Transitional statuses (`Pending`, `Active`) yield `null`
   * so that the attribute is cleared.
   */
  getType(stepId: StepId): string | null {
    const status = this.getStatus(stepId);
    switch (status) {
      case StepStatus.Success:
      case StepStatus.Error:
      case StepStatus.Warning:
        return status;
      default:
        return null;
    }
  }

  isActive(stepId: StepId): boolean {
    return this.getStatus(stepId) === StepStatus.Active;
  }
}
