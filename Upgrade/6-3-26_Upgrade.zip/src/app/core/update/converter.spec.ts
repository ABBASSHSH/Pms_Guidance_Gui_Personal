import { TestBed, fakeAsync, tick } from '@angular/core/testing';
import { Observable, Subject } from 'rxjs';
import { Converter } from './converter';
import { MESSAGE_RECEIVER } from '../communication/i-message-receiver.token';
import { IMessageReceiver } from '../communication/i-message-receiver';
import { UiStateManagementService } from './ui-state-management-service';
import { PrereqStatus, StepId } from './update.models';
import { I18nService } from '../i18n';
import { LogService } from '../log/log.service';
import { RawMessage } from '../communication/raw-message';

describe('Converter', () => {
  let converter: Converter;
  let mockMessageReceiver: IMessageReceiver;
  let mockUiStateManagementService: jasmine.SpyObj<UiStateManagementService>;
  let mockI18nService: jasmine.SpyObj<I18nService>;
  let mockLogService: jasmine.SpyObj<LogService>;
  let messageSubject: Subject<RawMessage>;

  beforeEach(() => {
    messageSubject = new Subject<RawMessage>();

    // Create mock IMessageReceiver
    mockMessageReceiver = {
      messages$: messageSubject.asObservable()
    };

    mockUiStateManagementService = jasmine.createSpyObj('UiStateManagementService', [
      'setPrereqStatus',
      'complete',
      'error',
      'setActive',
      'next',
    ]);

    mockI18nService = jasmine.createSpyObj('I18nService', [
      'setLanguage',
      'translate',
      'getTranslations',
    ]);

    mockLogService = jasmine.createSpyObj('LogService', ['info', 'debug', 'warn', 'error']);

    TestBed.configureTestingModule({
      providers: [
        Converter,
        { provide: MESSAGE_RECEIVER, useValue: mockMessageReceiver },
        { provide: UiStateManagementService, useValue: mockUiStateManagementService },
        { provide: I18nService, useValue: mockI18nService },
        { provide: LogService, useValue: mockLogService },
      ],
    });

    converter = TestBed.inject(Converter);
  });

  afterEach(() => {
    messageSubject.complete();
  });

  describe('Service Creation', () => {
    it('should create the converter service', () => {
      expect(converter).toBeTruthy();
    });

    it('should inject IMessageReceiver', () => {
      expect(converter['receiver']).toBeDefined();
    });

    it('should inject UiStateManagementService', () => {
      expect(converter['state']).toBeDefined();
    });
  });

  describe('start() Method', () => {
    it('should subscribe to message receiver observable', () => {
      spyOn(mockMessageReceiver.messages$, 'pipe').and.returnValue(messageSubject.asObservable());
      
      converter.start();

      expect(mockMessageReceiver.messages$.pipe).toHaveBeenCalled();
    });

    it('should not throw error when called multiple times', () => {
      expect(() => {
        converter.start();
        converter.start();
        converter.start();
      }).not.toThrow();
    });
  });

  describe('Message Processing - OK Status', () => {
    beforeEach(() => {
      converter.start();
    });

    it('should process ShowInstallationPrerequisite message with OK status', fakeAsync(() => {
      const message = {
        Action: 'ShowInstallationPrerequisite',
        Status: PrereqStatus.OK,
      };

      messageSubject.next(message);
      tick();

      expect(mockUiStateManagementService.setPrereqStatus).toHaveBeenCalledWith(PrereqStatus.OK);
    }));

    it('should call complete() for OK status', fakeAsync(() => {
      const message = {
        Action: 'ShowInstallationPrerequisite',
        Status: PrereqStatus.OK,
      };

      messageSubject.next(message);
      tick();

      expect(mockUiStateManagementService.complete).toHaveBeenCalledWith(StepId.VerifyPrereq);
    }));

    it('should not call error() for OK status', fakeAsync(() => {
      const message = {
        Action: 'ShowInstallationPrerequisite',
        Status: PrereqStatus.OK,
      };

      messageSubject.next(message);
      tick();

      expect(mockUiStateManagementService.error).not.toHaveBeenCalled();
    }));

    it('should navigate to verification result immediately for OK status', fakeAsync(() => {
      const message = {
        Action: 'ShowInstallationPrerequisite',
        Status: PrereqStatus.OK,
      };

      messageSubject.next(message);
      tick();

      expect(mockUiStateManagementService.setActive).toHaveBeenCalledWith(StepId.VerificationResult);
    }));
  });

  describe('Message Processing - Not Ok Status', () => {
    beforeEach(() => {
      converter.start();
    });

    it('should process ShowInstallationPrerequisite message with Not Ok status', fakeAsync(() => {
      const message = {
        Action: 'ShowInstallationPrerequisite',
        Status: PrereqStatus.NotOk,
      };

      messageSubject.next(message);
      tick();

      expect(mockUiStateManagementService.setPrereqStatus).toHaveBeenCalledWith(PrereqStatus.NotOk);
    }));

    it('should call error() for Not Ok status', fakeAsync(() => {
      const message = {
        Action: 'ShowInstallationPrerequisite',
        Status: PrereqStatus.NotOk,
      };

      messageSubject.next(message);
      tick();

      expect(mockUiStateManagementService.error).toHaveBeenCalledWith(StepId.VerifyPrereq);
    }));

    it('should not call complete() for Not Ok status', fakeAsync(() => {
      const message = {
        Action: 'ShowInstallationPrerequisite',
        Status: PrereqStatus.NotOk,
      };

      messageSubject.next(message);
      tick();

      expect(mockUiStateManagementService.complete).not.toHaveBeenCalled();
    }));

    it('should navigate to verification result immediately for Not Ok status', fakeAsync(() => {
      const message = {
        Action: 'ShowInstallationPrerequisite',
        Status: PrereqStatus.NotOk,
      };

      messageSubject.next(message);
      tick();

      expect(mockUiStateManagementService.setActive).toHaveBeenCalledWith(StepId.VerificationResult);
    }));
  });

  describe('Message Filtering', () => {
    beforeEach(() => {
      converter.start();
    });

    it('should ignore messages with wrong Action', fakeAsync(() => {
      const message = {
        Action: 'WrongAction',
        Status: 'OK',
      };

      messageSubject.next(message);
      tick();

      expect(mockUiStateManagementService.setPrereqStatus).not.toHaveBeenCalled();
      expect(mockUiStateManagementService.complete).not.toHaveBeenCalled();
      expect(mockUiStateManagementService.error).not.toHaveBeenCalled();
    }));

    it('should ignore messages with invalid Status', fakeAsync(() => {
      const message = {
        Action: 'ShowInstallationPrerequisite',
        Status: 'InvalidStatus',
      };

      messageSubject.next(message);
      tick();

      expect(mockUiStateManagementService.setPrereqStatus).not.toHaveBeenCalled();
    }));

    it('should ignore messages without Status field', fakeAsync(() => {
      const message = {
        Action: 'ShowInstallationPrerequisite',
      };

      messageSubject.next(message);
      tick();

      expect(mockUiStateManagementService.setPrereqStatus).not.toHaveBeenCalled();
    }));

    it('should ignore messages with null Status', fakeAsync(() => {
      const message = {
        Action: 'ShowInstallationPrerequisite',
        Status: null,
      };

      messageSubject.next(message);
      tick();

      expect(mockUiStateManagementService.setPrereqStatus).not.toHaveBeenCalled();
    }));

    it('should ignore completely unrelated messages', fakeAsync(() => {
      const message = {
        SomeField: 'SomeValue',
      };

      messageSubject.next(message);
      tick();

      expect(mockUiStateManagementService.setPrereqStatus).not.toHaveBeenCalled();
    }));
  });

  describe('Multiple Messages', () => {
    beforeEach(() => {
      converter.start();
    });

    it('should process multiple OK messages', fakeAsync(() => {
      const message1 = {
        Action: 'ShowInstallationPrerequisite',
        Status: PrereqStatus.OK,
      };

      const message2 = {
        Action: 'ShowInstallationPrerequisite',
        Status: PrereqStatus.OK,
      };

      messageSubject.next(message1);
      tick();
      messageSubject.next(message2);
      tick();

      expect(mockUiStateManagementService.setPrereqStatus).toHaveBeenCalledTimes(2);
      expect(mockUiStateManagementService.complete).toHaveBeenCalledTimes(2);
    }));

    it('should process alternating OK and Not Ok messages', fakeAsync(() => {
      const message1 = {
        Action: 'ShowInstallationPrerequisite',
        Status: PrereqStatus.OK,
      };

      const message2 = {
        Action: 'ShowInstallationPrerequisite',
        Status: PrereqStatus.NotOk,
      };

      messageSubject.next(message1);
      tick();
      messageSubject.next(message2);
      tick();

      expect(mockUiStateManagementService.setPrereqStatus).toHaveBeenCalledWith(PrereqStatus.OK);
      expect(mockUiStateManagementService.setPrereqStatus).toHaveBeenCalledWith(PrereqStatus.NotOk);
      expect(mockUiStateManagementService.complete).toHaveBeenCalledTimes(1);
      expect(mockUiStateManagementService.error).toHaveBeenCalledTimes(1);
    }));

    it('should handle valid and invalid messages mixed together', fakeAsync(() => {
      const validMessage = {
        Action: 'ShowInstallationPrerequisite',
        Status: PrereqStatus.OK,
      };

      const invalidMessage = {
        Action: 'WrongAction',
        Status: 'OK',
      };

      messageSubject.next(invalidMessage);
      messageSubject.next(validMessage);
      messageSubject.next(invalidMessage);
      tick();

      expect(mockUiStateManagementService.setPrereqStatus).toHaveBeenCalledTimes(1);
    }));
  });

  describe('State Update Call Order', () => {
    beforeEach(() => {
      converter.start();
    });

    it('should call setPrereqStatus before complete/error', fakeAsync(() => {
      const message = {
        Action: 'ShowInstallationPrerequisite',
        Status: PrereqStatus.OK,
      };

      let callOrder: string[] = [];

      mockUiStateManagementService.setPrereqStatus.and.callFake(() => {
        callOrder.push('setPrereqStatus');
      });

      mockUiStateManagementService.complete.and.callFake(() => {
        callOrder.push('complete');
      });

      messageSubject.next(message);
      tick();

      expect(callOrder).toEqual(['setPrereqStatus', 'complete']);
    }));

    it('should call complete/error before setActive', fakeAsync(() => {
      const message = {
        Action: 'ShowInstallationPrerequisite',
        Status: PrereqStatus.OK,
      };

      let callOrder: string[] = [];

      mockUiStateManagementService.complete.and.callFake(() => {
        callOrder.push('complete');
      });

      mockUiStateManagementService.setActive.and.callFake(() => {
        callOrder.push('setActive');
      });

      messageSubject.next(message);
      tick();

      expect(callOrder).toEqual(['complete', 'setActive']);
    }));
  });

  describe('Edge Cases', () => {
    beforeEach(() => {
      converter.start();
    });

    it('should handle empty message', fakeAsync(() => {
      messageSubject.next({});
      tick();

      expect(mockUiStateManagementService.setPrereqStatus).not.toHaveBeenCalled();
    }));

    it('should handle null message', fakeAsync(() => {
      messageSubject.next(null as unknown as RawMessage);
      tick();

      expect(mockUiStateManagementService.setPrereqStatus).not.toHaveBeenCalled();
    }));

    it('should handle undefined message', fakeAsync(() => {
      messageSubject.next(undefined as unknown as RawMessage);
      tick();

      expect(mockUiStateManagementService.setPrereqStatus).not.toHaveBeenCalled();
    }));

    it('should handle message with extra fields', fakeAsync(() => {
      const message = {
        Action: 'ShowInstallationPrerequisite',
        Status: PrereqStatus.OK,
        ExtraField1: 'value1',
        ExtraField2: 123,
      };

      messageSubject.next(message);
      tick();

      expect(mockUiStateManagementService.setPrereqStatus).toHaveBeenCalledWith(PrereqStatus.OK);
    }));

    it('should handle case-sensitive Action matching', fakeAsync(() => {
      const message = {
        Action: 'showinstallationprerequisite', // lowercase - should not match
        Status: 'OK',
      };

      messageSubject.next(message);
      tick();

      expect(mockUiStateManagementService.setPrereqStatus).not.toHaveBeenCalled();
    }));
  });

  describe('Integration Scenarios', () => {
    it('should process complete workflow: start -> message -> state update -> navigation', fakeAsync(() => {
      converter.start();

      const message = {
        Action: 'ShowInstallationPrerequisite',
        Status: PrereqStatus.OK,
      };

      messageSubject.next(message);
      tick();

      expect(mockUiStateManagementService.setPrereqStatus).toHaveBeenCalledWith(PrereqStatus.OK);
      expect(mockUiStateManagementService.complete).toHaveBeenCalledWith(StepId.VerifyPrereq);
      expect(mockUiStateManagementService.setActive).toHaveBeenCalledWith(StepId.VerificationResult);
    }));

    it('should handle error workflow: start -> Not Ok message -> error state', fakeAsync(() => {
      converter.start();

      const message = {
        Action: 'ShowInstallationPrerequisite',
        Status: PrereqStatus.NotOk,
      };

      messageSubject.next(message);
      tick();

      expect(mockUiStateManagementService.setPrereqStatus).toHaveBeenCalledWith(PrereqStatus.NotOk);
      expect(mockUiStateManagementService.error).toHaveBeenCalledWith(StepId.VerifyPrereq);
      expect(mockUiStateManagementService.complete).not.toHaveBeenCalled();
      expect(mockUiStateManagementService.setActive).toHaveBeenCalledWith(StepId.VerificationResult);
    }));
  });

  describe('Error Handling (try/catch)', () => {
    beforeEach(() => {
      converter.start();
    });

    it('should catch and log an error thrown inside a handler', fakeAsync(() => {
      mockUiStateManagementService.setPrereqStatus.and.throwError('handler boom');

      const message = { Action: 'ShowInstallationPrerequisite', Status: PrereqStatus.OK };
      messageSubject.next(message);
      tick();

      expect(mockLogService.error).toHaveBeenCalledWith(
        'Converter',
        'route',
        jasmine.stringContaining('ShowInstallationPrerequisite')
      );
    }));

    it('should not rethrow errors from handlers', fakeAsync(() => {
      mockUiStateManagementService.setPrereqStatus.and.throwError('handler boom');

      const message = { Action: 'ShowInstallationPrerequisite', Status: PrereqStatus.OK };

      expect(() => {
        messageSubject.next(message);
        tick();
      }).not.toThrow();
    }));

    it('should continue processing subsequent messages after a handler error', fakeAsync(() => {
      let callCount = 0;
      mockUiStateManagementService.setPrereqStatus.and.callFake((status: PrereqStatus) => {
        callCount++;
        if (callCount === 1) throw new Error('first call fails');
      });

      messageSubject.next({ Action: 'ShowInstallationPrerequisite', Status: PrereqStatus.OK });
      tick();
      messageSubject.next({ Action: 'ShowInstallationPrerequisite', Status: PrereqStatus.OK });
      tick();

      expect(mockUiStateManagementService.setPrereqStatus).toHaveBeenCalledTimes(2);
      expect(mockLogService.error).toHaveBeenCalledTimes(1);
    }));
  });

  describe('Stream Error Handling', () => {
    it('should log an error when the message stream errors', () => {
      converter.start();

      messageSubject.error(new Error('WebView2 environment not detected.'));

      expect(mockLogService.error).toHaveBeenCalledWith(
        'Converter',
        'connect',
        'Message stream error: Error: WebView2 environment not detected.'
      );
    });

    it('should not throw when the message stream errors', () => {
      converter.start();

      expect(() => {
        messageSubject.error(new Error('WebView2 environment not detected.'));
      }).not.toThrow();
    });

    it('should log at error level, not warn or info', () => {
      converter.start();

      messageSubject.error(new Error('connection lost'));

      expect(mockLogService.error).toHaveBeenCalled();
      expect(mockLogService.warn).not.toHaveBeenCalled();
      expect(mockLogService.info).not.toHaveBeenCalled();
    });

    it('should include the error detail in the log message', () => {
      converter.start();

      messageSubject.error(new Error('some specific failure'));

      expect(mockLogService.error).toHaveBeenCalledWith(
        'Converter',
        'connect',
        jasmine.stringContaining('some specific failure')
      );
    });
  });

});

