
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import {
  StepId,
  StepStatus,
  PrereqStatus,
  GuidanceOverviewState,
  GUIDANCE_OVERVIEW_LABELS,
  getNextStepId,
  getActiveStepId,
  isValidStepId,
} from './update.models';
import { LogService } from '../log/log.service';

/** Creates the initial per-step status map: first step Active, all others Pending. */
function createInitialStepStatuses(): Record<StepId, StepStatus> {
  const statuses = {} as Record<StepId, StepStatus>;
  GUIDANCE_OVERVIEW_LABELS.forEach((config, index) => {
    statuses[config.id] = index === 0 ? StepStatus.Active : StepStatus.Pending;
  });
  return statuses;
}

/** Returns the application's initial state with the Introduction step active. */
function createInitialState(): GuidanceOverviewState {
  return {
    stepStatuses: createInitialStepStatuses(),
  };
}

@Injectable({ providedIn: 'root' })
export class UiStateManagementService {
  private readonly uiStateSubject = new BehaviorSubject<GuidanceOverviewState>(createInitialState());
  private readonly prereqSubject = new BehaviorSubject<PrereqStatus>(PrereqStatus.Unknown);

  /** Navigation state observable — active step and per-step lifecycle statuses. */
  readonly state$: Observable<GuidanceOverviewState> = this.uiStateSubject.asObservable();

  /** Prerequisite-verification outcome, independent of navigation state. */
  readonly prereqStatus$: Observable<PrereqStatus> = this.prereqSubject.asObservable();

  constructor(private readonly log: LogService) {
    this.log.info('UiStateManagementService', 'init', 'State service initialized');
  }

  // ========== PUBLIC API ==========

  /**
   * Activates the given step. Promotes it from Pending → Active if needed;
   * steps already Completed or in Error are left unchanged.
   */
  setActive(stepId: StepId): void {
    if (!isValidStepId(stepId)) {
      this.log.warn('UiStateManagementService', 'setActive', `Ignored setActive. Unknown stepId: ${StepId[stepId]}`);
      return;
    }

    const current = this.currentState();
    const currentActiveStepId = getActiveStepId(current);
    this.log.info(
      'UiStateManagementService',
      'setActive',
      `Active step changed: ${StepId[currentActiveStepId]} -> ${StepId[stepId]}`
    );

    const newStatuses = { ...current.stepStatuses };

    // Deactivate the previously active step back to Pending (only if it's still Active)
    if (newStatuses[currentActiveStepId] === StepStatus.Active) {
      newStatuses[currentActiveStepId] = StepStatus.Pending;
    }

    // Promote the target step from Pending → Active (keeps Completed/Error unchanged)
    if (newStatuses[stepId] === StepStatus.Pending) {
      newStatuses[stepId] = StepStatus.Active;
    }

    this.setState({ ...current, stepStatuses: newStatuses });
  }

  /** Marks the given step as Completed. */
  complete(stepId: StepId): void {
    this.log.info('UiStateManagementService', 'complete', `Step completed: ${StepId[stepId]}`);
    this.setStepStatus(stepId, StepStatus.Success);
  }

  /** Marks the given step as Error. */
  error(stepId: StepId): void {
    this.log.warn('UiStateManagementService', 'error', `Step error state set: ${StepId[stepId]}`);
    this.setStepStatus(stepId, StepStatus.Error);
  }

  /** Updates the prerequisite-verification outcome. */
  setPrereqStatus(status: PrereqStatus): void {
    this.log.info('UiStateManagementService', 'setPrereqStatus', `Prereq status: ${status}`);
    this.prereqSubject.next(status);
  }

  /**
   * Atomically marks the current step as Completed and activates the next one
   * in a single state emission. No-op if already on the last step.
   */
  next(): void {
    const current = this.currentState();
    const currentActiveStepId = getActiveStepId(current);
    const nextStepId = getNextStepId(currentActiveStepId);

    if (nextStepId === null) {
      this.log.warn('UiStateManagementService', 'next', `No next step from: ${StepId[currentActiveStepId]}`);
      return;
    }

    this.log.info(
      'UiStateManagementService',
      'next',
      `Next requested. Completing ${StepId[currentActiveStepId]} and activating ${StepId[nextStepId]}`
    );

    // Complete current and activate next in a single atomic state emission.
    const newStatuses = { ...current.stepStatuses };
    newStatuses[currentActiveStepId] = StepStatus.Success;
    newStatuses[nextStepId] = StepStatus.Active;

    this.setState({ ...current, stepStatuses: newStatuses });

    // Flush logs for immediate backend visibility
    this.log.flush();
  }

  /** Returns the current state snapshot synchronously. Use sparingly — prefer subscribing to `state$`. */
  getCurrentState(): GuidanceOverviewState {
    return this.currentState();
  }

  /** Returns the current status of the given step synchronously. */
  getStepStatus(stepId: StepId): StepStatus {
    return this.currentState().stepStatuses[stepId];
  }

  // ========== PRIVATE HELPERS ==========

  private setStepStatus(stepId: StepId, status: StepStatus): void {
    const current = this.currentState();
    const newStatuses = { ...current.stepStatuses, [stepId]: status };
    this.setState({ ...current, stepStatuses: newStatuses });
  }

  private currentState(): GuidanceOverviewState {
    return this.uiStateSubject.getValue();
  }

  private setState(next: GuidanceOverviewState): void {
    this.uiStateSubject.next(next);
  }
}
