import { TestBed, fakeAsync, tick } from '@angular/core/testing';
import { Subject } from 'rxjs';
import { Converter } from './converter';
import { UiStateManagementService } from './ui-state-management-service';
import { MESSAGE_RECEIVER } from '../communication/i-message-receiver.token';
import { IMessageReceiver } from '../communication/i-message-receiver';
import { LogService } from '../log/log.service';
import { I18nService } from '../i18n';
import { PrereqStatus, StepId, StepStatus, GUIDANCE_OVERVIEW_LABELS, getActiveStepId } from './update.models';

/**
 * Integration tests for message parsing and handling flow.
 * Tests the complete journey: Message -> Converter -> Handler -> State Update
 */
describe('Message Parsing Integration', () => {
  let converter: Converter;
  let stateService: UiStateManagementService;
  let mockMessageReceiver: IMessageReceiver;
  let mockLogService: jasmine.SpyObj<LogService>;
  let mockI18nService: jasmine.SpyObj<I18nService>;
  let messageSubject: Subject<any>;

  /** Reads the latest prereqStatus synchronously from the BehaviorSubject. */
  function getCurrentPrereqStatus(): PrereqStatus {
    let status!: PrereqStatus;
    stateService.prereqStatus$.subscribe(s => (status = s)).unsubscribe();
    return status;
  }

  beforeEach(() => {
    messageSubject = new Subject<any>();

    mockMessageReceiver = {
      messages$: messageSubject.asObservable()
    };

    mockLogService = jasmine.createSpyObj('LogService', [
      'debug',
      'info',
      'warn',
      'error',
      'flush',
    ]);

    mockI18nService = jasmine.createSpyObj('I18nService', ['setLanguage', 'translate']);

    TestBed.configureTestingModule({
      providers: [
        Converter,
        UiStateManagementService,
        { provide: MESSAGE_RECEIVER, useValue: mockMessageReceiver },
        { provide: LogService, useValue: mockLogService },
        { provide: I18nService, useValue: mockI18nService },
      ],
    });

    converter = TestBed.inject(Converter);
    stateService = TestBed.inject(UiStateManagementService);
  });

  afterEach(() => {
    messageSubject.complete();
  });

  describe('End-to-End Message Flow', () => {
    it('should process OK message through complete pipeline', fakeAsync(() => {
      converter.start();

      const message = {
        Action: 'ShowInstallationPrerequisite',
        Status: PrereqStatus.OK,
      };

      messageSubject.next(message);
      tick();

      const state = stateService.getCurrentState();
      expect(getCurrentPrereqStatus()).toBe(PrereqStatus.OK);
      expect(state.stepStatuses[StepId.VerifyPrereq]).toBe(StepStatus.Success);
    }));

    it('should process Not Ok message through complete pipeline', fakeAsync(() => {
      converter.start();

      const message = {
        Action: 'ShowInstallationPrerequisite',
        Status: PrereqStatus.NotOk,
      };

      messageSubject.next(message);
      tick();

      const state = stateService.getCurrentState();
      expect(getCurrentPrereqStatus()).toBe(PrereqStatus.NotOk);
      expect(state.stepStatuses[StepId.VerifyPrereq]).toBe(StepStatus.Error);
    }));

    it('should navigate to verification result after processing', fakeAsync(() => {
      converter.start();

      const message = {
        Action: 'ShowInstallationPrerequisite',
        Status: PrereqStatus.OK,
      };

      messageSubject.next(message);
      tick();

      const state = stateService.getCurrentState();
      expect(getActiveStepId(state)).toBe(StepId.VerificationResult);
    }));
  });

  describe('Message Validation Integration', () => {
    it('should reject invalid messages without affecting state', fakeAsync(() => {
      converter.start();

      const initialState = stateService.getCurrentState();

      const invalidMessage = {
        Action: 'ShowInstallationPrerequisite',
        Status: 'InvalidStatus',
      };

      messageSubject.next(invalidMessage);
      tick();

      const finalState = stateService.getCurrentState();
      expect(getCurrentPrereqStatus()).toBe(PrereqStatus.Unknown);
      expect(mockLogService.error).toHaveBeenCalled();
    }));

    it('should process valid message after invalid one', fakeAsync(() => {
      converter.start();

      const invalidMessage = {
        Action: 'ShowInstallationPrerequisite',
        Status: 'InvalidStatus',
      };

      const validMessage = {
        Action: 'ShowInstallationPrerequisite',
        Status: PrereqStatus.OK,
      };

      messageSubject.next(invalidMessage);
      tick();
      
      messageSubject.next(validMessage);
      tick();

      expect(getCurrentPrereqStatus()).toBe(PrereqStatus.OK);
    }));

    it('should ignore messages with missing Action field', fakeAsync(() => {
      converter.start();

      const initialState = stateService.getCurrentState();

      const messageWithoutAction = {
        Status: 'OK',
      };

      messageSubject.next(messageWithoutAction);
      tick();

      const finalState = stateService.getCurrentState();
      expect(finalState).toEqual(initialState);
    }));

    it('should ignore messages with null Action', fakeAsync(() => {
      converter.start();

      const messageWithNullAction = {
        Action: null,
        Status: 'OK',
      };

      messageSubject.next(messageWithNullAction);
      tick();

      // State should remain at initial Unknown prereqStatus
      expect(getCurrentPrereqStatus()).toBe(PrereqStatus.Unknown);
    }));
  });

  describe('Multiple Message Sequences', () => {
    it('should handle OK -> Not Ok -> OK sequence', fakeAsync(() => {
      converter.start();

      const messages = [
        { Action: 'ShowInstallationPrerequisite', Status: PrereqStatus.OK },
        { Action: 'ShowInstallationPrerequisite', Status: PrereqStatus.NotOk },
        { Action: 'ShowInstallationPrerequisite', Status: PrereqStatus.OK },
      ];

      messages.forEach((msg) => {
        messageSubject.next(msg);
        tick();
      });

      expect(getCurrentPrereqStatus()).toBe(PrereqStatus.OK);
    }));

    it('should maintain correct step status through message sequence', fakeAsync(() => {
      converter.start();

      // First message: OK
      messageSubject.next({
        Action: 'ShowInstallationPrerequisite',
        Status: PrereqStatus.OK,
      });
      tick();

      let state = stateService.getCurrentState();
      expect(state.stepStatuses[StepId.VerifyPrereq]).toBe(StepStatus.Success);

      // Second message: Not Ok
      messageSubject.next({
        Action: 'ShowInstallationPrerequisite',
        Status: PrereqStatus.NotOk,
      });
      tick();

      state = stateService.getCurrentState();
      expect(state.stepStatuses[StepId.VerifyPrereq]).toBe(StepStatus.Error);
    }));

    it('should handle rapid message burst', fakeAsync(() => {
      converter.start();

      for (let i = 0; i < 10; i++) {
        messageSubject.next({
          Action: 'ShowInstallationPrerequisite',
          Status: (i % 2 === 0 ? PrereqStatus.OK : PrereqStatus.NotOk),
        });
      }

      tick();

      // Last message was Not Ok (index 9)
      expect(getCurrentPrereqStatus()).toBe(PrereqStatus.NotOk);
    }));
  });

  describe('State Observable Integration', () => {
    it('should emit prereqStatus changes to subscribers', fakeAsync(() => {
      converter.start();

      const statusChanges: PrereqStatus[] = [];

      stateService.prereqStatus$.subscribe((status) => {
        if (status !== PrereqStatus.Unknown) {
          statusChanges.push(status);
        }
      });

      messageSubject.next({
        Action: 'ShowInstallationPrerequisite',
        Status: PrereqStatus.OK,
      });
      tick();

      messageSubject.next({
        Action: 'ShowInstallationPrerequisite',
        Status: PrereqStatus.NotOk,
      });
      tick();

      expect(statusChanges).toContain(PrereqStatus.OK);
      expect(statusChanges).toContain(PrereqStatus.NotOk);
    }));
  });

  describe('Navigation Integration', () => {
    it('should navigate after OK status', fakeAsync(() => {
      converter.start();

      messageSubject.next({
        Action: 'ShowInstallationPrerequisite',
        Status: PrereqStatus.OK,
      });

      tick();
      expect(getActiveStepId(stateService.getCurrentState())).toBe(StepId.VerificationResult);
    }));

    it('should navigate after Not Ok status', fakeAsync(() => {
      converter.start();

      messageSubject.next({
        Action: 'ShowInstallationPrerequisite',
        Status: PrereqStatus.NotOk,
      });

      tick();
      expect(getActiveStepId(stateService.getCurrentState())).toBe(StepId.VerificationResult);
    }));

    it('should handle overlapping navigation messages', fakeAsync(() => {
      converter.start();

      messageSubject.next({
        Action: 'ShowInstallationPrerequisite',
        Status: PrereqStatus.OK,
      });
      tick();

      messageSubject.next({
        Action: 'ShowInstallationPrerequisite',
        Status: PrereqStatus.NotOk,
      });
      tick();

      const state = stateService.getCurrentState();
      expect(getActiveStepId(state)).toBe(StepId.VerificationResult);
    }));
  });

  describe('Logging Integration', () => {
    it('should log message processing events', fakeAsync(() => {
      converter.start();

      messageSubject.next({
        Action: 'ShowInstallationPrerequisite',
        Status: PrereqStatus.OK,
      });

      tick();

      expect(mockLogService.info).toHaveBeenCalled();
      expect(mockLogService.debug).toHaveBeenCalled();
    }));

    it('should log errors for invalid messages', fakeAsync(() => {
      converter.start();

      messageSubject.next({
        Action: 'ShowInstallationPrerequisite',
        Status: 'InvalidStatus',
      });

      tick();

      expect(mockLogService.error).toHaveBeenCalledWith(
        'Handler',
        'ShowInstallationPrereq',
        jasmine.stringContaining('Invalid message structure')
      );
    }));

    it('should log warnings for unknown actions', fakeAsync(() => {
      converter.start();

      messageSubject.next({
        Action: 'UnknownAction',
        Status: 'OK',
      });

      tick();

      expect(mockLogService.warn).toHaveBeenCalledWith(
        'Converter',
        'route',
        jasmine.stringContaining('No handler registered for action: UnknownAction')
      );
    }));

    it('should log navigation events', fakeAsync(() => {
      converter.start();

      messageSubject.next({
        Action: 'ShowInstallationPrerequisite',
        Status: PrereqStatus.OK,
      });

      tick();

      expect(mockLogService.debug).toHaveBeenCalledWith(
        'Handler',
        'ShowInstallationPrereq',
        jasmine.stringContaining('Navigated to VerificationResult')
      );
    }));
  });

  describe('Error Recovery Integration', () => {
    it('should continue processing after invalid message', fakeAsync(() => {
      converter.start();

      // Invalid message
      messageSubject.next({
        Action: 'ShowInstallationPrerequisite',
        Status: 'BadStatus',
      });
      tick();

      // Valid message
      messageSubject.next({
        Action: 'ShowInstallationPrerequisite',
        Status: PrereqStatus.OK,
      });
      tick();

      expect(getCurrentPrereqStatus()).toBe(PrereqStatus.OK);
    }));

    it('should handle malformed messages gracefully', fakeAsync(() => {
      converter.start();

      // Completely malformed message
      messageSubject.next(null);
      messageSubject.next(undefined);
      messageSubject.next({});
      messageSubject.next({ randomField: 'value' });

      tick();

      // prereqStatus should remain at initial Unknown
      expect(getCurrentPrereqStatus()).toBe(PrereqStatus.Unknown);
    }));

    it('should recover from thrown errors in handler', fakeAsync(() => {
      converter.start();

      // This should not crash the application
      messageSubject.next({
        Action: 'ShowInstallationPrerequisite',
        Status: PrereqStatus.OK,
      });

      tick();

      // Subsequent message should still work
      messageSubject.next({
        Action: 'ShowInstallationPrerequisite',
        Status: PrereqStatus.NotOk,
      });

      tick();

      expect(getCurrentPrereqStatus()).toBe(PrereqStatus.NotOk);
    }));
  });

  describe('Complete Workflow Scenarios', () => {
    it('should handle successful verification workflow', fakeAsync(() => {
      converter.start();

      const workflowSteps: string[] = [];

      stateService.state$.subscribe((state) => {
        if (getActiveStepId(state) === StepId.VerificationResult) {
          workflowSteps.push('navigated');
        }
      });

      stateService.prereqStatus$.subscribe((status) => {
        if (status === PrereqStatus.OK) {
          workflowSteps.push('statusSet');
        }
      });

      messageSubject.next({
        Action: 'ShowInstallationPrerequisite',
        Status: PrereqStatus.OK,
      });

      tick();

      expect(workflowSteps).toContain('statusSet');
      expect(workflowSteps).toContain('navigated');

      const state = stateService.getCurrentState();
      expect(state.stepStatuses[StepId.VerifyPrereq]).toBe(StepStatus.Success);
    }));

    it('should handle failed verification workflow', fakeAsync(() => {
      converter.start();

      messageSubject.next({
        Action: 'ShowInstallationPrerequisite',
        Status: PrereqStatus.NotOk,
      });

      tick();

      expect(getCurrentPrereqStatus()).toBe(PrereqStatus.NotOk);
      const state = stateService.getCurrentState();
      expect(getActiveStepId(state)).toBe(StepId.VerificationResult);
      expect(state.stepStatuses[StepId.VerifyPrereq]).toBe(StepStatus.Error);
    }));

    it('should handle retry scenario: Not Ok -> OK', fakeAsync(() => {
      converter.start();

      // First attempt fails
      messageSubject.next({
        Action: 'ShowInstallationPrerequisite',
        Status: PrereqStatus.NotOk,
      });
      tick();

      expect(getCurrentPrereqStatus()).toBe(PrereqStatus.NotOk);

      // Second attempt succeeds
      messageSubject.next({
        Action: 'ShowInstallationPrerequisite',
        Status: PrereqStatus.OK,
      });
      tick();

      expect(getCurrentPrereqStatus()).toBe(PrereqStatus.OK);
      expect(stateService.getCurrentState().stepStatuses[StepId.VerifyPrereq]).toBe(StepStatus.Success);
    }));
  });

  describe('Converter Service Lifecycle', () => {
    it('should not process messages before start() is called', fakeAsync(() => {
      // Don't call converter.start()

      messageSubject.next({
        Action: 'ShowInstallationPrerequisite',
        Status: PrereqStatus.OK,
      });

      tick();

      // Initial prereqStatus is Unknown
      expect(getCurrentPrereqStatus()).toBe(PrereqStatus.Unknown);
    }));

    it('should process messages after start() is called', fakeAsync(() => {
      converter.start();

      messageSubject.next({
        Action: 'ShowInstallationPrerequisite',
        Status: PrereqStatus.OK,
      });

      tick();

      expect(getCurrentPrereqStatus()).toBe(PrereqStatus.OK);
    }));

    it('should handle multiple start() calls gracefully', fakeAsync(() => {
      converter.start();
      converter.start();
      converter.start();

      messageSubject.next({
        Action: 'ShowInstallationPrerequisite',
        Status: PrereqStatus.OK,
      });

      tick();

      expect(getCurrentPrereqStatus()).toBe(PrereqStatus.OK);
    }));
  });

  describe('State Consistency', () => {
    it('should maintain consistent state across multiple operations', fakeAsync(() => {
      converter.start();

      messageSubject.next({
        Action: 'ShowInstallationPrerequisite',
        Status: PrereqStatus.OK,
      });
      tick();

      expect(getCurrentPrereqStatus()).toBe(PrereqStatus.OK);
      expect(stateService.getCurrentState().stepStatuses[StepId.VerifyPrereq]).toBe(StepStatus.Success);

      tick();

      expect(getCurrentPrereqStatus()).toBe(PrereqStatus.OK);
      expect(getActiveStepId(stateService.getCurrentState())).toBe(StepId.VerificationResult);
      expect(stateService.getCurrentState().stepStatuses[StepId.VerifyPrereq]).toBe(StepStatus.Success);
    }));

    it('should preserve step configs throughout message processing', fakeAsync(() => {
      converter.start();

      const initialConfigCount = GUIDANCE_OVERVIEW_LABELS.length;

      messageSubject.next({
        Action: 'ShowInstallationPrerequisite',
        Status: PrereqStatus.OK,
      });

      tick();

      // GUIDANCE_OVERVIEW_LABELS is a constant array - should remain unchanged
      expect(GUIDANCE_OVERVIEW_LABELS.length).toBe(initialConfigCount);
    }));

    it('should preserve step statuses count throughout message processing', fakeAsync(() => {
      converter.start();

      const initialStatusesCount = Object.keys(stateService.getCurrentState().stepStatuses).length;

      messageSubject.next({
        Action: 'ShowInstallationPrerequisite',
        Status: PrereqStatus.OK,
      });

      tick();

      expect(Object.keys(stateService.getCurrentState().stepStatuses).length).toBe(initialStatusesCount);
    }));
  });
});
