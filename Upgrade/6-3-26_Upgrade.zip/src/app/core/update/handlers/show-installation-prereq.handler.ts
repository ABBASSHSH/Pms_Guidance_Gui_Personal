import { BackendMessage, ShowInstallationPrereqMsg } from '../message.interfaces';
import { HandlerContext } from '../message-handlers';
import { StepId, PrereqStatus } from '../update.models';

export class ShowInstallationPrereqHandler {
  static isValid(message: BackendMessage): message is ShowInstallationPrereqMsg {
    return (
      message.Action === 'ShowInstallationPrerequisite' &&
      'Status' in message &&
      (message.Status === PrereqStatus.OK || message.Status === PrereqStatus.NotOk)
    );
  }

  static handle(message: BackendMessage, context: HandlerContext): void {
    const { state, log } = context;

    if (!ShowInstallationPrereqHandler.isValid(message)) {
      log.error('Handler', 'ShowInstallationPrereq', `Invalid message structure: ${JSON.stringify(message)}`);
      return;
    }

    log.info('Handler', 'ShowInstallationPrereq', `Processing status: ${message.Status}`);
    state.setPrereqStatus(message.Status);

    if (message.Status === PrereqStatus.OK) {
      state.complete(StepId.VerifyPrereq);
    } else {
      state.error(StepId.VerifyPrereq);
    }

    state.setActive(StepId.VerificationResult);
    log.debug('Handler', 'ShowInstallationPrereq', 'Navigated to VerificationResult');
  }
}