/** Identifies each wizard step in display order. */
export enum StepId {
  Introduction = 0,
  VerifyPrereq = 1,
  VerificationResult = 2,
  SaveImages = 3,
  DriveToPark = 4,
  Installation = 5,
}

/**
 * Lifecycle status of a single wizard step.
 * Terminal statuses (`Success`, `Error`, `Warning`) match the SHUI `sh-stepper-item` `[type]`
 * attribute values directly, so they can be bound without transformation.
 */
export enum StepStatus {
  Pending = 'pending',
  Active = 'active',
  Success = 'success',
  Error = 'error',
  Warning = 'warning',
}

/** Result of the prerequisite-verification check. */
export enum PrereqStatus {
  OK = 'OK',
  NotOk = 'Not Ok',
  Unknown = 'unknown',
}

/**
 * Navigation state — tracks per-step lifecycle statuses.
 * The active step is the entry with `StepStatus.Active`; use `getActiveStepId()` to retrieve it.
 * Prerequisite-verification outcome is managed separately via `prereqStatus$`.
 */
export interface GuidanceOverviewState {
  /** Per-step lifecycle status, keyed by StepId. */
  readonly stepStatuses: Readonly<Record<StepId, StepStatus>>;
}

/**
 * Returns the StepId whose status is `Active`, or `StepId.Introduction` as a safe fallback
 * when no step is active (should not happen in normal operation).
 */
export function getActiveStepId(state: GuidanceOverviewState): StepId {
  const entry = GUIDANCE_OVERVIEW_LABELS.find(s => state.stepStatuses[s.id] === StepStatus.Active);
  return entry?.id ?? StepId.Introduction;
}

/**
 * Returns the next StepId in sequence, or `null` when already at the last step.
 */
export function getNextStepId(currentStepId: StepId): StepId | null {
  const currentIndex = GUIDANCE_OVERVIEW_LABELS.findIndex(s => s.id === currentStepId);
  if (currentIndex < 0 || currentIndex >= GUIDANCE_OVERVIEW_LABELS.length - 1) {
    return null;
  }
  return GUIDANCE_OVERVIEW_LABELS[currentIndex + 1].id;
}

/** Returns `true` when the given value corresponds to a known StepId. */
export function isValidStepId(stepId: StepId): boolean {
  return GUIDANCE_OVERVIEW_LABELS.some(s => s.id === stepId);
}

/** Maps a StepId to the i18n key used in the stepper label. */
export interface GuidanceOverviewLabel {
  readonly id: StepId;
  readonly labelKey: string;
}

/** Ordered step configuration — single place to change step order or labels. */
export const GUIDANCE_OVERVIEW_LABELS: readonly GuidanceOverviewLabel[] = [
  { id: StepId.Introduction,       labelKey: 'steps.introduction'       },
  { id: StepId.VerifyPrereq,       labelKey: 'steps.verifyPrereq'       },
  { id: StepId.VerificationResult, labelKey: 'steps.verificationResult' },
  { id: StepId.SaveImages,         labelKey: 'steps.saveImages'         },
  { id: StepId.DriveToPark,        labelKey: 'steps.driveToPark'        },
  { id: StepId.Installation,       labelKey: 'steps.installation'       },
] as const;
