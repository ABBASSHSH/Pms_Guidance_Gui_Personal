import { TestBed } from '@angular/core/testing';
import { UiStateManagementService } from './ui-state-management-service';
import { LogService } from '../log/log.service';
import { StepId, StepStatus, PrereqStatus, GuidanceOverviewState, GUIDANCE_OVERVIEW_LABELS, getActiveStepId } from './update.models';

describe('UiStateManagementService', () => {
  let service: UiStateManagementService;
  let mockLogService: jasmine.SpyObj<LogService>;

  beforeEach(() => {
    mockLogService = jasmine.createSpyObj('LogService', [
      'debug',
      'info',
      'warn',
      'error',
      'flush',
    ]);

    TestBed.configureTestingModule({
      providers: [
        UiStateManagementService,
        { provide: LogService, useValue: mockLogService },
      ],
    });

    service = TestBed.inject(UiStateManagementService);
  });

  describe('Initialization', () => {
    it('should create the service', () => {
      expect(service).toBeTruthy();
    });

    it('should initialize with Introduction as active step', (done) => {
      service.state$.subscribe((state) => {
        expect(getActiveStepId(state)).toBe(StepId.Introduction);
        done();
      });
    });

    it('should initialize with all step statuses defined', (done) => {
      service.state$.subscribe((state) => {
        expect(Object.keys(state.stepStatuses).length).toBe(GUIDANCE_OVERVIEW_LABELS.length);
        done();
      });
    });

    it('should initialize with first step active and rest pending', (done) => {
      service.state$.subscribe((state) => {
        expect(state.stepStatuses[StepId.Introduction]).toBe(StepStatus.Active);
        GUIDANCE_OVERVIEW_LABELS.filter(c => c.id !== StepId.Introduction).forEach(config => {
          expect(state.stepStatuses[config.id]).toBe(StepStatus.Pending);
        });
        done();
      });
    });

    it('should initialize prereq status as Unknown', (done) => {
      service.prereqStatus$.subscribe((status) => {
        expect(status).toBe(PrereqStatus.Unknown);
        done();
      });
    });

    it('should log initialization', () => {
      expect(mockLogService.info).toHaveBeenCalledWith(
        'UiStateManagementService',
        'init',
        'State service initialized'
      );
    });
  });

  describe('Active Step Management', () => {
    it('should change active step', (done) => {
      service.setActive(StepId.SaveImages);

      service.state$.subscribe((state) => {
        if (getActiveStepId(state) === StepId.SaveImages) {
          expect(getActiveStepId(state)).toBe(StepId.SaveImages);
          done();
        }
      });
    });

    it('should update step status when setting active', (done) => {
      service.setActive(StepId.SaveImages);

      service.state$.subscribe((state) => {
        if (state.stepStatuses[StepId.SaveImages] === StepStatus.Active) {
          expect(state.stepStatuses[StepId.SaveImages]).toBe(StepStatus.Active);
          done();
        }
      });
    });

    it('should ignore invalid step id', () => {
      const stateBefore = service.getCurrentState();
      service.setActive(999 as StepId);
      const stateAfter = service.getCurrentState();

      expect(getActiveStepId(stateAfter)).toBe(getActiveStepId(stateBefore));
    });

    it('should log warning for invalid step id', () => {
      service.setActive(999 as StepId);

      expect(mockLogService.warn).toHaveBeenCalledWith(
        'UiStateManagementService',
        'setActive',
        jasmine.stringContaining('Unknown stepId')
      );
    });

    it('should preserve completed status when changing active step', (done) => {
      service.complete(StepId.Introduction);
      service.setActive(StepId.SaveImages);

      service.state$.subscribe((state) => {
        if (state.stepStatuses[StepId.SaveImages] === StepStatus.Active && 
            state.stepStatuses[StepId.Introduction] === StepStatus.Success) {
          expect(state.stepStatuses[StepId.Introduction]).toBe(StepStatus.Success);
          done();
        }
      });
    });

    it('should log active step change', () => {
      service.setActive(StepId.VerifyPrereq);

      expect(mockLogService.info).toHaveBeenCalledWith(
        'UiStateManagementService',
        'setActive',
        jasmine.stringContaining('Active step changed')
      );
    });
  });

  describe('Step Completion', () => {
    it('should mark step as completed', (done) => {
      service.complete(StepId.Introduction);

      service.state$.subscribe((state) => {
        if (state.stepStatuses[StepId.Introduction] === StepStatus.Success) {
          expect(state.stepStatuses[StepId.Introduction]).toBe(StepStatus.Success);
          done();
        }
      });
    });

    it('should log step completion', () => {
      service.complete(StepId.Introduction);

      expect(mockLogService.info).toHaveBeenCalledWith(
        'UiStateManagementService',
        'complete',
        jasmine.stringContaining('Step completed')
      );
    });

    it('should get step status', () => {
      service.complete(StepId.Introduction);
      
      expect(service.getStepStatus(StepId.Introduction)).toBe(StepStatus.Success);
    });
  });

  describe('Error Handling', () => {
    it('should mark step as error', (done) => {
      service.error(StepId.VerifyPrereq);

      service.state$.subscribe((state) => {
        if (state.stepStatuses[StepId.VerifyPrereq] === StepStatus.Error) {
          expect(state.stepStatuses[StepId.VerifyPrereq]).toBe(StepStatus.Error);
          done();
        }
      });
    });

    it('should log error state', () => {
      service.error(StepId.SaveImages);

      expect(mockLogService.warn).toHaveBeenCalledWith(
        'UiStateManagementService',
        'error',
        jasmine.stringContaining('Step error state set')
      );
    });
  });

  describe('Next Step Navigation', () => {
    it('should navigate to next step', (done) => {
      service.next();

      service.state$.subscribe((state) => {
        if (getActiveStepId(state) === StepId.VerifyPrereq) {
          expect(getActiveStepId(state)).toBe(StepId.VerifyPrereq);
          done();
        }
      });
    });

    it('should complete current step when moving to next', (done) => {
      service.next();

      service.state$.subscribe((state) => {
        if (state.stepStatuses[StepId.Introduction] === StepStatus.Success) {
          expect(state.stepStatuses[StepId.Introduction]).toBe(StepStatus.Success);
          done();
        }
      });
    });

    it('should do nothing if already on last step', () => {
      service.setActive(StepId.Installation);
      const stateBefore = service.getCurrentState();

      service.next();

      const stateAfter = service.getCurrentState();
      expect(getActiveStepId(stateAfter)).toBe(getActiveStepId(stateBefore));
    });

    it('should log warning when no next step available', () => {
      service.setActive(StepId.Installation);
      mockLogService.warn.calls.reset();

      service.next();

      expect(mockLogService.warn).toHaveBeenCalledWith(
        'UiStateManagementService',
        'next',
        jasmine.stringContaining('No next step')
      );
    });

    it('should flush logs after navigating', () => {
      service.next();

      expect(mockLogService.flush).toHaveBeenCalled();
    });
  });

  describe('State Observable', () => {
    it('should emit state changes to subscribers', () => {
      const states: GuidanceOverviewState[] = [];

      service.state$.subscribe((state) => states.push(state));

      service.setActive(StepId.SaveImages);

      expect(states.length).toBeGreaterThan(1);
    });

    it('should support multiple subscribers', () => {
      const states1: GuidanceOverviewState[] = [];
      const states2: GuidanceOverviewState[] = [];

      service.state$.subscribe((state) => states1.push(state));
      service.state$.subscribe((state) => states2.push(state));

      service.setActive(StepId.SaveImages);

      expect(states1.length).toBeGreaterThan(0);
      expect(states2.length).toBeGreaterThan(0);
      expect(states1.length).toEqual(states2.length);
    });
  });

  describe('State Observable', () => {
    it('should provide state$ observable with step statuses', (done) => {
      service.state$.subscribe((state) => {
        expect(state).toBeDefined();
        expect(state.stepStatuses).toBeDefined();
        expect(Object.keys(state.stepStatuses).length).toBeGreaterThan(0);
        done();
      });
    });

    it('should provide activeStepId via state$', (done) => {
      service.state$.subscribe((state) => {
        expect(getActiveStepId(state)).toBe(StepId.Introduction);
        done();
      });
    });

    it('should provide prereqStatus via prereqStatus$', (done) => {
      service.prereqStatus$.subscribe((status) => {
        expect(status).toBe(PrereqStatus.Unknown);
        done();
      });
    });
  });

  describe('Complex Scenarios', () => {
    it('should handle complete workflow: intro -> verify -> result -> save -> park', (done) => {
      service.state$.subscribe((state) => {
        if (getActiveStepId(state) === StepId.DriveToPark) {
          const intro = state.stepStatuses[StepId.Introduction];
          const verify = state.stepStatuses[StepId.VerifyPrereq];
          const result = state.stepStatuses[StepId.VerificationResult];
          const save = state.stepStatuses[StepId.SaveImages];

          expect(intro).toBe(StepStatus.Success);
          expect(verify).toBe(StepStatus.Success);
          expect(result).toBe(StepStatus.Success);
          expect(save).toBe(StepStatus.Success);
          done();
        }
      });

      service.next(); // intro -> verify
      service.next(); // verify -> result
      service.next(); // result -> save
      service.next(); // save -> park
    });

    it('should preserve error status when navigating', (done) => {
      service.error(StepId.Introduction);
      service.setActive(StepId.SaveImages);

      service.state$.subscribe((state) => {
        if (state.stepStatuses[StepId.SaveImages] === StepStatus.Active) {
          expect(state.stepStatuses[StepId.Introduction]).toBe(StepStatus.Error);
          done();
        }
      });
    });
  });

  describe('Prerequisite Status Management', () => {
    it('should set prerequisite status to OK', (done) => {
      service.setPrereqStatus(PrereqStatus.OK);

      service.prereqStatus$.subscribe((status) => {
        if (status === PrereqStatus.OK) {
          expect(status).toBe(PrereqStatus.OK);
          done();
        }
      });
    });

    it('should set prerequisite status to NotOk', (done) => {
      service.setPrereqStatus(PrereqStatus.NotOk);

      service.prereqStatus$.subscribe((status) => {
        if (status === PrereqStatus.NotOk) {
          expect(status).toBe(PrereqStatus.NotOk);
          done();
        }
      });
    });

    it('should log prereq status change', () => {
      service.setPrereqStatus(PrereqStatus.OK);

      expect(mockLogService.info).toHaveBeenCalledWith(
        'UiStateManagementService',
        'setPrereqStatus',
        jasmine.stringContaining('Prereq status')
      );
    });

    it('should update prerequisite status without affecting navigation state', (done) => {
      service.setActive(StepId.SaveImages);
      service.setPrereqStatus(PrereqStatus.OK);

      service.prereqStatus$.subscribe((status) => {
        if (status === PrereqStatus.OK) {
          expect(service.getCurrentState().stepStatuses[StepId.SaveImages]).toBe(StepStatus.Active);
          expect(getActiveStepId(service.getCurrentState())).toBe(StepId.SaveImages);
          expect(status).toBe(PrereqStatus.OK);
          done();
        }
      });
    });
  });
});
