/**
 * WebView2 API Mock
 * 
 * This mock simulates the window.chrome.webview API for browser testing.
 * It intercepts messages and automatically responds based on configuration.
 */

/**
 * Configuration for mock responses
 */
export const WEBVIEW2_MOCK_CONFIG = {
  /** Enable/disable the mock */
  enabled: true,
  
  /** Response delay in milliseconds */
  responseDelayMs: 10500,
  
  /** Default status for VerifyInstallationPrerequisite response   */
  defaultStatus: 'OK' as 'OK' | 'Not Ok',
  
  /** Randomize responses (for stress testing) */
  randomize: false,
  
  /** Log all communication to console */
  logToConsole: true,
  
  /** System language to send on connection (simulates backend) */
  systemLanguage: 'English',
  
  /** Delay before sending system language message after connection (ms) */
  systemLanguageDelayMs: 100,
};

/**
 * Mock implementation of the WebView2 API
 */
class WebView2Mock {
  private messageHandlers: Array<(event: MessageEvent) => void> = [];
  private autoResponders: Map<string, (message: any) => void> = new Map();

  constructor() {
    this.setupAutoResponders();
    this.log('🎭 WebView2 Mock initialized');
  }

  /**
   * Mock of window.chrome.webview.postMessage
   * Accepts both string (JSON) and object for flexibility
   */
  postMessage(message: string | any): void {
    try {
      // Handle both string and object inputs
      const parsed = typeof message === 'string' ? JSON.parse(message) : message;
      const action = parsed.Action;

      if (WEBVIEW2_MOCK_CONFIG.logToConsole) {
        console.group('📤 MOCK WebView2: Message Sent');
        console.log('Timestamp:', new Date().toLocaleTimeString());
        console.log('Action:', action);
        console.log('Full Message:', parsed);
        console.groupEnd();
      }

      // Check if we have an auto-responder for this action
      const responder = this.autoResponders.get(action);
      if (responder) {
        responder(parsed);
      } else {
        this.log(`⚠️ No auto-responder configured for action: ${action}`);
      }
    } catch (error) {
      console.error('❌ MOCK WebView2: Failed to parse message:', error);
    }
  }

  /**
   * Mock of window.chrome.webview.addEventListener
   * When FE registers for messages, it signals connection establishment.
   * Backend responds with SystemLanguage message.
   */
  addEventListener(event: string, handler: (event: MessageEvent) => void): void {
    if (event === 'message') {
      this.messageHandlers.push(handler);
      this.log(`✅ Event listener added (total: ${this.messageHandlers.length})`);
      
      // First listener registration = connection established
      // Send SystemLanguage message to FE (simulates backend behavior)
      if (this.messageHandlers.length === 1) {
        this.sendSystemLanguageOnConnect();
      }
    }
  }

  /**
   * Sends SystemLanguage message after connection is established.
   * This simulates the backend behavior of sending language info on connect.
   */
  private sendSystemLanguageOnConnect(): void {
    this.log(`🌐 Connection detected. Will send SystemLanguage after ${WEBVIEW2_MOCK_CONFIG.systemLanguageDelayMs}ms`);
    
    this.sendMockResponse(
      {
        Action: 'ShowSystemLanguage',
        Language: WEBVIEW2_MOCK_CONFIG.systemLanguage,
      },
      WEBVIEW2_MOCK_CONFIG.systemLanguageDelayMs
    );
  }

  /**
   * Mock of window.chrome.webview.removeEventListener
   */
  removeEventListener(event: string, handler: (event: MessageEvent) => void): void {
    if (event === 'message') {
      const index = this.messageHandlers.indexOf(handler);
      if (index > -1) {
        this.messageHandlers.splice(index, 1);
        this.log(`🗑️ Event listener removed (remaining: ${this.messageHandlers.length})`);
      }
    }
  }

  /**
   * Send a mock response from "backend" to all registered handlers
   */
  private sendMockResponse(response: any, delayMs: number = WEBVIEW2_MOCK_CONFIG.responseDelayMs): void {
    setTimeout(() => {
      const responseJson = JSON.stringify(response);

      if (WEBVIEW2_MOCK_CONFIG.logToConsole) {
        console.group('📥 MOCK WebView2: Backend Response');
        console.log('Timestamp:', new Date().toLocaleTimeString());
        console.log('Action:', response.Action);
        console.log('Full Response:', response);
        console.groupEnd();
      }

      // Create a mock MessageEvent
      const mockEvent = {
        data: responseJson,
        origin: 'mock-webview2',
        source: null,
        ports: [],
      } as unknown as MessageEvent;

      // Notify all registered handlers
      this.messageHandlers.forEach(handler => {
        try {
          handler(mockEvent);
        } catch (error) {
          console.error('❌ MOCK WebView2: Error in message handler:', error);
        }
      });
    }, delayMs);
  }

  /**
   * Setup auto-responders for known actions
   */
  private setupAutoResponders(): void {
    // VerifyInstallationPrerequisite -> ShowInstallationPrerequisite
    this.autoResponders.set('VerifyInstallationPrerequisite', (message) => {
      const status = WEBVIEW2_MOCK_CONFIG.randomize
        ? (Math.random() > 0.5 ? 'OK' : 'Not Ok')
        : WEBVIEW2_MOCK_CONFIG.defaultStatus;

      this.log(`🎯 Auto-responding to VerifyInstallationPrerequisite with Status="${status}" after ${WEBVIEW2_MOCK_CONFIG.responseDelayMs}ms`);

      this.sendMockResponse({
        Action: 'ShowInstallationPrerequisite',
        Status: status,
      });
    });

    // Add more auto-responders here as needed
    // Example:
    // this.autoResponders.set('SomeOtherAction', (message) => {
    //   this.sendMockResponse({ Action: 'ResponseAction', ...data });
    // });
  }

  /**
   * Helper for console logging
   */
  private log(message: string, ...args: any[]): void {
    if (WEBVIEW2_MOCK_CONFIG.logToConsole) {
      console.log(`🎭 ${message}`, ...args);
    }
  }

  /**
   * Public method to manually send responses (for testing)
   */
  public manualResponse(response: any, delayMs: number = 0): void {
    this.sendMockResponse(response, delayMs);
  }
}

/**
 * Initialize the WebView2 mock if conditions are met
 */
export function initializeWebView2Mock(): void {
  // Only initialize if:
  // 1. Mock is enabled in config
  // 2. We're in a browser (window object exists)
  // 3. WebView2 doesn't already exist
  if (
    WEBVIEW2_MOCK_CONFIG.enabled &&
    typeof window !== 'undefined' &&
    !(window as any).chrome?.webview
  ) {
    console.log('🎭 Initializing WebView2 Mock...');
    console.log('🎭 Config:', WEBVIEW2_MOCK_CONFIG);

    // Create the mock WebView2 API
    const mockWebView = new WebView2Mock();

    // Inject it into the global window object
    if (!(window as any).chrome) {
      (window as any).chrome = {};
    }
    (window as any).chrome.webview = mockWebView;

    // Expose mock for manual testing from console
    (window as any).__webview2Mock = mockWebView;

    console.log('✅ WebView2 Mock installed successfully!');
    console.log('💡 Access it from console: window.__webview2Mock.manualResponse({ Action: "...", ... })');
  } else if ((window as any).chrome?.webview) {
    console.log('ℹ️ Real WebView2 detected - mock not needed');
  } else if (!WEBVIEW2_MOCK_CONFIG.enabled) {
    console.log('ℹ️ WebView2 Mock disabled in config');
  }
}

/**
 * Check if WebView2 mock is active
 */
export function isWebView2MockActive(): boolean {
  return !!(window as any).__webview2Mock;
}
