import { TestBed, ComponentFixture, fakeAsync, tick, flush, discardPeriodicTasks } from '@angular/core/testing';
import { BehaviorSubject } from 'rxjs';
import { NO_ERRORS_SCHEMA } from '@angular/core';

import { AppComponent } from './app.component';
import { UiStateManagementService } from './core/update/ui-state-management-service';
import { LogService } from './core/log/log.service';
import { I18nService } from './core/i18n';
import { CommunicationService } from './core/communication/communication.service';
import { Converter } from './core/update/converter';
import { GuidanceOverviewState, StepId, StepStatus, GUIDANCE_OVERVIEW_LABELS, PrereqStatus, getActiveStepId } from './core/update/update.models';

describe('AppComponent', () => {
  let component: AppComponent;
  let fixture: ComponentFixture<AppComponent>;
  let mockUiStateManagementService: jasmine.SpyObj<UiStateManagementService>;
  let mockLogService: jasmine.SpyObj<LogService>;
  let mockI18nService: jasmine.SpyObj<I18nService>;
  let mockCommunicationService: jasmine.SpyObj<CommunicationService>;
  let mockConverter: jasmine.SpyObj<Converter>;
  let uiStateSubject: BehaviorSubject<GuidanceOverviewState>;
  let prereqSubject: BehaviorSubject<PrereqStatus>;

  const createMockState = (activeStepId: StepId = StepId.Introduction): GuidanceOverviewState => {
    const stepStatuses = {} as Record<StepId, StepStatus>;
    GUIDANCE_OVERVIEW_LABELS.forEach(config => {
      stepStatuses[config.id] = config.id === activeStepId ? StepStatus.Active : StepStatus.Pending;
    });
    return {
      stepStatuses,
    };
  };

  beforeEach(async () => {
    uiStateSubject = new BehaviorSubject<GuidanceOverviewState>(createMockState());
    prereqSubject = new BehaviorSubject<PrereqStatus>(PrereqStatus.Unknown);

    mockUiStateManagementService = jasmine.createSpyObj('UiStateManagementService', [
      'setActive',
      'complete',
      'error',
      'next',
      'reset',
    ]);
    Object.defineProperty(mockUiStateManagementService, 'state$', {
      get: () => uiStateSubject.asObservable(),
    });
    Object.defineProperty(mockUiStateManagementService, 'prereqStatus$', {
      get: () => prereqSubject.asObservable(),
    });

    mockLogService = jasmine.createSpyObj('LogService', [
      'info',
      'debug',
      'warn',
      'error',
      'flush',
    ]);

    mockI18nService = jasmine.createSpyObj('I18nService', ['translate', 'setLanguage']);
    mockI18nService.translate.and.callFake((key: string) => key);

    mockCommunicationService = jasmine.createSpyObj('CommunicationService', ['connect', 'send']);
    mockConverter = jasmine.createSpyObj('Converter', ['start', 'stop']);

    await TestBed.configureTestingModule({
      imports: [AppComponent],
      providers: [
        { provide: UiStateManagementService, useValue: mockUiStateManagementService },
        { provide: LogService, useValue: mockLogService },
        { provide: I18nService, useValue: mockI18nService },
        { provide: CommunicationService, useValue: mockCommunicationService },
        { provide: Converter, useValue: mockConverter },
      ],
      schemas: [NO_ERRORS_SCHEMA], // Ignore child component errors
    }).compileComponents();

    fixture = TestBed.createComponent(AppComponent);
    component = fixture.componentInstance;
  });

  afterEach(() => {
    if (fixture) {
      fixture.destroy();
    }
  });

  describe('Component Initialization', () => {
    it('should create the app component', () => {
      expect(component).toBeTruthy();
    });

    it('should connect communication on init', fakeAsync(() => {
      fixture.detectChanges();
      tick();
      expect(mockCommunicationService.connect).toHaveBeenCalled();
    }));

    it('should start converter on init', fakeAsync(() => {
      fixture.detectChanges();
      tick();
      expect(mockConverter.start).toHaveBeenCalled();
    }));

    it('should have state$ observable from UiStateManagementService', fakeAsync(() => {
      expect(component.state$).toBeDefined();
      
      // Verify it emits the correct state
      let receivedState: GuidanceOverviewState | undefined;
      component.state$.subscribe(state => {
        receivedState = state;
      });
      tick();
      
      expect(receivedState).toBeTruthy();
      expect(getActiveStepId(receivedState!)).toBe(StepId.Introduction);
    }));

    it('should log info message on initialization', fakeAsync(() => {
      fixture.detectChanges();
      tick();

      expect(mockLogService.info).toHaveBeenCalledWith(
        'AppComponent',
        'init',
        'App started'
      );
    }));
  });

  describe('State Subscription', () => {
    it('should subscribe to state$ observable', fakeAsync(() => {
      fixture.detectChanges();
      tick();

      // Emit a state change
      uiStateSubject.next(createMockState(StepId.VerifyPrereq));
      uiStateSubject.next(createMockState(StepId.VerifyPrereq));
      tick();

      // Should have logged the state change
      expect(mockLogService.debug).toHaveBeenCalled();
    }));

    it('should log debug messages for state changes', fakeAsync(() => {
      fixture.detectChanges();
      tick();

      uiStateSubject.next(createMockState(StepId.SaveImages));
      uiStateSubject.next(createMockState(StepId.VerifyPrereq));
      tick();

      const debugCalls = mockLogService.debug.calls.all();
      const stateChangeCalls = debugCalls.filter(
        call => call.args[0] === 'AppComponent' && call.args[1] === 'state'
      );

      expect(stateChangeCalls.length).toBeGreaterThan(0);
    }));

    it('should log active step ID in debug messages', fakeAsync(() => {
      fixture.detectChanges();
      tick();

      uiStateSubject.next(createMockState(StepId.VerificationResult));
      uiStateSubject.next(createMockState(StepId.VerifyPrereq));
      tick();

      const debugCalls = mockLogService.debug.calls.all();
      const stateMessage = debugCalls.find(
        call =>
          call.args[0] === 'AppComponent' &&
          call.args[2]?.includes('VerificationResult')
      );

      expect(stateMessage).toBeDefined();
    }));

    it('should handle multiple state changes', fakeAsync(() => {
      fixture.detectChanges();
      tick();

      const initialDebugCount = mockLogService.debug.calls.count();

      uiStateSubject.next(createMockState(StepId.Introduction));
      uiStateSubject.next(createMockState(StepId.Introduction));
      tick();
      uiStateSubject.next(createMockState(StepId.VerifyPrereq));
      uiStateSubject.next(createMockState(StepId.VerifyPrereq));
      tick();
      uiStateSubject.next(createMockState(StepId.SaveImages));
      uiStateSubject.next(createMockState(StepId.SaveImages));
      tick();

      expect(mockLogService.debug.calls.count()).toBeGreaterThan(
        initialDebugCount
      );
    }));

    it('should continue logging even if state ID changes frequently', fakeAsync(() => {
      fixture.detectChanges();
      tick();

      // Cycle through different states rapidly
      const states = [StepId.Introduction, StepId.VerifyPrereq, StepId.SaveImages, StepId.VerificationResult];
      states.forEach(stepId => {
        uiStateSubject.next(createMockState(stepId));
        uiStateSubject.next(createMockState(stepId));
        tick();
      });

      // Should log each state change
      expect(mockLogService.debug.calls.count()).toBeGreaterThan(states.length);
    }));
  });

  describe('Template Rendering', () => {
    it('should render sh-page with dark theme', () => {
      fixture.detectChanges();
      const compiled = fixture.nativeElement as HTMLElement;
      const page = compiled.querySelector('sh-page');

      expect(page).toBeTruthy();
      expect(page?.getAttribute('theme')).toBe('dark');
    });

    it('should render sh-access-bar with correct attributes', () => {
      fixture.detectChanges();
      const compiled = fixture.nativeElement as HTMLElement;
      const accessBar = compiled.querySelector('sh-access-bar');

      expect(accessBar).toBeTruthy();
      expect(accessBar?.getAttribute('slot')).toBe('access');
      expect(accessBar?.getAttribute('embedded')).toBe('');
      // Label now comes from translation pipe - mock returns the key
      expect(accessBar?.getAttribute('label')).toBe('app.accessBarLabel');
    });

    it('should render app-frame when state is available', fakeAsync(() => {
      uiStateSubject.next(createMockState(StepId.Introduction));
      fixture.detectChanges();
      tick();

      const compiled = fixture.nativeElement as HTMLElement;
      const appFrame = compiled.querySelector('.app-frame');

      expect(appFrame).toBeTruthy();
    }));

    it('should render update-stepper with state items', fakeAsync(() => {
      const mockState = createMockState(StepId.Introduction);
      uiStateSubject.next(mockState);
      fixture.detectChanges();
      tick();

      const compiled = fixture.nativeElement as HTMLElement;
      const stepper = compiled.querySelector('app-guidance-overview');

      expect(stepper).toBeTruthy();
    }));

    it('should pass items to update-stepper', fakeAsync(() => {
      const mockState = createMockState(StepId.VerifyPrereq);
      uiStateSubject.next(mockState);
      fixture.detectChanges();
      tick();
      discardPeriodicTasks(); // Clear any pending periodic timers

      const compiled = fixture.nativeElement as HTMLElement;
      const stepper = compiled.querySelector('app-guidance-overview');

      expect(stepper).toBeTruthy();
      // Items are passed via property binding
    }));

    it('should pass activeStepId to update-stepper', fakeAsync(() => {
      const mockState = createMockState(StepId.SaveImages);
      uiStateSubject.next(mockState);
      fixture.detectChanges();
      tick();

      const compiled = fixture.nativeElement as HTMLElement;
      const stepper = compiled.querySelector('app-guidance-overview');

      expect(stepper).toBeTruthy();
      // ActiveStepId is passed via property binding
    }));

    it('should have left and right sections', fakeAsync(() => {
      uiStateSubject.next(createMockState(StepId.Introduction));
      fixture.detectChanges();
      tick();

      const compiled = fixture.nativeElement as HTMLElement;
      const leftSection = compiled.querySelector('.left');
      const rightSection = compiled.querySelector('.right');

      expect(leftSection).toBeTruthy();
      expect(rightSection).toBeTruthy();
    }));
  });

  describe('Step Component Rendering - @switch', () => {
    it('should render introduction component when activeStepId is Introduction', fakeAsync(() => {
      uiStateSubject.next(createMockState(StepId.Introduction));
      fixture.detectChanges();
      tick();

      const compiled = fixture.nativeElement as HTMLElement;
      const introComponent = compiled.querySelector('app-introduction');

      expect(introComponent).toBeTruthy();
    }));

    it('should render verify-installation-prerequisites when activeStepId is VerifyPrereq', fakeAsync(() => {
      uiStateSubject.next(createMockState(StepId.VerifyPrereq));
      uiStateSubject.next(createMockState(StepId.VerifyPrereq));
      fixture.detectChanges();
      tick();
      discardPeriodicTasks(); // Clear any pending periodic timers

      const compiled = fixture.nativeElement as HTMLElement;
      const verifyComponent = compiled.querySelector(
        'app-verify-installation-prerequisites'
      );

      expect(verifyComponent).toBeTruthy();
    }));

    it('should render verification-result when activeStepId is VerificationResult', fakeAsync(() => {
      uiStateSubject.next(createMockState(StepId.VerificationResult));
      fixture.detectChanges();
      tick();

      const compiled = fixture.nativeElement as HTMLElement;
      const resultComponent = compiled.querySelector(
        'app-verification-result'
      );

      expect(resultComponent).toBeTruthy();
    }));

    it('should render save-patient-images when activeStepId is SaveImages', fakeAsync(() => {
      uiStateSubject.next(createMockState(StepId.SaveImages));
      fixture.detectChanges();
      tick();

      const compiled = fixture.nativeElement as HTMLElement;
      const saveComponent = compiled.querySelector('app-save-patient-images');

      expect(saveComponent).toBeTruthy();
    }));

    it('should render introduction component for default case', fakeAsync(() => {
      // All steps Pending means no Active entry — getActiveStepId falls back to Introduction
      const allPendingState: GuidanceOverviewState = {
        stepStatuses: {
          [StepId.Introduction]: StepStatus.Pending,
          [StepId.VerifyPrereq]: StepStatus.Pending,
          [StepId.VerificationResult]: StepStatus.Pending,
          [StepId.SaveImages]: StepStatus.Pending,
          [StepId.DriveToPark]: StepStatus.Pending,
          [StepId.Installation]: StepStatus.Pending,
        },
      };
      uiStateSubject.next(allPendingState);
      fixture.detectChanges();
      tick();

      const compiled = fixture.nativeElement as HTMLElement;
      const introComponent = compiled.querySelector('app-introduction');

      expect(introComponent).toBeTruthy();
    }));

    it('should switch components when activeStepId changes', fakeAsync(() => {
      // Start with introduction
      uiStateSubject.next(createMockState(StepId.Introduction));
      fixture.detectChanges();
      tick();

      let compiled = fixture.nativeElement as HTMLElement;
      expect(compiled.querySelector('app-introduction')).toBeTruthy();
      expect(
        compiled.querySelector('app-verify-installation-prerequisites')
      ).toBeFalsy();

      // Switch to verifyPrereq
      uiStateSubject.next(createMockState(StepId.VerifyPrereq));
      fixture.detectChanges();
      tick();
      discardPeriodicTasks(); // Clear any pending periodic timers

      compiled = fixture.nativeElement as HTMLElement;
      expect(compiled.querySelector('app-introduction')).toBeFalsy();
      expect(
        compiled.querySelector('app-verify-installation-prerequisites')
      ).toBeTruthy();
    }));

    it('should only render one step component at a time', fakeAsync(() => {
      uiStateSubject.next(createMockState(StepId.SaveImages));
      fixture.detectChanges();
      tick();

      const compiled = fixture.nativeElement as HTMLElement;
      const allStepComponents = [
        compiled.querySelector('app-introduction'),
        compiled.querySelector('app-verify-installation-prerequisites'),
        compiled.querySelector('app-verification-result'),
        compiled.querySelector('app-save-patient-images'),
      ].filter(el => el !== null);

      expect(allStepComponents.length).toBe(1);
    }));
  });

  describe('AsyncPipe Integration', () => {
    it('should use async pipe for state$ observable', fakeAsync(() => {
      uiStateSubject.next(createMockState(StepId.Introduction));
      fixture.detectChanges();
      tick();

      // If async pipe is working, the template should render
      const compiled = fixture.nativeElement as HTMLElement;
      const appFrame = compiled.querySelector('.app-frame');

      expect(appFrame).toBeTruthy();
    }));

    it('should hide app-frame when using *ngIf with falsy value', fakeAsync(() => {
      // This tests the *ngIf behavior, but we can't actually emit null
      // without breaking the subscription, so we just verify the
      // template structure
      uiStateSubject.next(createMockState(StepId.Introduction));
      fixture.detectChanges();
      tick();

      const compiled = fixture.nativeElement as HTMLElement;
      const appFrame = compiled.querySelector('.app-frame');

      // With valid state, frame should be present
      expect(appFrame).toBeTruthy();
    }));

    it('should handle state$ updates reactively', fakeAsync(() => {
      // Initial state
      uiStateSubject.next(createMockState(StepId.Introduction));
      fixture.detectChanges();
      tick();

      let compiled = fixture.nativeElement as HTMLElement;
      expect(compiled.querySelector('app-introduction')).toBeTruthy();

      // Update state
      uiStateSubject.next(createMockState(StepId.VerificationResult));
      fixture.detectChanges();
      tick();

      compiled = fixture.nativeElement as HTMLElement;
      expect(compiled.querySelector('app-verification-result')).toBeTruthy();
    }));
  });

  describe('Component Lifecycle', () => {
    it('should initialize services in constructor', fakeAsync(() => {
      fixture.detectChanges();
      tick();

      expect(mockLogService.info).toHaveBeenCalledWith(
        'AppComponent',
        'init',
        'App started'
      );
    }));

    it('should subscribe to state$ in constructor', fakeAsync(() => {
      fixture.detectChanges();
      tick();

      // Emit state change
      uiStateSubject.next(createMockState(StepId.SaveImages));
      tick();

      // Debug log should have been called from the subscription
      expect(mockLogService.debug).toHaveBeenCalled();
    }));

    it('should log state changes via subscription', fakeAsync(() => {
      // Component subscribed in constructor during beforeEach
      fixture.detectChanges();
      tick();

      // Emit a state change
      uiStateSubject.next(createMockState(StepId.VerifyPrereq));
      tick();

      // Should log the state change
      expect(mockLogService.debug).toHaveBeenCalledWith(
        'AppComponent',
        'state',
        jasmine.stringContaining('Active step')
      );

      discardPeriodicTasks(); // Clean up any remaining timers
    }));
  });

  describe('State$ Observable Property', () => {
    it('should expose state$ as readonly property', () => {
      expect(component.state$).toBeDefined();
      expect(typeof component.state$).toBe('object');
    });

    it('should reference UiStateManagementService state$ via observable', fakeAsync(() => {
      let receivedState: GuidanceOverviewState | undefined;
      component.state$.subscribe(state => {
        receivedState = state;
      });
      tick();

      expect(receivedState).toEqual(createMockState());
    }));

    it('should be accessible from template', fakeAsync(() => {
      uiStateSubject.next(createMockState(StepId.Introduction));
      fixture.detectChanges();
      tick();

      // Template can access state$ via async pipe
      const compiled = fixture.nativeElement as HTMLElement;
      expect(compiled.querySelector('.app-frame')).toBeTruthy();
    }));
  });

  describe('Dependency Injection', () => {
    it('should inject UiStateManagementService', () => {
      expect(component['stepUpdate']).toBeDefined();
    });

    it('should inject LogService', () => {
      expect(component['log']).toBeDefined();
    });

    it('should use injected services', fakeAsync(() => {
      fixture.detectChanges();
      tick();

      expect(mockLogService.info).toHaveBeenCalled();
    }));
  });

  describe('CSS Classes', () => {
    it('should apply left class to stepper', fakeAsync(() => {
      uiStateSubject.next(createMockState(StepId.Introduction));
      fixture.detectChanges();
      tick();

      const compiled = fixture.nativeElement as HTMLElement;
      const stepper = compiled.querySelector('app-guidance-overview.left');

      expect(stepper).toBeTruthy();
    }));

    it('should apply right class to step content container', fakeAsync(() => {
      uiStateSubject.next(createMockState(StepId.Introduction));
      fixture.detectChanges();
      tick();

      const compiled = fixture.nativeElement as HTMLElement;
      const rightSection = compiled.querySelector('.right');

      expect(rightSection).toBeTruthy();
    }));

    it('should apply app-frame class to main container', fakeAsync(() => {
      uiStateSubject.next(createMockState(StepId.Introduction));
      fixture.detectChanges();
      tick();

      const compiled = fixture.nativeElement as HTMLElement;
      const appFrame = compiled.querySelector('.app-frame');

      expect(appFrame).toBeTruthy();
    }));
  });

  describe('Error Handling', () => {
    it('should log even when state changes to different values', fakeAsync(() => {
      fixture.detectChanges();
      tick();

      const incompleteState: GuidanceOverviewState = {
        stepStatuses: {
          [StepId.Introduction]: StepStatus.Pending,
          [StepId.VerifyPrereq]: StepStatus.Pending,
          [StepId.VerificationResult]: StepStatus.Pending,
          [StepId.SaveImages]: StepStatus.Pending,
          [StepId.DriveToPark]: StepStatus.Pending,
          [StepId.Installation]: StepStatus.Pending,
        },
      };
      uiStateSubject.next(incompleteState);
      fixture.detectChanges();
      tick();

      // Should log the active step regardless of state
      expect(mockLogService.debug).toHaveBeenCalled();
    }));

    it('should continue functioning after multiple state updates', fakeAsync(() => {
      fixture.detectChanges();
      tick();

      // Multiple rapid updates
      for (let i = 0; i < 5; i++) {
        uiStateSubject.next(createMockState(StepId.Introduction));
        tick();
      }

      // Component should still be functional
      expect(mockLogService.debug.calls.count()).toBeGreaterThan(0);
    }));
  });

  describe('Logging Behavior', () => {
    it('should log with AppComponent as source', fakeAsync(() => {
      fixture.detectChanges();
      tick();

      expect(mockLogService.info).toHaveBeenCalledWith(
        'AppComponent',
        jasmine.any(String),
        jasmine.any(String)
      );
    }));

    it('should log init event on startup', fakeAsync(() => {
      fixture.detectChanges();
      tick();

      expect(mockLogService.info).toHaveBeenCalledWith(
        jasmine.any(String),
        'init',
        jasmine.any(String)
      );
    }));

    it('should log state event for state changes', fakeAsync(() => {
      fixture.detectChanges();
      tick();

      uiStateSubject.next(createMockState(StepId.VerifyPrereq));
      tick();

      expect(mockLogService.debug).toHaveBeenCalledWith(
        jasmine.any(String),
        'state',
        jasmine.any(String)
      );
    }));

    it('should include descriptive messages in logs', fakeAsync(() => {
      fixture.detectChanges();
      tick();

      const infoCall = mockLogService.info.calls.first();
      expect(infoCall.args[2]).toContain('App started');
    }));
  });
});




