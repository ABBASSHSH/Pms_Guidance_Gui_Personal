import { Component, CUSTOM_ELEMENTS_SCHEMA, OnInit, DestroyRef, inject } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { filter } from 'rxjs';

import { UiStateManagementService } from '../../core/update/ui-state-management-service';
import { CommunicationService } from '../../core/communication/communication.service';
import { LogService } from '../../core/log/log.service';
import { PrereqStatus } from '../../core/update/update.models';
import { TranslatePipe } from '../../core/i18n';

@Component({
    selector: 'app-verify-installation-prerequisites',
    imports: [TranslatePipe],
    templateUrl: './verify-installation-prerequisites.component.html',
    styleUrls: ['./verify-installation-prerequisites.component.css'],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class VerifyInstallationPrerequisitesComponent implements OnInit {
  progress = 0;
  statusTextKey = 'verification.status.inProgress';
  isError = false;
  showAbortModal = false;

  // Inject DestroyRef for takeUntilDestroyed
  private readonly destroyRef = inject(DestroyRef);

  constructor(
    private readonly uiStateUpdate: UiStateManagementService,
    private readonly comm: CommunicationService,
    private readonly log: LogService
  ) {}

  ngOnInit(): void {
    this.log.info('VerifyPrerequisites', 'step.entered', 'Entered Verify Installation Prerequisites step.');
    // Send request to backend
    this.comm.send('VerifyInstallationPrerequisite');
    this.log.debug('VerifyPrerequisites', 'be.request', 'Sent VerifyInstallationPrerequisite to backend.');
    // Listen for prerequisite-verification outcome (updated by message handler)
    this.uiStateUpdate.prereqStatus$
      .pipe(
        takeUntilDestroyed(this.destroyRef),
        filter((status): status is PrereqStatus.OK | PrereqStatus.NotOk => 
          status === PrereqStatus.OK || status === PrereqStatus.NotOk)
      )
      .subscribe(status => {
        this.log.info('VerifyPrerequisites', 'state.update', `Received prereqStatus: ${status}`);
        if (status === PrereqStatus.OK) {
          this.isError = false;
          this.progress = 100;
          this.statusTextKey = 'verification.status.success';
        } else {
          this.isError = true;
          this.progress = 75;
          this.statusTextKey = 'verification.status.error';
        }
      });
  }

  onAbort(): void {
    this.log.warn('VerifyPrerequisites', 'ui.abort', 'User pressed Abort — showing confirmation modal.');
    this.showAbortModal = true;
  }

  onAbortConfirmed(): void {
    this.showAbortModal = false;
    this.log.warn('VerifyPrerequisites', 'ui.abort.confirmed', 'User confirmed abort — sending CloseApp to backend.');
    this.comm.send('CloseApp');
    this.log.debug('VerifyPrerequisites', 'be.request', 'Sent CloseApp to backend.');
    // setPrereqStatus triggers the prereqStatus$ subscription above,
    // which will set isError, progress, and statusTextKey consistently.
    this.uiStateUpdate.setPrereqStatus(PrereqStatus.NotOk);
  }

  onAbortCancelled(): void {
    this.showAbortModal = false;
    this.log.info('VerifyPrerequisites', 'ui.abort.cancelled', 'User cancelled abort — verification continues.');
  }
}
