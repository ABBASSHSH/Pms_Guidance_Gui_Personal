import { ComponentFixture, TestBed, fakeAsync, tick, discardPeriodicTasks } from '@angular/core/testing';
import { VerifyInstallationPrerequisitesComponent } from './verify-installation-prerequisites.component';
import { UiStateManagementService } from '../../core/update/ui-state-management-service';
import { CommunicationService } from '../../core/communication/communication.service';
import { LogService } from '../../core/log/log.service';
import { I18nService } from '../../core/i18n';
import { BehaviorSubject } from 'rxjs';
import { GuidanceOverviewState, StepId, StepStatus, PrereqStatus, GUIDANCE_OVERVIEW_LABELS } from '../../core/update/update.models';

describe('VerifyInstallationPrerequisitesComponent', () => {
  let component: VerifyInstallationPrerequisitesComponent;
  let fixture: ComponentFixture<VerifyInstallationPrerequisitesComponent>;
  let mockStateService: jasmine.SpyObj<UiStateManagementService>;
  let mockCommService: jasmine.SpyObj<CommunicationService>;
  let mockLogService: jasmine.SpyObj<LogService>;
  let mockI18nService: jasmine.SpyObj<I18nService>;
  let uiStateSubject: BehaviorSubject<GuidanceOverviewState>;
  let prereqSubject: BehaviorSubject<PrereqStatus>;

  const INITIAL_STATUS_TEXT_KEY = 'verification.status.inProgress';
  const SUCCESS_STATUS_TEXT_KEY = 'verification.status.success';
  const ERROR_STATUS_TEXT_KEY = 'verification.status.error';

  const createMockState = (): GuidanceOverviewState => {
    const stepStatuses = {} as Record<StepId, StepStatus>;
    GUIDANCE_OVERVIEW_LABELS.forEach(config => {
      stepStatuses[config.id] = config.id === StepId.VerifyPrereq ? StepStatus.Active : StepStatus.Pending;
    });
    return {
      stepStatuses,
    };
  };

  beforeEach(async () => {
    uiStateSubject = new BehaviorSubject<GuidanceOverviewState>(createMockState());
    prereqSubject = new BehaviorSubject<PrereqStatus>(PrereqStatus.Unknown);
    
    mockStateService = jasmine.createSpyObj('UiStateManagementService', ['next', 'complete', 'error', 'setActive', 'setPrereqStatus']);
    Object.defineProperty(mockStateService, 'state$', {
      get: () => uiStateSubject.asObservable()
    });
    Object.defineProperty(mockStateService, 'prereqStatus$', {
      get: () => prereqSubject.asObservable()
    });
    
    mockCommService = jasmine.createSpyObj('CommunicationService', ['send']);
    mockLogService = jasmine.createSpyObj('LogService', ['info', 'debug', 'warn', 'error']);
    mockI18nService = jasmine.createSpyObj('I18nService', ['translate', 'setLanguage']);
    mockI18nService.translate.and.callFake((key: string) => key);

    await TestBed.configureTestingModule({
      imports: [VerifyInstallationPrerequisitesComponent],
      providers: [
        { provide: UiStateManagementService, useValue: mockStateService },
        { provide: CommunicationService, useValue: mockCommService },
        { provide: LogService, useValue: mockLogService },
        { provide: I18nService, useValue: mockI18nService }
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(VerifyInstallationPrerequisitesComponent);
    component = fixture.componentInstance;
  });

  describe('Component Initialization', () => {
    it('should create', fakeAsync(() => {
      expect(component).toBeTruthy();
      discardPeriodicTasks();
    }));

    it('should have initial progress of 0', fakeAsync(() => {
      expect(component.progress).toBe(0);
      discardPeriodicTasks();
    }));

    it('should have initial statusTextKey', fakeAsync(() => {
      expect(component.statusTextKey).toBe(INITIAL_STATUS_TEXT_KEY);
      discardPeriodicTasks();
    }));

    it('should have isError false initially', fakeAsync(() => {
      expect(component.isError).toBe(false);
      discardPeriodicTasks();
    }));
  });

  describe('ngOnInit Lifecycle', () => {
    it('should log step entry on init', fakeAsync(() => {
      fixture.detectChanges();
      tick();

      expect(mockLogService.info).toHaveBeenCalledWith(
        'VerifyPrerequisites',
        'step.entered',
        'Entered Verify Installation Prerequisites step.'
      );
      discardPeriodicTasks();
    }));

    it('should send VerifyInstallationPrerequisite message', fakeAsync(() => {
      fixture.detectChanges();
      tick();

      expect(mockCommService.send).toHaveBeenCalledWith('VerifyInstallationPrerequisite');
      discardPeriodicTasks();
    }));

    it('should log debug message after sending', fakeAsync(() => {
      fixture.detectChanges();
      tick();

      expect(mockLogService.debug).toHaveBeenCalledWith(
        'VerifyPrerequisites',
        'be.request',
        'Sent VerifyInstallationPrerequisite to backend.'
      );
      discardPeriodicTasks();
    }));

    it('should subscribe to state changes', fakeAsync(() => {
      fixture.detectChanges();
      tick();

      prereqSubject.next(PrereqStatus.OK);
      tick();

      expect(component.progress).toBe(100);
      discardPeriodicTasks();
    }));
  });

  describe('Success Scenario', () => {
    it('should set progress to 100 on success', fakeAsync(() => {
      fixture.detectChanges();
      tick();

      prereqSubject.next(PrereqStatus.OK);
      tick();

      expect(component.progress).toBe(100);
      discardPeriodicTasks();
    }));

    it('should update statusTextKey on success', fakeAsync(() => {
      fixture.detectChanges();
      tick();

      prereqSubject.next(PrereqStatus.OK);
      tick();

      expect(component.statusTextKey).toBe(SUCCESS_STATUS_TEXT_KEY);
      discardPeriodicTasks();
    }));

    it('should keep isError false on success', fakeAsync(() => {
      fixture.detectChanges();
      tick();

      prereqSubject.next(PrereqStatus.OK);
      tick();

      expect(component.isError).toBe(false);
      discardPeriodicTasks();
    }));

    it('should not call uiStateUpdate.next() on success', fakeAsync(() => {
      fixture.detectChanges();
      tick();

      prereqSubject.next(PrereqStatus.OK);
      tick();

      expect(mockStateService.next).not.toHaveBeenCalled();
      discardPeriodicTasks();
    }));
  });

  describe('Error Scenario', () => {
    it('should set isError to true on error', fakeAsync(() => {
      fixture.detectChanges();
      tick();

      prereqSubject.next(PrereqStatus.NotOk);
      tick();

      expect(component.isError).toBe(true);
      discardPeriodicTasks();
    }));

    it('should update statusTextKey on error', fakeAsync(() => {
      fixture.detectChanges();
      tick();

      prereqSubject.next(PrereqStatus.NotOk);
      tick();

      expect(component.statusTextKey).toBe(ERROR_STATUS_TEXT_KEY);
      discardPeriodicTasks();
    }));

    it('should set progress to at least 75 on error', fakeAsync(() => {
      fixture.detectChanges();
      tick(250 * 5); // progress = 10

      prereqSubject.next(PrereqStatus.NotOk);
      tick();

      expect(component.progress).toBeGreaterThanOrEqual(75);
      discardPeriodicTasks();
    }));

    it('should not call uiStateUpdate.next() on error', fakeAsync(() => {
      fixture.detectChanges();
      tick();

      prereqSubject.next(PrereqStatus.NotOk);
      tick();

      expect(mockStateService.next).not.toHaveBeenCalled();
      discardPeriodicTasks();
    }));
  });

  describe('onAbort Handler', () => {
    it('should show the abort confirmation modal', fakeAsync(() => {
      expect(component.showAbortModal).toBeFalse();
      component.onAbort();
      expect(component.showAbortModal).toBeTrue();
      discardPeriodicTasks();
    }));

    it('should log warn when abort is triggered', fakeAsync(() => {
      component.onAbort();

      expect(mockLogService.warn).toHaveBeenCalledWith(
        'VerifyPrerequisites',
        'ui.abort',
        'User pressed Abort — showing confirmation modal.'
      );
      discardPeriodicTasks();
    }));

    it('should handle multiple abort calls', fakeAsync(() => {
      component.onAbort();
      component.onAbort();

      expect(mockLogService.warn).toHaveBeenCalledTimes(2);
      discardPeriodicTasks();
    }));
  });

  describe('onAbortConfirmed Handler', () => {
    it('should close the modal', fakeAsync(() => {
      component.showAbortModal = true;
      component.onAbortConfirmed();
      expect(component.showAbortModal).toBeFalse();
      discardPeriodicTasks();
    }));

    it('should set isError to true', fakeAsync(() => {
      fixture.detectChanges();
      component.onAbortConfirmed();
      prereqSubject.next(PrereqStatus.NotOk);
      tick();
      expect(component.isError).toBeTrue();
      discardPeriodicTasks();
    }));

    it('should set progress to 75', fakeAsync(() => {
      fixture.detectChanges();
      component.onAbortConfirmed();
      prereqSubject.next(PrereqStatus.NotOk);
      tick();
      expect(component.progress).toBe(75);
      discardPeriodicTasks();
    }));

    it('should set statusTextKey to error key', fakeAsync(() => {
      fixture.detectChanges();
      component.onAbortConfirmed();
      prereqSubject.next(PrereqStatus.NotOk);
      tick();
      expect(component.statusTextKey).toBe('verification.status.error');
      discardPeriodicTasks();
    }));

    it('should call setPrereqStatus with NotOk', fakeAsync(() => {
      component.onAbortConfirmed();
      expect(mockStateService.setPrereqStatus).toHaveBeenCalledWith(PrereqStatus.NotOk);
      discardPeriodicTasks();
    }));

    it('should send CloseApp to backend', fakeAsync(() => {
      component.onAbortConfirmed();
      expect(mockCommService.send).toHaveBeenCalledWith('CloseApp');
      discardPeriodicTasks();
    }));

    it('should log warn on confirmed abort', fakeAsync(() => {
      component.onAbortConfirmed();
      expect(mockLogService.warn).toHaveBeenCalledWith(
        'VerifyPrerequisites',
        'ui.abort.confirmed',
        'User confirmed abort — sending CloseApp to backend.'
      );
      discardPeriodicTasks();
    }));

    it('should log debug after sending CloseApp', fakeAsync(() => {
      component.onAbortConfirmed();
      expect(mockLogService.debug).toHaveBeenCalledWith(
        'VerifyPrerequisites',
        'be.request',
        'Sent CloseApp to backend.'
      );
      discardPeriodicTasks();
    }));
  });

  describe('onAbortCancelled Handler', () => {
    it('should close the modal', fakeAsync(() => {
      component.showAbortModal = true;
      component.onAbortCancelled();
      expect(component.showAbortModal).toBeFalse();
      discardPeriodicTasks();
    }));

    it('should not set isError', fakeAsync(() => {
      component.isError = false;
      component.onAbortCancelled();
      expect(component.isError).toBeFalse();
      discardPeriodicTasks();
    }));

    it('should not call setPrereqStatus', fakeAsync(() => {
      component.onAbortCancelled();
      expect(mockStateService.setPrereqStatus).not.toHaveBeenCalled();
      discardPeriodicTasks();
    }));

    it('should log info on cancelled abort', fakeAsync(() => {
      component.onAbortCancelled();
      expect(mockLogService.info).toHaveBeenCalledWith(
        'VerifyPrerequisites',
        'ui.abort.cancelled',
        'User cancelled abort — verification continues.'
      );
      discardPeriodicTasks();
    }));
  });

  describe('DestroyRef and Cleanup', () => {
    it('should use takeUntilDestroyed in subscriptions', fakeAsync(() => {
      fixture.detectChanges();
      tick();

      fixture.destroy();

      prereqSubject.next(PrereqStatus.OK);
      tick();

      expect(component.progress).not.toBe(100);
      discardPeriodicTasks();
    }));

    it('should stop updates on destroy', fakeAsync(() => {
      fixture.detectChanges();
      tick(250 * 5);
      const progressBeforeDestroy = component.progress;

      fixture.destroy();
      tick(250 * 10);

      expect(component.progress).toBe(progressBeforeDestroy);
      discardPeriodicTasks();
    }));
  });

  describe('Logging Behavior', () => {
    it('should use correct source for all logs', fakeAsync(() => {
      fixture.detectChanges();
      tick();

      const infoCalls = mockLogService.info.calls.all();
      const debugCalls = mockLogService.debug.calls.all();

      infoCalls.forEach(call => {
        expect(call.args[0]).toBe('VerifyPrerequisites');
      });
      debugCalls.forEach(call => {
        expect(call.args[0]).toBe('VerifyPrerequisites');
      });
      discardPeriodicTasks();
    }));

    it('should use correct event types', fakeAsync(() => {
      fixture.detectChanges();
      tick();

      expect(mockLogService.info).toHaveBeenCalledWith(
        jasmine.any(String),
        'step.entered',
        jasmine.any(String)
      );
      expect(mockLogService.debug).toHaveBeenCalledWith(
        jasmine.any(String),
        'be.request',
        jasmine.any(String)
      );
      discardPeriodicTasks();
    }));

    it('should use warn level for abort', fakeAsync(() => {
      component.onAbort();

      expect(mockLogService.warn).toHaveBeenCalled();
      expect(mockLogService.info).not.toHaveBeenCalledWith(
        jasmine.any(String),
        'ui.abort',
        jasmine.any(String)
      );
      discardPeriodicTasks();
    }));
  });

  describe('Integration Tests', () => {
    it('should complete full success flow', fakeAsync(() => {
      fixture.detectChanges();
      tick();

      expect(mockCommService.send).toHaveBeenCalledWith('VerifyInstallationPrerequisite');
      expect(component.progress).toBeGreaterThanOrEqual(0);

      prereqSubject.next(PrereqStatus.OK);
      tick();

      expect(component.progress).toBe(100);
      expect(component.statusTextKey).toBe(SUCCESS_STATUS_TEXT_KEY);
      expect(component.isError).toBe(false);
      discardPeriodicTasks();
    }));

    it('should complete full error flow', fakeAsync(() => {
      fixture.detectChanges();
      tick();

      prereqSubject.next(PrereqStatus.NotOk);
      tick();

      expect(component.progress).toBeGreaterThanOrEqual(75);
      expect(component.statusTextKey).toBe(ERROR_STATUS_TEXT_KEY);
      expect(component.isError).toBe(true);
      discardPeriodicTasks();
    }));

    it('should handle abort during verification', fakeAsync(() => {
      fixture.detectChanges();
      tick(250 * 5);

      component.onAbort();

      expect(component.showAbortModal).toBeTrue();
      expect(mockLogService.warn).toHaveBeenCalledWith(
        'VerifyPrerequisites',
        'ui.abort',
        'User pressed Abort — showing confirmation modal.'
      );
      discardPeriodicTasks();
    }));

    it('should ignore null prereqStatus', fakeAsync(() => {
      fixture.detectChanges();
      tick();

      prereqSubject.next(PrereqStatus.Unknown);
      tick();

      expect(component.progress).not.toBe(100);
      expect(component.statusTextKey).toBe(INITIAL_STATUS_TEXT_KEY);
      discardPeriodicTasks();
    }));

    it('should handle rapid status changes', fakeAsync(() => {
      fixture.detectChanges();
      tick();

      prereqSubject.next(PrereqStatus.OK);
      prereqSubject.next(PrereqStatus.OK);
      tick();

      expect(component.progress).toBe(100);
      expect(component.isError).toBe(false);
      discardPeriodicTasks();
    }));
  });
});
