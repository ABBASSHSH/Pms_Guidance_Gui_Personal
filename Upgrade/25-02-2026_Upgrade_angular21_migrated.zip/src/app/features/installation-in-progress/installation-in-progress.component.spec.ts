import { ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { BehaviorSubject } from 'rxjs';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

import { InstallationInProgressComponent } from './installation-in-progress.component';
import { UiStateManagementService } from '../../core/update/ui-state-management-service';
import { CommunicationService } from '../../core/communication/communication.service';
import { LogService } from '../../core/log/log.service';
import { I18nService } from '../../core/i18n';
import { GuidanceOverviewState, StepId, StepStatus, GUIDANCE_OVERVIEW_LABELS } from '../../core/update/update.models';

describe('InstallationInProgressComponent', () => {
  let component: InstallationInProgressComponent;
  let fixture: ComponentFixture<InstallationInProgressComponent>;
  let mockStateService: jasmine.SpyObj<UiStateManagementService>;
  let mockCommService: jasmine.SpyObj<CommunicationService>;
  let mockLogService: jasmine.SpyObj<LogService>;
  let mockI18nService: jasmine.SpyObj<I18nService>;
  let uiStateSubject: BehaviorSubject<GuidanceOverviewState>;

  const createMockState = (): GuidanceOverviewState => {
    const stepStatuses = {} as Record<StepId, StepStatus>;
    GUIDANCE_OVERVIEW_LABELS.forEach(label => {
      stepStatuses[label.id] = label.id === StepId.Installation ? StepStatus.Active : StepStatus.Success;
    });
    return {
      stepStatuses,
    };
  };

  beforeEach(async () => {
    uiStateSubject = new BehaviorSubject<GuidanceOverviewState>(createMockState());

    mockStateService = jasmine.createSpyObj('UiStateManagementService', ['next', 'complete', 'error', 'setActive']);
    Object.defineProperty(mockStateService, 'state$', {
      get: () => uiStateSubject.asObservable()
    });

    mockCommService = jasmine.createSpyObj('CommunicationService', ['send']);
    mockLogService = jasmine.createSpyObj('LogService', ['info', 'debug', 'warn', 'error']);
    mockI18nService = jasmine.createSpyObj('I18nService', ['translate', 'setLanguage']);
    mockI18nService.translate.and.callFake((key: string) => key);

    await TestBed.configureTestingModule({
      imports: [InstallationInProgressComponent],
      providers: [
        { provide: UiStateManagementService, useValue: mockStateService },
        { provide: CommunicationService, useValue: mockCommService },
        { provide: LogService, useValue: mockLogService },
        { provide: I18nService, useValue: mockI18nService }
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();

    fixture = TestBed.createComponent(InstallationInProgressComponent);
    component = fixture.componentInstance;
  });

  describe('Component Initialization', () => {
    it('should create', () => {
      expect(component).toBeTruthy();
    });

    it('should have initial spinnerLabelKey', () => {
      expect(component.spinnerLabelKey).toBe('installation.status.inProgress');
    });
  });

  describe('ngOnInit Lifecycle', () => {
    it('should log step entry on init', fakeAsync(() => {
      fixture.detectChanges();
      tick();

      expect(mockLogService.info).toHaveBeenCalledWith(
        'InstallationInProgressComponent',
        'enter',
        'Entered Installation In Progress step'
      );
    }));

    it('should send InstallSoftware message to backend', fakeAsync(() => {
      fixture.detectChanges();
      tick();

      expect(mockCommService.send).toHaveBeenCalledWith('InstallSoftware');
    }));

    it('should log debug message after sending', fakeAsync(() => {
      fixture.detectChanges();
      tick();

      expect(mockLogService.debug).toHaveBeenCalledWith(
        'InstallationInProgressComponent',
        'be.request',
        'Sent InstallSoftware to backend'
      );
    }));
  });

  describe('Template Rendering', () => {
    it('should render full-page-container', fakeAsync(() => {
      fixture.detectChanges();
      tick();

      const compiled = fixture.nativeElement as HTMLElement;
      const container = compiled.querySelector('.full-page-container');
      expect(container).toBeTruthy();
    }));

    it('should render spinner-wrapper', fakeAsync(() => {
      fixture.detectChanges();
      tick();

      const compiled = fixture.nativeElement as HTMLElement;
      const wrapper = compiled.querySelector('.spinner-wrapper');
      expect(wrapper).toBeTruthy();
    }));

    it('should render sh-spinner element', fakeAsync(() => {
      fixture.detectChanges();
      tick();

      const compiled = fixture.nativeElement as HTMLElement;
      const spinner = compiled.querySelector('sh-spinner');
      expect(spinner).toBeTruthy();
    }));

    it('should render sh-spinner with large size', fakeAsync(() => {
      fixture.detectChanges();
      tick();

      const compiled = fixture.nativeElement as HTMLElement;
      const spinner = compiled.querySelector('sh-spinner');
      expect(spinner?.getAttribute('size')).toBe('l');
    }));
  });

  describe('Cleanup', () => {
    it('should not throw on destroy', fakeAsync(() => {
      fixture.detectChanges();
      tick();

      expect(() => fixture.destroy()).not.toThrow();
    }));
  });
});
